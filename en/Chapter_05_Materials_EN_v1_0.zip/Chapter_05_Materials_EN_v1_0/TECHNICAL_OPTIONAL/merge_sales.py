#!/usr/bin/env python3
"""Normalize, validate, deduplicate and combine the Chapter 5 training CSV files."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo

CENT = Decimal("0.01")
CANONICAL_FIELDS = ["sale_id", "sale_date", "item_code", "item_name", "quantity", "unit", "unit_price", "line_total"]

class InputError(Exception):
    pass

def money(text: str, decimal_mark: str) -> Decimal:
    value = (text or "").strip()
    if not value:
        raise ValueError('empty amount')
    if decimal_mark == ",":
        if "." in value or value.count(",") > 1:
            raise ValueError('unexpected decimal separator format')
        value = value.replace(",", ".")
    elif "," in value:
        raise ValueError('unexpected decimal separator format')
    if not re.fullmatch(r"-?\d+(\.\d{1,2})?", value):
        raise ValueError('amount does not have two decimal places')
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)

def parse_one(raw: dict, source: dict, row_number: int) -> dict:
    mapped = {}
    for header, canonical in source["headers"].items():
        mapped[canonical] = (raw.get(header) or "").strip()
    out = {
        "sale_id": mapped.get("sale_id", "").strip().upper(),
        "sale_date": None,
        "item_code": mapped.get("item_code", "").strip(),
        "item_name": mapped.get("item_name", "").strip(),
        "quantity": None,
        "unit": None,
        "unit_price": None,
        "line_total": None,
        "currency": "EUR",
        "source_file": source["file"],
        "source_row": row_number,
        "errors": [],
        "declared_total": None,
    }
    if not out["sale_id"]:
        out["errors"].append('missing sale ID')
    if not out["item_code"]:
        out["errors"].append('missing product code')
    if not out["item_name"]:
        out["errors"].append('missing product name')
    raw_date = mapped.get("sale_date", "")
    try:
        out["sale_date"] = datetime.strptime(raw_date, source["date_format"]).date()
    except (ValueError, TypeError):
        out["errors"].append('date has the wrong file-specific format or does not exist')
    raw_qty = mapped.get("quantity", "")
    try:
        if not re.fullmatch(r"\d+", raw_qty):
            raise ValueError
        out["quantity"] = int(raw_qty)
        if out["quantity"] <= 0:
            out["errors"].append('quantity must be a positive integer')
    except ValueError:
        out["errors"].append('quantity must be a positive integer')
    raw_unit = mapped.get("unit", "").strip()
    unit_map = {k.casefold(): v for k, v in source["unit_map"].items()}
    out["unit"] = unit_map.get(raw_unit.casefold())
    if out["unit"] is None:
        out["errors"].append('unit is absent from the agreed mapping')
    for field, label in (("unit_price", 'unit price'), ("line_total", 'line total')):
        try:
            out[field] = money(mapped.get(field, ""), source["decimal_mark"])
        except (ValueError, InvalidOperation):
            out["errors"].append(label + ' could not read without guessing')
    if out["unit_price"] is not None and out["unit_price"] <= 0:
        out["errors"].append('practice price must be greater than zero')
    if out["line_total"] is not None and out["line_total"] < 0:
        out["errors"].append('negative amounts are not allowed in this practice example')
    out["declared_total"] = out["line_total"]
    if out["quantity"] is not None and out["unit_price"] is not None and out["line_total"] is not None:
        expected = (Decimal(out["quantity"]) * out["unit_price"]).quantize(CENT, rounding=ROUND_HALF_UP)
        if expected != out["line_total"]:
            out["errors"].append('line total is not quantity multiplied by price')
    return out

def signature(row: dict) -> tuple:
    return tuple(row.get(key) for key in ("sale_date", "item_code", "quantity", "unit", "unit_price", "line_total", "currency"))

def read_inputs(input_dir: Path, spec: dict):
    all_rows, hashes, source_counts = [], [], []
    for source in spec["source_files"]:
        path = input_dir / source["file"]
        if not path.is_file():
            raise InputError('Required file missing: ' + source["file"])
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        hashes.append((source["file"], digest))
        with path.open("r", encoding=source["encoding"], newline="") as handle:
            reader = csv.DictReader(handle, delimiter=source["delimiter"])
            expected_headers = list(source["headers"].keys())
            if reader.fieldnames != expected_headers:
                raise InputError(
                    source["file"] + ': headers or their order differ from the specification. '
                    'Agree on the column mapping first; file not processed.'
                )
            count = 0
            for row_number, raw in enumerate(reader, start=2):
                count += 1
                if None in raw:
                    raise InputError(source["file"] + ', row ' + str(row_number) + ': field count differs from header; review the entire file.')
                all_rows.append(parse_one(raw, source, row_number))
            source_counts.append((source["file"], count))
    return all_rows, hashes, source_counts

def process(rows: list, duplicate_key: str):
    groups = defaultdict(list)
    for row in rows:
        key = row.get(duplicate_key)
        if key:
            groups[key].append(row)
    accepted, review = [], []
    for row in rows:
        if not row.get(duplicate_key):
            row["status"] = 'Data error'
            row["reason"] = "; ".join(row["errors"])
            review.append(row)
            continue
        group = groups[row[duplicate_key]]
        if len(group) > 1:
            clean = all(not item["errors"] for item in group)
            same = clean and all(signature(item) == signature(group[0]) for item in group[1:])
            if same:
                if row is group[0]:
                    row["status"] = 'Accepted row'
                    accepted.append(row)
                else:
                    row["status"] = 'Exact duplicate'
                    row["reason"] = 'The agreed key and all comparison fields match; duplicate excluded.'
                    review.append(row)
            else:
                differing = []
                first = group[0]
                if all(not item["errors"] for item in group):
                    for name in ("sale_date", "item_code", "quantity", "unit", "unit_price", "line_total", "currency"):
                        if any(item.get(name) != first.get(name) for item in group[1:]):
                            differing.append(name)
                reason = 'Same sale_id key, conflicting values'
                if differing:
                    reason += ' in fields: ' + ", ".join(differing)
                reason += '; every record for this key is sent to review.'
                if row["errors"]:
                    reason += ' Also: ' + "; ".join(row["errors"])
                row["status"] = 'Key conflict'
                row["reason"] = reason
                review.append(row)
        elif row["errors"]:
            row["status"] = 'Data error'
            row["reason"] = "; ".join(row["errors"])
            review.append(row)
        else:
            row["status"] = 'Accepted row'
            accepted.append(row)
    return accepted, review

def dec_sum(rows, field):
    return sum((r[field] for r in rows if isinstance(r.get(field), Decimal)), Decimal("0.00")).quantize(CENT)

def write_workbook(output_path: Path, accepted: list, review: list, summary: dict, source_counts: list, hashes: list, spec: dict):
    wb = Workbook()
    ws = wb.active
    ws.title = 'Summary'
    accepted_ws = wb.create_sheet('Accepted')
    review_ws = wb.create_sheet('Review')
    sources_ws = wb.create_sheet('Sources')
    font = "Arial"
    header_fill = PatternFill("solid", fgColor="24476B")
    pale_blue = PatternFill("solid", fgColor="EAF1F7")
    pale_red = PatternFill("solid", fgColor="FCE8E6")
    thin = Side(style="thin", color="D9D9D9")
    border = Border(bottom=thin)
    for sheet in wb.worksheets:
        sheet.sheet_view.showGridLines = False
        sheet.sheet_properties.pageSetUpPr.fitToPage = True
    ws["A1"] = 'Merged practice sales report'
    ws["A1"].font = Font(name=font, size=16, bold=True, color="000000")
    ws["A2"] = 'Period: September 1–11, 2026 • currency EUR • synthetic practice data'
    ws["A2"].font = Font(name=font, size=10, italic=True, color="404040")
    ws.append([])
    ws.append(['Processing checks', 'Result', 'Explanation'])
    for cell in ws[4]:
        cell.fill, cell.font, cell.alignment = header_fill, Font(name=font, bold=True, color="FFFFFF"), Alignment(horizontal="center", vertical="center", wrap_text=True)
    controls = [
        ('Source rows', summary["input_rows"], 'Data rows from three CSVs'),
        ('Rows accepted', len(accepted), 'Included in the final report'),
        ('Exact duplicate', summary["exact_duplicates"], 'Excluded; first row retained'),
        ('Key-conflict rows', summary["conflict_rows"], 'All rows with this ID held for review'),
        ('Invalid rows', summary["invalid_rows"], 'Excluded from the sales total'),
        ('Source row total, EUR', float(summary["source_amount"]), 'Before excluding duplicates and rows for review'),
        ('Excluded exact duplicate, EUR', float(summary["duplicate_amount"]), 'Duplicate row total'),
        ('Conflicting row total, EUR', float(summary["conflict_amount"]), 'Both rows with the same key'),
        ('Invalid row total, EUR', float(summary["invalid_amount"]), 'Stated line total before checking'),
        ('Accepted total, EUR', float(summary["accepted_amount"]), 'Total of accepted rows only'),
        ('Reconciliation difference, EUR', float(summary["reconciliation_difference"]) if summary["reconciliation_complete"] else None,
         'Expected 0,00 when amounts are readable' if summary["reconciliation_complete"] else 'Unconfirmed: one or more source amounts could not be read'),
    ]
    for row in controls:
        ws.append(list(row))
    for row in ws.iter_rows(min_row=5,max_row=15,min_col=1,max_col=3):
        for cell in row:
            cell.font=Font(name=font,size=10,color="202020")
            cell.border=border
            cell.alignment=Alignment(vertical="center",wrap_text=True)
    for row in range(10,16):
        ws.cell(row,2).number_format='#,##0.00 "EUR"'
    ws["A16"] = 'The chart includes only accepted rows; rows under review are excluded.'
    ws["A16"].font = Font(name=font,size=9,italic=True,color="404040")
    ws["A18"] = 'Accepted sales by date'
    ws["A18"].font = Font(name=font,size=12,bold=True)
    ws["A19"] = 'Date'
    ws["B19"] = 'Sales total, EUR'
    for cell in ws[19][:2]:
        cell.fill, cell.font = header_fill, Font(name=font,bold=True,color="FFFFFF")
    by_date=defaultdict(lambda:Decimal("0.00"))
    for row in accepted:
        by_date[row["sale_date"]] += row["line_total"]
    for index, (d, amount) in enumerate(sorted(by_date.items()), start=20):
        r=index
        ws.cell(r,1).value=d
        ws.cell(r,1).number_format="dd.mm.yyyy"
        ws.cell(r,2).value=float(amount)
        ws.cell(r,2).number_format='#,##0.00 "EUR"'
    chart=BarChart()
    chart.type="col"
    chart.style=10
    chart.title='Sales by date, EUR'
    chart.y_axis.title="EUR"
    chart.x_axis.title='Sale date'
    chart.height=8.5
    chart.width=15
    data=Reference(ws,min_col=2,min_row=19,max_row=19+len(by_date))
    cats=Reference(ws,min_col=1,min_row=20,max_row=19+len(by_date))
    chart.add_data(data,titles_from_data=True)
    chart.set_categories(cats)
    chart.legend=None
    ws.add_chart(chart,"D4")
    ws.column_dimensions["A"].width=36
    ws.column_dimensions["B"].width=22
    ws.column_dimensions["C"].width=52
    ws.column_dimensions["D"].width=14
    ws.freeze_panes="A5"

    headers=['Sale ID','Date','Product code','Product','Quantity','Unit','Price EUR','Total EUR','Source file','Source row']
    accepted_ws.append(headers)
    for r in accepted:
        accepted_ws.append([r["sale_id"],r["sale_date"],r["item_code"],r["item_name"],r["quantity"],r["unit"],float(r["unit_price"]),float(r["line_total"]),r["source_file"],r["source_row"]])
    review_headers=['Sale ID','Status','Review reason','Date','Product code','Product','Quantity','Unit','Price EUR','Total EUR','Source file','Source row']
    review_ws.append(review_headers)
    for r in review:
        review_ws.append([r["sale_id"],r["status"],r["reason"],r["sale_date"],r["item_code"],r["item_name"],r["quantity"],r["unit"],float(r["unit_price"]) if r["unit_price"] is not None else None,float(r["line_total"]) if r["line_total"] is not None else None,r["source_file"],r["source_row"]])
    for sheet,tabname,ref in ((accepted_ws,"AcceptedSales","A1:J"+str(max(2,accepted_ws.max_row))),(review_ws,"ReviewSales","A1:L"+str(max(2,review_ws.max_row)))):
        for cell in sheet[1]:
            cell.fill=header_fill; cell.font=Font(name=font,bold=True,color="FFFFFF"); cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.font=Font(name=font,size=10)
                cell.alignment=Alignment(vertical="center",wrap_text=cell.column in (3,))
            if sheet is review_ws:
                for cell in row:
                    cell.fill=pale_red
        table=Table(displayName=tabname,ref=ref)
        table.tableStyleInfo=TableStyleInfo(name="TableStyleMedium2",showFirstColumn=False,showLastColumn=False,showRowStripes=True,showColumnStripes=False)
        sheet.add_table(table)
        sheet.freeze_panes="A2"
        for col in sheet.columns:
            letter=col[0].column_letter
            width=min(max(max(len(str(c.value or "")) for c in col)+2,12),42)
            sheet.column_dimensions[letter].width=width
        for row_idx in range(2,sheet.max_row+1):
            sheet.cell(row_idx,2 if sheet is accepted_ws else 4).number_format="dd.mm.yyyy"
            if sheet is accepted_ws:
                sheet.cell(row_idx,3).number_format="@"
                sheet.cell(row_idx,7).number_format='#,##0.00 "EUR"'
                sheet.cell(row_idx,8).number_format='#,##0.00 "EUR"'
            else:
                sheet.cell(row_idx,5).number_format="@"
                sheet.cell(row_idx,9).number_format='#,##0.00 "EUR"'
                sheet.cell(row_idx,10).number_format='#,##0.00 "EUR"'
    sources_ws.append(['Source file','Data rows','Delimiter','Date format','Decimal separator',"SHA-256"])
    source_by_name={item["file"]:item for item in spec["source_files"]}
    hash_map=dict(hashes)
    for name, count in source_counts:
        source=source_by_name[name]
        sources_ws.append([name,count,source["delimiter"],source["date_format"],source["decimal_mark"],hash_map[name]])
    for cell in sources_ws[1]:
        cell.fill=header_fill; cell.font=Font(name=font,bold=True,color="FFFFFF"); cell.alignment=Alignment(horizontal="center",wrap_text=True)
    for col,width in zip("ABCDEF",[24,15,15,20,20,68]): sources_ws.column_dimensions[col].width=width
    sources_ws.freeze_panes="A2"
    for sheet in wb.worksheets:
        sheet.sheet_view.showGridLines=False
    output_path.parent.mkdir(parents=True,exist_ok=True)
    wb.save(output_path)

def run(input_dir: Path, spec_path: Path, output_dir: Path):
    spec=json.loads(spec_path.read_text(encoding="utf-8"))
    rows,hashes,source_counts=read_inputs(input_dir,spec)
    accepted,review=process(rows,spec["duplicate_rule"]["key"][0])
    duplicate_amount=dec_sum([r for r in review if r["status"]=='Exact duplicate'],"declared_total")
    conflict_amount=dec_sum([r for r in review if r["status"]=='Key conflict'],"declared_total")
    invalid_amount=dec_sum([r for r in review if r["status"]=='Data error'],"declared_total")
    source_amount=dec_sum(rows,"declared_total")
    accepted_amount=dec_sum(accepted,"line_total")
    difference=(source_amount-duplicate_amount-conflict_amount-invalid_amount-accepted_amount).quantize(CENT)
    exact_count=sum(r["status"]=='Exact duplicate' for r in review)
    conflict_count=sum(r["status"]=='Key conflict' for r in review)
    invalid_count=sum(r["status"]=='Data error' for r in review)
    reconciliation_complete=all(r["declared_total"] is not None for r in rows)
    summary={"input_rows":len(rows),"accepted_rows":len(accepted),"exact_duplicates":exact_count,"conflict_rows":conflict_count,"invalid_rows":invalid_count,"source_amount":source_amount,"duplicate_amount":duplicate_amount,"conflict_amount":conflict_amount,"invalid_amount":invalid_amount,"accepted_amount":accepted_amount,"reconciliation_difference":difference,"reconciliation_complete":reconciliation_complete}
    if not reconciliation_complete:
        summary["reconciliation_difference"] = None
    output_dir.mkdir(parents=True,exist_ok=True)
    write_workbook(output_dir/"merged_sales.xlsx",accepted,review,summary,source_counts,hashes,spec)
    def json_row(row):
        return {key:(value.isoformat() if isinstance(value,date) else format(value,".2f") if isinstance(value,Decimal) else value)
                for key,value in row.items() if key not in ("errors","declared_total")}
    json_summary={key:(format(value,".2f") if isinstance(value,Decimal) else value) for key,value in summary.items()}
    json_data={"summary":json_summary,"accepted":[json_row(row) for row in accepted],"review":[json_row(row) for row in review],"source_counts":[{"file":name,"rows":count,"sha256":dict(hashes)[name]} for name,count in source_counts],"sources":spec["source_files"]}
    (output_dir/"processed_data.json").write_text(json.dumps(json_data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    complete=reconciliation_complete
    lines=['PROCESSING VERIFICATION RECORD', 'Practice sales dataset; currency EUR.', "", 'SOURCES']
    lines += [f"{name}: {count} rows; SHA-256 {digest}" for name,digest in hashes for count in [dict(source_counts)[name]]]
    difference_text=f"{difference:.2f} EUR" if complete else 'UNCONFIRMED: an unreadable source amount exists'
    lines += ["", 'RESULTS', f"Source rows: {len(rows)}",f"Accepted: {len(accepted)}",f"Exact duplicate excluded: {exact_count}",f"Conflicting-key rows: {conflict_count}",f"Invalid rows: {invalid_count}",f"Source row total: {source_amount:.2f} EUR",f"Exact duplicate: {duplicate_amount:.2f} EUR",f"Conflicting rows: {conflict_amount:.2f} EUR",f"Invalid rows: {invalid_amount:.2f} EUR",f"Accepted total: {accepted_amount:.2f} EUR",f"Reconciliation difference: {difference_text}", "", 'The script does not confirm human review of the workbook’s business meaning or appearance.', 'Review Summary, Accepted, and Review before using the result.']
    (output_dir/"run_record.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    return summary

if __name__=="__main__":
    parser=argparse.ArgumentParser(description='Reconcile and merge practice sales CSV reports.')
    parser.add_argument("--input-dir",required=True,type=Path,help='Folder with three input CSV files')
    parser.add_argument("--spec",required=True,type=Path,help='Agreed field and format description')
    parser.add_argument("--output-dir",required=True,type=Path,help='Folder for the Excel workbook and verification record')
    args=parser.parse_args()
    try:
        result=run(args.input_dir,args.spec,args.output_dir)
    except (InputError, OSError, KeyError, json.JSONDecodeError) as exc:
        print('PROCESSING STOPPED:',str(exc),file=sys.stderr)
        sys.exit(2)
    print(json.dumps({k:(f"{v:.2f}" if isinstance(v,Decimal) else v) for k,v in result.items()},ensure_ascii=False,indent=2))
