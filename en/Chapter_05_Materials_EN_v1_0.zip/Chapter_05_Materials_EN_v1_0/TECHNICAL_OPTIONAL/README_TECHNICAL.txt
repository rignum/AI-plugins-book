TECHNICAL EXTENSION

This folder is not needed for the main exercise.

It contains the original technical implementation materials:
- merge_sales.py — Python processing script;
- requirements.txt — XLSX creation dependency;
- field_spec.json — machine-readable specification;
- plugin_sales_report/ — example Skill/plugin packaging;
- SHA256SUMS.txt — source-file checksums;
- SOURCES.txt and VALIDATION_original.txt — original package information.

To try the Python route, work only with practice-file copies. A script’s presence does not mean ChatGPT can run it on your computer. A real connection requires a supported environment and explicit permissions.
