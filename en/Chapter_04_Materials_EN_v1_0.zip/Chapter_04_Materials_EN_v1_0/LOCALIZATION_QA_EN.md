# English localization QA — Chapter4

Review candidate; not a published download. Source author VALIDATION.txt records are translated historical records, not evidence of tests run in this localization session. Current actual tests are listed in BOOK02_PRACTICE_FUNCTIONAL_QA.csv and qa logs.

Scope: Preserve quote lines, catalog quantities, EUR149.00/EUR116.00 and rejection conditions.

No source files were changed. Machine-generated caches are omitted only as documented. No external service was invoked. For chapter13, four WebM remain Russian in-frame and block complete localization. Chapter15 reference paragraph3 mismatch remains open. Full-book visual and download-hosting checks are pending.
