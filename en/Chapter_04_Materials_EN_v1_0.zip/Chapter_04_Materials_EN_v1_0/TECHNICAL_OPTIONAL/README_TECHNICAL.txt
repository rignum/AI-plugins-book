TECHNICAL EXTENSION — CHAPTER 4

This folder is optional for the book’s main exercise.
It shows the original technical implementation:
- JSON versions of the catalog and requests;
- calculate_quote.py for deterministic validation and calculation;
- a sample Skill_Office_Quote structure;
- reference JSON results.

To try the Python version, use a folder copy and Python 3. Do not change work-computer settings or bypass organizational package-installation rules. The script uses only the standard library.

Availability of Skills, Plugins, MCP, and installation methods in ChatGPT changes. Consult current OpenAI documentation before real packaging. These files do not by themselves mean anything is installed or running inside ChatGPT.