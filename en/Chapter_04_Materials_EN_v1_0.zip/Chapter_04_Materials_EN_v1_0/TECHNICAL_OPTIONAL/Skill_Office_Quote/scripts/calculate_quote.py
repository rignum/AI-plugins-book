#!/usr/bin/env python3
'Practice quote calculation. Python 3, standard library only.\n\nUsage: python calculate_quote.py catalog.json request_full.json\nReads two files and prints JSON; writes and sends nothing.\nExit code: 0 — success; 2 — input corrections required.\n'
import json
import re
import sys
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


def calculate(catalog, request):
    errors = []
    if not isinstance(catalog, dict) or not isinstance(request, dict):
        return {"status": "needs_review", "errors": ['Catalog and request must be JSON objects']}
    allowed_catalog = {"version", "seller", "currency", "scope_note", "services"}
    allowed_request = {"quote_id", "date", "client", "currency", "delivery_terms", "payment_terms", "valid_until", "items"}
    for label, obj, allowed in [('Catalog', catalog, allowed_catalog), ('Request', request, allowed_request)]:
        extra = set(obj) - allowed
        if extra:
            errors.append(label + ': unknown fields ' + ", ".join(sorted(extra)))
    for key in ["version", "seller", "currency", "scope_note"]:
        if not isinstance(catalog.get(key), str) or not catalog[key].strip():
            errors.append('Catalog: missing text field ' + key)
    for key in ["quote_id", "date", "client", "currency", "delivery_terms", "payment_terms", "valid_until"]:
        if not isinstance(request.get(key), str) or not request[key].strip():
            errors.append('Request: missing text field ' + key)
    if isinstance(request.get("quote_id"), str) and not re.fullmatch(r"KP-[0-9]{3,8}", request["quote_id"]):
        errors.append('Number must have the form KP-001 with 3 to 8 digits')
    parsed_dates = {}
    for key in ["date", "valid_until"]:
        try:
            raw = request.get(key)
            if not isinstance(raw, str) or not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", raw):
                raise ValueError()
            parsed_dates[key] = date.fromisoformat(raw)
        except ValueError:
            errors.append('Request: invalid date ' + key + ', expected YYYY-MM-DD')
    if len(parsed_dates) == 2 and parsed_dates["valid_until"] < parsed_dates["date"]:
        errors.append('Validity ends before the quote date')
    if catalog.get("currency") != "EUR" or request.get("currency") != "EUR":
        errors.append('Practice calculation supports EUR only, without conversion')

    services = catalog.get("services")
    lookup = {}
    if not isinstance(services, list) or not services:
        errors.append('Catalog: services must be a nonempty list')
        services = []
    for index, service in enumerate(services, 1):
        prefix = 'Catalog, service ' + str(index) + ": "
        if not isinstance(service, dict):
            errors.append(prefix + 'object required')
            continue
        if set(service) != {"code", "name", "unit", "price"}:
            errors.append(prefix + 'only code, name, unit, price required')
            continue
        if not all(isinstance(service[k], str) and service[k].strip() for k in service):
            errors.append(prefix + 'all fields must be nonempty strings')
            continue
        code = service["code"]
        if code in lookup:
            errors.append(prefix + 'duplicate code ' + code)
            continue
        if not re.fullmatch(r"[A-Z][A-Z0-9_]{0,29}", code):
            errors.append(prefix + 'invalid code')
            continue
        if not re.fullmatch(r"(?:0|[1-9][0-9]{0,6})\.[0-9]{2}", service["price"]):
            errors.append(prefix + 'price must be a string such as 18.00')
            continue
        price = Decimal(service["price"])
        if price <= 0:
            errors.append(prefix + 'price must be positive')
            continue
        lookup[code] = service

    items = request.get("items")
    if not isinstance(items, list) or not items:
        errors.append('Request: items must be a nonempty list')
        items = []
    rows = []
    seen = set()
    for index, item in enumerate(items, 1):
        prefix = 'Request, line item ' + str(index) + ": "
        if not isinstance(item, dict) or set(item) != {"code", "quantity"}:
            errors.append(prefix + 'only code and quantity required; the catalog sets the price')
            continue
        code, quantity = item["code"], item["quantity"]
        if not isinstance(code, str) or code not in lookup:
            errors.append(prefix + 'unknown service code ' + str(code))
            continue
        if code in seen:
            errors.append(prefix + 'duplicate service code ' + code)
            continue
        seen.add(code)
        if type(quantity) is not int or not 1 <= quantity <= 1000000:
            errors.append(prefix + 'quantity must be an integer from 1 to 1000000')
            continue
        service = lookup[code]
        amount = (Decimal(service["price"]) * quantity).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        rows.append({"code": code, "name": service["name"], "unit": service["unit"], "quantity": quantity, "price": service["price"], "amount": format(amount, ".2f")})
    if errors:
        return {"status": "needs_review", "errors": errors}
    total = sum((Decimal(row["amount"]) for row in rows), Decimal("0.00"))
    return {"status": "ok", "catalog_version": catalog["version"], "seller": catalog["seller"],
            "quote_id": request["quote_id"], "date": request["date"], "client": request["client"],
            "currency": "EUR", "rows": rows, "total": format(total, ".2f"),
            "delivery_terms": request["delivery_terms"], "payment_terms": request["payment_terms"],
            "valid_until": request["valid_until"], "scope_note": catalog["scope_note"]}


def reject_duplicate_keys(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('Duplicate JSON field: ' + key)
        obj[key] = value
    return obj


def main():
    if len(sys.argv) != 3:
        print(json.dumps({"status": "needs_review", "errors": ['Usage: python calculate_quote.py catalog.json request_full.json']}, ensure_ascii=False))
        return 2
    try:
        objects = []
        for filename in sys.argv[1:]:
            with open(filename, encoding="utf-8-sig") as stream:
                objects.append(json.load(stream, object_pairs_hook=reject_duplicate_keys))
        result = calculate(*objects)
    except (OSError, ValueError, InvalidOperation, UnicodeError) as exc:
        result = {"status": "needs_review", "errors": ['Could not read or validate inputs: ' + str(exc)]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "ok" else 2


if __name__ == "__main__":
    sys.exit(main())
