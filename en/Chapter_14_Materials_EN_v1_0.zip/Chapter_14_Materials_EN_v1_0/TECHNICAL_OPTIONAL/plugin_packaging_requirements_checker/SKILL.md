# Requirements Checker — practice Skill

Purpose: explain formal document-package check results against a supplied procedure.

Rules:
1. Preserve every rule’s ID and actual status.
2. Do not turn NOT_APPLICABLE into an error.
3. Do not replace INSUFFICIENT_DATA with a guess.
4. Provide specific evidence for DEVIATION.
5. Do not claim legal, regulatory, or full corporate compliance.
6. Change documents only after an explicit user decision.
