from pathlib import Path
import csv,re,json

def read_csv(path):
    with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def read_manifest(path):
    with open(path,encoding='utf-8-sig',newline='') as f:return {r['field']:r['value'] for r in csv.DictReader(f)}
def load_docs(folder):
    return {p.name:p.read_text(encoding='utf-8') for p in Path(folder).glob('*.txt')}
def check_rule(rule,man,docs):
    t=rule['check_type']; target=rule['target']
    if t=='required_file':
        return ('COMPLIANT',f'File {target} found.') if target in docs else ('DEVIATION',f'File {target} missing.')
    if t=='conditional_file':
        k,v=rule['applies_if'].split('=',1)
        if man.get(k)!=v:return ('NOT_APPLICABLE',f'Condition {rule["applies_if"]} is not met.')
        return ('COMPLIANT',f'File {target} found.') if target in docs else ('DEVIATION',f'File {target} is required but missing.')
    if t=='required_headings':
        if target not in docs:return ('DEVIATION',f'{target} missing.')
        miss=[x for x in rule['argument'].split('|') if x not in docs[target]]
        return ('DEVIATION','Missing fields: '+', '.join(miss)) if miss else ('COMPLIANT','All required fields found.')
    if t=='data_period_not_after_submission':
        if target not in docs:return ('DEVIATION',f'{target} missing.')
        m=re.search('Data period:\\s*(\\d{4}-\\d{2}-\\d{2})\\s*[—-]\\s*(\\d{4}-\\d{2}-\\d{2})',docs[target])
        if not m:return ('DEVIATION','Period field not found.')
        sub=man.get('submission_date','')
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',sub):return ('INSUFFICIENT_DATA','Submission date is not unambiguous.')
        return ('COMPLIANT',f'{m.group(2)} <= {sub}') if m.group(2)<=sub else ('DEVIATION',f'{m.group(2)} > {sub}')
    if t=='ambiguous_external_data':
        if man.get('contains_external_data','').lower()!='yes':return ('NOT_APPLICABLE','No external data is used.')
        return ('INSUFFICIENT_DATA','No measurable criterion for “sufficiently up to date” is defined.')
    return ('INSUFFICIENT_DATA','Unknown check type.')
def check(regulation,manifest,folder):
    rules=read_csv(regulation); man=read_manifest(manifest); docs=load_docs(folder)
    return [(r['rule_id'],)+check_rule(r,man,docs) for r in rules]
