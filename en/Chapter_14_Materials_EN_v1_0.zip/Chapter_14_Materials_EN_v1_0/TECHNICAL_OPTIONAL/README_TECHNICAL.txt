This section is not needed for the main exercise.

checker.py is a reference Python implementation of the same formal rules as the local browser tool.
tests/test_checker.py contains automated tests for normal and edge cases.
plugin_packaging_requirements_checker/ demonstrates permanent Skill instructions and a future tool contract.

To run tests from TECHNICAL_OPTIONAL:
python -m unittest discover -s tests -v
