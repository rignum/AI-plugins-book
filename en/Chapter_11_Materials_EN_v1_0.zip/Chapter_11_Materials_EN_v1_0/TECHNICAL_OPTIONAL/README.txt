TECHNICAL EXTENSION

This folder is not needed for the main exercise.
This contains the original Python implementation, automated tests, BAT files, sample Skill, and tool contract.
They support technical reproduction or discussion with a developer.
