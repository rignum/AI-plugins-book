PRACTICE PROJECT: tasks from meeting minutes

IMPORTANT: this project has no Trello connection or network requests.
create_tasks_simulated.bat simulates Trello responses and saves fictional
cards in project/reports/. It changes no board, account, or work data.

Procedure:
1. Review data/minutes.txt, data/people.csv, and data/project_map.json.
2. Run run_preview.bat. It validates candidates and creates reports/preview_tasks.csv.
3. Compare with materials/EXPECTED_PREVIEW.txt. Only T-01 and T-02 are ready.
4. Confirm data/approved_task_ids.txt contains only T-01 and T-02.
5. Run create_tasks_simulated.bat. Explicit confirmation flag is required; execution is simulation only.
6. Check reports/simulated_trello_cards.json and reports/creation_result.json.
7. Repeat create_tasks_simulated.bat. No new practice cards should appear.
8. Run run_tests.bat for automated checks.

Python 3, no third-party libraries. If py -3 is unavailable,
open a terminal in project and run:
  python src/task_pipeline.py preview
  python src/task_pipeline.py simulate-create --confirm
  python -m unittest discover -s tests -v

BOARD-DEMO-11, LIST-DEMO-11-READY, and MEM-DEMO-* are fictional values.
Do not use them in a real Trello request.
