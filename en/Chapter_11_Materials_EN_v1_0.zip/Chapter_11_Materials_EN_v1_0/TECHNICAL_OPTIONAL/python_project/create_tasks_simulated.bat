@echo off
setlocal
cd /d "%~dp0"
echo Practice mode: only local examples will be written; Trello is not connected.
py -3 src\task_pipeline.py simulate-create --confirm
if errorlevel 1 pause
