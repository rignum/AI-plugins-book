(function(global){
'use strict';
const EXPECTED_UNITS = {
  room_length: 'mm', room_width: 'mm', reserve: '%', package_area: 'm2', package_price: 'CHF/package'
};
function fail(msg){ const e=new Error(msg); e.name='CalculationInputError'; throw e; }
function decimalToScaledInt(raw, digits, name){
  const s=String(raw ?? '').trim();
  if(!/^\d+(?:\.\d{1,2})?$/.test(s)) fail(`Field ${name} requires a finite nonnegative number with a decimal point.`);
  const parts=s.split('.');
  const frac=(parts[1]||'').padEnd(digits,'0');
  if(frac.length>digits) fail(`Parameter ${name} allows at most ${digits} decimal places.`);
  return BigInt(parts[0])*10n**BigInt(digits)+BigInt(frac||'0');
}
function intStrict(raw,name,min,max){
  const s=String(raw ?? '').trim();
  if(!/^\d+$/.test(s)) fail(`${name} must be an integer from ${min} to ${max} mm.`);
  const n=BigInt(s);
  if(n<BigInt(min)||n>BigInt(max)) fail(`${name} must be an integer from ${min} to ${max} mm.`);
  return n;
}
function ceilDiv(n,d){ return (n+d-1n)/d; }
function roundRationalTo2(n,d){
  // Half-up to 2 decimal places.
  const scaled=n*100n;
  return (scaled*2n + d)/(2n*d);
}
function fmtScaled(v,digits){
  let s=v.toString();
  const neg=s.startsWith('-'); if(neg) s=s.slice(1);
  s=s.padStart(digits+1,'0');
  const whole=s.slice(0,-digits)||'0', frac=s.slice(-digits);
  return (neg?'-':'')+whole+'.'+frac;
}
function parseCsv(text){
  const lines=String(text).replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim()!=='');
  if(!lines.length) fail("Input CSV is empty.");
  if(lines[0].trim()!=='parameter,value,unit') fail("CSV header must have exactly three columns: parameter,value,unit.");
  const rows=[];
  for(let i=1;i<lines.length;i++){
    const parts=lines[i].split(',');
    if(parts.length!==3) fail(`Row ${i+1}: expected three comma-separated values.`);
    rows.push({parameter:parts[0].trim(), value:parts[1].trim(), unit:parts[2].trim()});
  }
  return rows;
}
function parseRows(rows){
  const values={};
  rows.forEach((row,idx)=>{
    const name=(row.parameter||'').trim(), value=(row.value||'').trim(), unit=(row.unit||'').trim();
    if(!(name in EXPECTED_UNITS)) fail(`Row ${idx+2}: unknown parameter ${name||"(blank)"}.`);
    if(name in values) fail(`Parameter ${name} is specified more than once.`);
    if(unit!==EXPECTED_UNITS[name]) fail(`Parameter ${name} uses unit ${unit||"(blank)"}, expected ${EXPECTED_UNITS[name]}.`);
    values[name]=value;
  });
  const missing=Object.keys(EXPECTED_UNITS).filter(k=>!(k in values));
  if(missing.length) fail("Missing required parameters: "+missing.join(', ')+'.');
  const L=intStrict(values.room_length,"Length",1,100000);
  const W=intStrict(values.room_width,"Width",1,100000);
  const reserve=decimalToScaledInt(values.reserve,2,'reserve');
  if(reserve<0n||reserve>10000n) fail("Allowance must be between 0 and 100 percent.");
  const packArea=decimalToScaledInt(values.package_area,2,'package_area');
  if(packArea<1n||packArea>10000n) fail("Package coverage must be between 0.01 and 100.00 m2.");
  const price=decimalToScaledInt(values.package_price,2,'package_price');
  if(price<1n||price>100000000n) fail("Package price must be between CHF 0.01 and CHF 1000000.00.");
  return {L,W,reserve,packArea,price,raw:values};
}
function calculate(req){
  const roomNum=req.L*req.W, roomDen=1000000n;
  const requiredNum=roomNum*(10000n+req.reserve), requiredDen=roomDen*10000n;
  const packRatioNum=requiredNum*100n, packRatioDen=requiredDen*req.packArea;
  const packs=ceilDiv(packRatioNum,packRatioDen);
  const purchasedHundredths=packs*req.packArea;
  const surplusNum=purchasedHundredths*requiredDen-requiredNum*100n;
  const surplusDen=100n*requiredDen;
  return {
    room2:roundRationalTo2(roomNum,roomDen),
    required2:roundRationalTo2(requiredNum,requiredDen),
    packs,
    purchased2:purchasedHundredths,
    surplus2:roundRationalTo2(surplusNum,surplusDen),
    totalCents:packs*req.price
  };
}
function render(req,res){
  const reserve2=fmtScaled(req.reserve,2), pa2=fmtScaled(req.packArea,2), price2=fmtScaled(req.price,2);
  return [
    "Flooring calculation — practice example",
    'Status: COMPLETE','',
    `Dimensions: ${req.L} mm x ${req.W} mm`,
    `Allowance: ${reserve2} %`,
    `Room area: ${fmtScaled(res.room2,2)} m2`,
    `Area with allowance: ${fmtScaled(res.required2,2)} m2`,
    `Package: ${pa2} m2`,
    `Packages: ceil(${fmtScaled(res.required2,2)} / ${pa2}) = ${res.packs}`,
    `Purchased area: ${fmtScaled(res.purchased2,2)} m2`,
    `Excess over requirement including allowance: ${fmtScaled(res.surplus2,2)} m2`,
    `Package price: CHF ${price2}`,
    `Estimated amount: CHF ${fmtScaled(res.totalCents,2)}`,'',
    "Price taken from input. Tax, delivery, and discounts not recalculated."
  ].join('\n');
}
function runCsv(text){
  try { const req=parseRows(parseCsv(text)); const res=calculate(req); return {status:'COMPLETE', report:render(req,res), req,res}; }
  catch(e){ if(e.name!=='CalculationInputError') throw e; return {status:'ERROR', report:["Flooring calculation — practice example",'Status: ERROR',`Reason: ${e.message}`,"Result not calculated."].join('\n'), error:e.message}; }
}
global.MaterialCalculator={parseCsv,parseRows,calculate,render,runCsv,fmtScaled};
})(typeof window!=='undefined'?window:globalThis);
