---
name: material-estimate
description: Collects inputs for a practice estimate of flooring package quantity and cost.
---

# Estimating flooring package quantity and cost

Use only for rectangular rooms and material sold in packages with specified coverage.

## Required inputs

Collect all five quantities:

- room length in whole millimeters;
- room width in whole millimeters;
- allowance percentage chosen by the user or a confirmed rule;
- coverage per package in square meters;
- price per package in CHF.

Ask about missing values. Do not infer allowance from “usual,” “small,” or “just in case.” Do not invent or look up package coverage, price, tax, discounts, or exchange rates. For other units, ask the user to explicitly convert dimensions to millimeters and confirm the conversion.

## Practice tool limits

- length and width: integers from 1 to 100000 mm;
- allowance: 0 to 100 percent;
- coverage: 0.01 to 100.00 m2;
- package price: CHF 0.01 to CHF 1000000.00.

On a tool error, do not guess corrected inputs. Identify the field needing clarification.

## Execution

If calculate_material is actually connected in this environment, pass inputs in its schema. Do not replace the call with a mental estimate of package count.

If calculate_material is unavailable, explicitly state it did not run in this conversation. Suggest the package’s local calculator or a formula for manual checking. Do not claim to have read or run a computer file.

## Presenting results

Check that the tool returned COMPLETE. State dimensions, allowance, area with allowance, package coverage, whole-package count, and user-supplied price. Explain rounding up.

Cost multiplies the entered price by package count. Tax, delivery, discounts, actual waste, availability, and allowance suitability were not checked unless a separate connected tool did so.

For ERROR or NOT_RUN, do not present a computed number as the result. Distinguish report facts from possible explanations.
