CALCULATION PLUGIN PACKAGING EXAMPLE

This package contains Skill instructions and an illustrative calculate_material function contract.
It demonstrates architecture. It does not connect Python to ChatGPT
or itself run code on the reader’s computer.

A real connection requires a technical specialist to:
1. Implement the function using tools/tool_contract.json fields.
2. Connect it to a supported environment.
3. Confirm the program, not a text model, performs calculations.
4. Limit permissions to transfer only calculation parameters.
5. Run reference tests before use.

If unavailable, the Skill must state that the local script did not run
and direct the user to project/run_calculation.bat.
