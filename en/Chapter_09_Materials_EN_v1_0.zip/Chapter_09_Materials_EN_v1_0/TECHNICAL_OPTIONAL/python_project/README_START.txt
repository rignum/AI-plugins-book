CHAPTER 9. FLOORING CALCULATION

WHAT THE EXAMPLE DOES
The calculator finds rectangular room area, adds the specified allowance,
rounds package count up, and multiplies by the entered package price.
This is a practice estimate. Tax, delivery, discounts, and installation-specific waste
are not calculated.

FIRST RUN
1. Confirm the package is extracted.
2. Open input.csv in Notepad.
3. Change only numbers in value. Do not change parameter names or units.
4. Save as comma-delimited CSV with decimal points.
5. Double-click run_calculation.bat.
6. Read reports/last_calculation.txt in Notepad.

Reference for the original file: 10 packages and CHF 385.00.
No external Python packages or internet connection needed.

REFERENCE TESTS
Double-click run_tests.bat. Results open from reports/last_tests.txt.
PASS concerns only this practice example’s prepared tests.

IF EXECUTION IS UNAVAILABLE
NOT_RUN means the program or tests did not run.
Do not change security settings or install software without organizational
permission. Use the reference examples in materials.
