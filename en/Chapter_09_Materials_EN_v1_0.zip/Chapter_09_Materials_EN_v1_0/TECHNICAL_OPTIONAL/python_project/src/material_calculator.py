"""Deterministic calculator for floor-covering packs in the Chapter 9 example."""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_HALF_UP
from pathlib import Path


class CalculationInputError(ValueError):
    """Raised when the supplied values do not follow the exercise rules."""


EXPECTED_UNITS = {
    "room_length": "mm",
    "room_width": "mm",
    "reserve": "%",
    "package_area": "m2",
    "package_price": "CHF/package",
}

MAX_DECIMAL_PLACES = {
    "reserve": 2,
    "package_area": 2,
    "package_price": 2,
}


@dataclass(frozen=True)
class CalculationRequest:
    room_length_mm: int
    room_width_mm: int
    reserve_percent: Decimal
    package_area_m2: Decimal
    package_price_chf: Decimal


@dataclass(frozen=True)
class CalculationResult:
    room_area_m2: Decimal
    required_area_m2: Decimal
    package_count: int
    purchased_area_m2: Decimal
    surplus_area_m2: Decimal
    total_price_chf: Decimal


def _parse_decimal(value: str, name: str) -> Decimal:
    try:
        parsed = Decimal(value.strip())
    except (InvalidOperation, AttributeError):
        raise CalculationInputError(
            f"Field {name} requires a finite number with a decimal point."
        )
    if not parsed.is_finite():
        raise CalculationInputError(f"Field {name} NaN and infinity are not allowed.")
    return parsed


def _decimal_places(value: Decimal) -> int:
    return max(0, -value.as_tuple().exponent)


def parse_input_rows(rows: list[dict[str, str]]) -> CalculationRequest:
    values: dict[str, Decimal] = {}

    for row_number, row in enumerate(rows, start=2):
        name = (row.get("parameter") or "").strip()
        raw_value = (row.get("value") or "").strip()
        unit = (row.get("unit") or "").strip()

        if not name and not raw_value and not unit:
            continue
        if name not in EXPECTED_UNITS:
            raise CalculationInputError(
                f"Row {row_number}: unknown parameter {name or '(blank)'}."
            )
        if name in values:
            raise CalculationInputError(f"Parameter {name} is specified more than once.")

        expected_unit = EXPECTED_UNITS[name]
        if unit != expected_unit:
            raise CalculationInputError(
                f"Parameter {name} uses unit {unit or '(blank)'}, "
                f"expected {expected_unit}."
            )

        value = _parse_decimal(raw_value, name)
        if name in MAX_DECIMAL_PLACES and _decimal_places(value) > MAX_DECIMAL_PLACES[name]:
            limit = MAX_DECIMAL_PLACES[name]
            raise CalculationInputError(
                f"Parameter {name} allows at most {limit} decimal places."
            )
        values[name] = value

    missing = [name for name in EXPECTED_UNITS if name not in values]
    if missing:
        raise CalculationInputError(
            'Missing required parameters: ' + ", ".join(missing) + "."
        )

    length = values["room_length"]
    width = values["room_width"]
    if length != length.to_integral_value() or not Decimal("1") <= length <= Decimal("100000"):
        raise CalculationInputError('Length must be an integer from 1 to 100000 mm.')
    if width != width.to_integral_value() or not Decimal("1") <= width <= Decimal("100000"):
        raise CalculationInputError('Width must be an integer from 1 to 100000 mm.')

    reserve = values["reserve"]
    if not Decimal("0") <= reserve <= Decimal("100"):
        raise CalculationInputError('Allowance must be between 0 and 100 percent.')

    package_area = values["package_area"]
    if not Decimal("0.01") <= package_area <= Decimal("100.00"):
        raise CalculationInputError('Package coverage must be between 0.01 and 100.00 m2.')

    package_price = values["package_price"]
    if not Decimal("0.01") <= package_price <= Decimal("1000000.00"):
        raise CalculationInputError('Package price must be between CHF 0.01 and CHF 1000000.00.')

    return CalculationRequest(
        room_length_mm=int(length),
        room_width_mm=int(width),
        reserve_percent=reserve,
        package_area_m2=package_area,
        package_price_chf=package_price,
    )


def read_request(path: Path) -> CalculationRequest:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as source:
            reader = csv.DictReader(source)
            if reader.fieldnames != ["parameter", "value", "unit"]:
                raise CalculationInputError(
                    'CSV header must have exactly three columns: parameter,value,unit.'
                )
            return parse_input_rows(list(reader))
    except OSError as exc:
        raise CalculationInputError(f"Could not read input file: {exc}.")


def calculate(request: CalculationRequest) -> CalculationResult:
    length_m = Decimal(request.room_length_mm) / Decimal("1000")
    width_m = Decimal(request.room_width_mm) / Decimal("1000")
    room_area = length_m * width_m
    required_area = room_area * (
        Decimal("1") + request.reserve_percent / Decimal("100")
    )

    exact_pack_count = required_area / request.package_area_m2
    package_count = int(exact_pack_count.to_integral_value(rounding=ROUND_CEILING))
    purchased_area = Decimal(package_count) * request.package_area_m2
    surplus_area = purchased_area - required_area
    total_price = Decimal(package_count) * request.package_price_chf

    return CalculationResult(
        room_area_m2=room_area,
        required_area_m2=required_area,
        package_count=package_count,
        purchased_area_m2=purchased_area,
        surplus_area_m2=surplus_area,
        total_price_chf=total_price,
    )


def _display(value: Decimal) -> str:
    return str(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def render_report(request: CalculationRequest, result: CalculationResult) -> str:
    return "\n".join(
        [
            'Flooring calculation — practice example',
            "Status: COMPLETE",
            "",
            f"Dimensions: {request.room_length_mm} mm x {request.room_width_mm} mm",
            f"Allowance: {_display(request.reserve_percent)} %",
            f"Room area: {_display(result.room_area_m2)} m2",
            f"Area with allowance: {_display(result.required_area_m2)} m2",
            f"Package: {_display(request.package_area_m2)} m2",
            (
                'Packages: ceil('
                f"{_display(result.required_area_m2)} / "
                f"{_display(request.package_area_m2)}) = {result.package_count}"
            ),
            f"Purchased area: {_display(result.purchased_area_m2)} m2",
            f"Excess over requirement including allowance: {_display(result.surplus_area_m2)} m2",
            f"Package price: CHF {_display(request.package_price_chf)}",
            f"Estimated amount: CHF {_display(result.total_price_chf)}",
            "",
            'Price taken from input. Tax, delivery, and discounts not recalculated.',
        ]
    )


def main() -> int:
    parser = argparse.ArgumentParser(description='Practice flooring package calculation.')
    parser.add_argument("input_file", type=Path)
    parser.add_argument("report_file", type=Path)
    args = parser.parse_args()

    try:
        request = read_request(args.input_file)
        result = calculate(request)
        report = render_report(request, result)
        status = 0
    except CalculationInputError as exc:
        report = "\n".join(
            [
                'Flooring calculation — practice example',
                "Status: ERROR",
                f"Reason: {exc}",
                'Result not calculated.',
            ]
        )
        status = 2

    args.report_file.parent.mkdir(parents=True, exist_ok=True)
    args.report_file.write_text(report + "\n", encoding="utf-8-sig")
    return status


if __name__ == "__main__":
    raise SystemExit(main())
