TECHNICAL EXTENSION

This folder is not needed for the main exercise.
This contains the original Python calculator, 13 automated tests, Skill instructions, and an illustrative calculate_material contract.

To reproduce technical execution, read python_project/README_START.txt first. Do not install software or change work-computer security policy without organizational permission.
