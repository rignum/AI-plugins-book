PRACTICE PROJECT: catalog image set

Purpose
Create images measuring 800 × 600 according to the rules in
data/catalog_manifest.csv. In this exercise, JPEG is saved at quality 88 with a
white background; transparent PNG remains transparent. All rules are specified in the table.

Safe file handling
- Sources are in input_images and are read only.
- Results are written separately to output/catalog.
- The script does not delete or replace sources.
- On repeat runs, only files with output names from the
  manifest and the local report inside output/catalog are overwritten.
- The script does not send files to the Internet or access AI models.

Running the project
1. If necessary, install Pillow once from an approved source:
   py -3 -m pip install -r requirements.txt
2. Run run_preview.bat and check output/catalog/processing_preview.csv.
3. If the source, name, dimensions, placement method, and format are correct,
   separately run run_catalog.bat.
4. Check output/catalog/processing_report.csv and the images themselves.
5. Run run_tests.bat.

Formats and padding rule
- JPEG requires an opaque background. The manifest specifies #FFFFFF.
- PNG can preserve a transparent background; transparent is selected for the mug file.
- fit=pad scales the image proportionally and centers it on the canvas.
- fit=crop crops the excess; fit=stretch changes proportions. These two modes are reserved
  for a separate comparison illustration; the main manifest uses pad.
- EXIF orientation is applied before resizing; EXIF is not copied to the result.
- This exercise does not perform color correction using an ICC profile and does not promise
  complete removal of every possible type of metadata. Color-critical print products
  must be prepared according to a separate color standard.

Dependencies: Python 3.10 or later and Pillow 12.3.0.
