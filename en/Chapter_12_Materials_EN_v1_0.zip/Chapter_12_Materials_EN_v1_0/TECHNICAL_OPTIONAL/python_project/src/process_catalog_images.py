"""Prepare a catalog image set from an explicit CSV manifest.

The script uses local CPU image operations only. It does not call ChatGPT,
external models, or network services, and it never writes into the source folder.
"""

import argparse
import csv
import hashlib
import json
import re
import sys
from pathlib import Path

from PIL import Image, ImageOps


ROOT = Path(__file__).resolve().parents[1]
REQUIRED_COLUMNS = {
    "source_file", "output_file", "width", "height", "fit", "format",
    "quality", "background",
}
ALLOWED_SOURCE_EXTENSIONS = {".jpg", ".jpeg", ".png"}
MAX_SOURCE_PIXELS = 25_000_000
MAX_TARGET_SIDE = 5_000
HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")
REPORT_COLUMNS = [
    "status", "source_file", "output_file", "source_size", "oriented_size",
    "target_size", "fit", "format", "quality", "source_had_alpha",
    "output_has_alpha", "exif_orientation", "exif_removed", "output_bytes",
    "message",
]
PREVIEW_COLUMNS = [
    "status", "source_file", "output_file", "source_size", "oriented_size",
    "target_size", "fit", "format", "quality", "background",
    "source_has_transparency", "exif_orientation", "message",
]


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_color(value):
    value = (value or "").strip()
    if value.lower() == "transparent":
        return None
    if not HEX_COLOR.fullmatch(value):
        raise ValueError('Background must be the word transparent or a #RRGGBB color')
    return tuple(int(value[index:index + 2], 16) for index in (1, 3, 5))


def contained_size(source_size, target_size):
    source_width, source_height = source_size
    target_width, target_height = target_size
    if min(source_width, source_height, target_width, target_height) <= 0:
        raise ValueError('Width and height must be positive')
    scale = min(target_width / source_width, target_height / source_height)
    return (
        max(1, round(source_width * scale)),
        max(1, round(source_height * scale)),
    )


def fit_image(image, target_size, strategy="pad", background=(255, 255, 255)):
    """Return an RGBA image using stretch, center crop, or contain-and-pad."""
    image = image.convert("RGBA")
    target_width, target_height = target_size
    if strategy == "stretch":
        return image.resize(target_size, Image.Resampling.LANCZOS)
    if strategy == "crop":
        scale = max(target_width / image.width, target_height / image.height)
        size = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
        resized = image.resize(size, Image.Resampling.LANCZOS)
        left = (resized.width - target_width) // 2
        top = (resized.height - target_height) // 2
        return resized.crop((left, top, left + target_width, top + target_height))
    if strategy == "pad":
        size = contained_size(image.size, target_size)
        resized = image.resize(size, Image.Resampling.LANCZOS)
        if background is None:
            canvas = Image.new("RGBA", target_size, (0, 0, 0, 0))
        else:
            canvas = Image.new("RGBA", target_size, (*background, 255))
        left = (target_width - resized.width) // 2
        top = (target_height - resized.height) // 2
        canvas.alpha_composite(resized, (left, top))
        return canvas
    raise ValueError(f"Unknown placement method: {strategy}")


def validate_manifest(path):
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = set(reader.fieldnames or [])
        missing = REQUIRED_COLUMNS - columns
        if missing:
            raise ValueError('The table is missing columns: ' + ", ".join(sorted(missing)))
        rows = list(reader)

    if not rows:
        raise ValueError('The table contains no images')

    seen_outputs = set()
    clean_rows = []
    for line_number, raw in enumerate(rows, start=2):
        row = {key: (value or "").strip() for key, value in raw.items()}
        source = row["source_file"]
        output = row["output_file"]
        if not source or Path(source).name != source or Path(source).suffix.lower() not in ALLOWED_SOURCE_EXTENSIONS:
            raise ValueError(f"Row {line_number}: specify a PNG or JPEG filename without a folder path")
        if not output or Path(output).name != output:
            raise ValueError(f"Row {line_number}: the output name must be a filename without a path")
        output_key = output.casefold()
        if output_key in seen_outputs:
            raise ValueError(f"Row {line_number}: duplicate output name")
        seen_outputs.add(output_key)

        try:
            width = int(row["width"])
            height = int(row["height"])
        except ValueError as exc:
            raise ValueError(f"Row {line_number}: width and height must be integers") from exc
        if min(width, height) <= 0 or max(width, height) > MAX_TARGET_SIDE:
            raise ValueError(f"Row {line_number}: allowed dimensions are 1 to {MAX_TARGET_SIDE} pixels per side")
        if row["fit"] not in {"pad", "crop", "stretch"}:
            raise ValueError(f"Row {line_number}: method must be pad, crop, or stretch")

        fmt = row["format"].upper()
        extension = Path(output).suffix.lower()
        if fmt == "JPEG":
            if extension not in {".jpg", ".jpeg"}:
                raise ValueError(f"Row {line_number}: JPEG requires the .jpg or .jpeg extension")
            try:
                quality = int(row["quality"])
            except ValueError as exc:
                raise ValueError(f"Row {line_number}: specify JPEG quality from 1 to 95") from exc
            if not 1 <= quality <= 95:
                raise ValueError(f"Row {line_number}: specify JPEG quality from 1 to 95")
            background = parse_color(row["background"])
            if background is None:
                raise ValueError(f"Row {line_number}: JPEG does not preserve transparency; specify a background color")
        elif fmt == "PNG":
            if extension != ".png":
                raise ValueError(f"Row {line_number}: PNG requires the .png extension")
            if row["quality"]:
                raise ValueError(f"Row {line_number}: leave the quality field blank for PNG in this exercise")
            background = parse_color(row["background"])
            quality = ""
        else:
            raise ValueError(f"Row {line_number}: this exercise supports only JPEG and PNG")

        row.update({"width": width, "height": height, "format": fmt,
                    "quality_value": quality, "background_rgb": background})
        clean_rows.append(row)
    return clean_rows


def process_one(source_path, row, target_path):
    with Image.open(source_path) as opened:
        source_size = opened.size
        if opened.width * opened.height > MAX_SOURCE_PIXELS:
            raise ValueError(f"Source exceeds the exercise limit of {MAX_SOURCE_PIXELS:,} pixels")
        orientation = opened.getexif().get(274, 1)
        if opened.mode not in {"1", "L", "LA", "P", "RGB", "RGBA"}:
            raise ValueError(f"Color mode {opened.mode} is outside the scope of this exercise; prepare RGB or RGBA first")
        original_has_alpha = (
            "A" in opened.getbands()
            or "transparency" in opened.info
        )
        icc_profile = opened.info.get("icc_profile")
        oriented = ImageOps.exif_transpose(opened)
        oriented_size = oriented.size
        rgba = oriented.convert("RGBA")
        has_visible_transparency = rgba.getchannel("A").getextrema()[0] < 255

    background = row["background_rgb"]
    framed = fit_image(
        rgba,
        (row["width"], row["height"]),
        row["fit"],
        background,
    )

    if row["format"] == "JPEG":
        if background is None:
            raise ValueError('JPEG requires an opaque background')
        base = Image.new("RGBA", framed.size, (*background, 255))
        base.alpha_composite(framed)
        output = base.convert("RGB")
        output.save(
            target_path,
            format="JPEG",
            quality=row["quality_value"],
            optimize=True,
            exif=b"",
            icc_profile=icc_profile,
        )
        output_has_alpha = False
    else:
        if background is None:
            output = framed
        else:
            base = Image.new("RGBA", framed.size, (*background, 255))
            base.alpha_composite(framed)
            output = base.convert("RGB")
        output.save(
            target_path,
            format="PNG",
            optimize=True,
            icc_profile=icc_profile,
        )
        output_has_alpha = "A" in output.getbands()

    return {
        "source_size": f"{source_size[0]}x{source_size[1]}",
        "oriented_size": f"{oriented_size[0]}x{oriented_size[1]}",
        "source_had_alpha": "yes" if has_visible_transparency else "no",
        "output_has_alpha": "yes" if output_has_alpha else "no",
        "exif_orientation": orientation,
        "exif_removed": "yes",
    }


def process_catalog(manifest, input_dir, output_dir):
    manifest = Path(manifest)
    input_dir = Path(input_dir).resolve()
    output_dir = Path(output_dir).resolve()
    if not input_dir.is_dir():
        raise ValueError(f"Source folder not found: {input_dir}")
    if output_dir == input_dir or output_dir.is_relative_to(input_dir):
        raise ValueError('The output folder must be separate from the originals')

    rows = validate_manifest(manifest)
    output_dir.mkdir(parents=True, exist_ok=True)
    reports = []
    for row in rows:
        source_path = input_dir / row["source_file"]
        target_path = output_dir / row["output_file"]
        report = {
            "status": "ERROR",
            "source_file": row["source_file"],
            "output_file": row["output_file"],
            "target_size": f"{row['width']}x{row['height']}",
            "fit": row["fit"],
            "format": row["format"],
            "quality": row["quality_value"],
            "output_bytes": "",
            "message": "",
        }
        try:
            if not source_path.is_file():
                raise FileNotFoundError('Source file not found')
            details = process_one(source_path, row, target_path)
            report.update(details)
            report["output_bytes"] = target_path.stat().st_size
            report["status"] = "OK"
            report["message"] = 'Processed according to the rule in the table'
        except Exception as exc:  # each row is reported; no silent skipping
            if target_path.exists():
                target_path.unlink()
            report["message"] = f"{type(exc).__name__}: {exc}"
        reports.append(report)

    report_path = output_dir / "processing_report.csv"
    with report_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=REPORT_COLUMNS)
        writer.writeheader()
        writer.writerows(reports)
    ok_count = sum(row["status"] == "OK" for row in reports)
    summary = {
        "mode": "LOCAL_IMAGE_PROCESSING_ONLY",
        "processed": ok_count,
        "errors": len(reports) - ok_count,
        "report": str(report_path),
        "network_requests_sent": 0,
    }
    (output_dir / "run_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return summary, reports


def preview_catalog(manifest, input_dir, output_dir):
    """Validate the manifest and source headers without writing image files."""
    manifest = Path(manifest)
    input_dir = Path(input_dir).resolve()
    output_dir = Path(output_dir).resolve()
    if not input_dir.is_dir():
        raise ValueError(f"Source folder not found: {input_dir}")
    if output_dir == input_dir or output_dir.is_relative_to(input_dir):
        raise ValueError('The output folder must be separate from the originals')
    rows = validate_manifest(manifest)
    output_dir.mkdir(parents=True, exist_ok=True)
    preview_rows = []
    for row in rows:
        record = {
            "status": "ERROR", "source_file": row["source_file"],
            "output_file": row["output_file"],
            "target_size": f"{row['width']}x{row['height']}",
            "fit": row["fit"], "format": row["format"],
            "quality": row["quality_value"],
            "background": row["background"],
            "source_size": "", "oriented_size": "",
            "source_has_transparency": "", "exif_orientation": "",
            "message": "",
        }
        try:
            source_path = input_dir / row["source_file"]
            if not source_path.is_file():
                raise FileNotFoundError('Source file not found')
            with Image.open(source_path) as opened:
                if opened.width * opened.height > MAX_SOURCE_PIXELS:
                    raise ValueError(f"Source exceeds the exercise limit of {MAX_SOURCE_PIXELS:,} pixels")
                if opened.mode not in {"1", "L", "LA", "P", "RGB", "RGBA"}:
                    raise ValueError(f"Color mode {opened.mode} is outside the scope of this exercise")
                record["source_size"] = f"{opened.width}x{opened.height}"
                record["exif_orientation"] = opened.getexif().get(274, 1)
                transparent = "A" in opened.getbands() or "transparency" in opened.info
                record["source_has_transparency"] = "yes" if transparent else "no"
                corrected = ImageOps.exif_transpose(opened)
                record["oriented_size"] = f"{corrected.width}x{corrected.height}"
            record["status"] = "READY"
            record["message"] = 'Rules and source passed the preliminary check'
        except Exception as exc:
            record["message"] = f"{type(exc).__name__}: {exc}"
        preview_rows.append(record)

    preview_path = output_dir / "processing_preview.csv"
    with preview_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=PREVIEW_COLUMNS)
        writer.writeheader()
        writer.writerows(preview_rows)
    ready = sum(row["status"] == "READY" for row in preview_rows)
    return {
        "mode": "LOCAL_PREVIEW_ONLY",
        "ready": ready,
        "errors": len(preview_rows) - ready,
        "report": str(preview_path),
        "network_requests_sent": 0,
    }, preview_rows


def main(argv=None):
    parser = argparse.ArgumentParser(description='Local catalog image preparation')
    parser.add_argument("--manifest", default="data/catalog_manifest.csv")
    parser.add_argument("--input-dir", default="input_images")
    parser.add_argument("--output-dir", default="output/catalog")
    parser.add_argument("--preview", action="store_true", help='check the plan and sources without processing')
    parser.add_argument("--confirm", action="store_true", help='confirm local processing')
    args = parser.parse_args(argv)
    if args.preview and args.confirm:
        parser.error('select either --preview or --confirm')
    if not args.preview and not args.confirm:
        print('First perform the preliminary check with --preview. To process after checking, specify --confirm.', file=sys.stderr)
        return 2
    try:
        if args.preview:
            summary, reports = preview_catalog(args.manifest, args.input_dir, args.output_dir)
        else:
            summary, reports = process_catalog(args.manifest, args.input_dir, args.output_dir)
    except Exception as exc:
        print(f"Preparation error: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    count = summary.get("processed", summary.get("ready", 0))
    print(f"Done: {count} of {len(reports)} images")
    print(f"Errors: {summary['errors']}")
    print(f"Report: {summary['report']}")
    print('Network requests: 0; originals are not changed.')
    return 0 if summary["errors"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
