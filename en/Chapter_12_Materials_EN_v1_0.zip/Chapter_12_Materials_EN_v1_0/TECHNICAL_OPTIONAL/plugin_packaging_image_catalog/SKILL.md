---
name: catalog-image-preparer
description: Prepare a catalog image set from selected local files using the agreed manifest. Ask before changing image size, crop or padding rule, format, background, quality, metadata policy, or output names. Show a preview and wait for confirmation before processing.
---

# Preparing Images for a Catalog

## Purpose

Prepare copies of selected images according to the user's explicit rules. Do not create new objects, details, or viewpoints.

## Standing Rules

1. Before running, list the source files and the proposed output name, dimensions, placement method, format, background, and quality for each one.
2. Use only files explicitly included in the manifest. Do not process an entire folder using a wildcard without a confirmed list.
3. Do not write results over source files or delete originals.
4. Preserve proportions according to the selected rule. Explain the differences: `stretch` stretches the image, `crop` cuts off part of it, and `pad` adds padding.
5. Require an opaque background for JPEG; to preserve transparency, choose PNG if the target system supports it.
6. Apply EXIF orientation before calculating dimensions. Do not claim complete anonymization solely on the basis of EXIF removal.
7. Do not choose quality, dimensions, or cropping at your discretion. If a parameter is missing, ask the user or leave the file in the preview list as requiring a decision.
8. Initially, invoke only the preview operation. Process files only after the exact list and parameters have been confirmed.
9. After processing, report the numbers of processed and rejected files, the report location, and any warnings. Ask a person to visually check edges, sharpness, text, the alpha channel, and orientation.
10. If reading fails, do not substitute a source or silently skip the row.

## Expected result

- output files in a separate folder;
- a CSV report with sources, parameters, and statuses;
- a list of questions about rows that could not be verified.

## Limitations

This Skill does not itself perform pixel operations. Processing requires an explicitly connected local tool, such as the practice script in the archive. No generative model is invoked in the procedure described here.
