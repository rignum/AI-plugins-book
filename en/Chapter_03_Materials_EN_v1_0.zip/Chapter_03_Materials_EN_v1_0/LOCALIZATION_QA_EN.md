# English localization QA — Chapter3

Review candidate; not a published download. Source author VALIDATION.txt records are translated historical records, not evidence of tests run in this localization session. Current actual tests are listed in BOOK02_PRACTICE_FUNCTIONAL_QA.csv and qa logs.

Scope: Separate local processing, APIs and external models; retain data boundaries and architecture alternatives.

No source files were changed. Machine-generated caches are omitted only as documented. No external service was invoked. For chapter13, four WebM remain Russian in-frame and block complete localization. Chapter15 reference paragraph3 mismatch remains open. Full-book visual and download-hosting checks are pending.
