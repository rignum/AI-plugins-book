Optional technical level

The main exercise can already be completed in a browser without installing software. This folder contains materials for a technical specialist:
- ffmpeg/—an example of reproducible command-line processing;
- plugin_packaging_media_editor/—a sample Skill and conceptual tool contract.

FFmpeg was checked separately before publication of the book. The commands assume that ffmpeg and ffprobe are installed and available in PATH. On a work computer, follow your organization's software installation policy.
