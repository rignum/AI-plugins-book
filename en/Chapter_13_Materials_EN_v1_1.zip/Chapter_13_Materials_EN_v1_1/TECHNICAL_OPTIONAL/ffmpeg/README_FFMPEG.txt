FFmpeg: technical workflow

The goal is to reproduce the same practice edit with a conventional media processor. These commands are not a required part of the chapter.

Main idea:
1. Take only the approved interval from each source.
2. Convert video to 640×360 at a uniform frame rate.
3. Reset video and audio timestamps to zero.
4. Join the segments in the approved order.
5. Add the prepared subtitles.
6. Export and check with ffprobe.

Do not replace prepared captions.vtt with automatic speech recognition: that is a separate task requiring separate text and synchronization checks.
