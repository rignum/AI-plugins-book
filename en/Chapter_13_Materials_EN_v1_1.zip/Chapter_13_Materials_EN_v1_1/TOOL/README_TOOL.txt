Local practice processor

Double-click video_editor.html to open it in a current version of Chromium/Chrome or another browser supporting MediaRecorder and canvas.captureStream. The page makes no network requests.

Main set: select the three files in INPUT/NORMAL/videos, edit_plan.csv, render_settings.json, and captions.vtt.
Click “Check plan” first. Export is available only with READY status.

The practice export runs in real time: an 8-second video takes approximately 8 seconds to assemble, plus a short technical pause between segments. Actual duration may differ by a few tenths of a second.
