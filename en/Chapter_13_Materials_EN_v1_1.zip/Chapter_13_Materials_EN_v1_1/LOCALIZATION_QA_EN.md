# English practice localization QA v1.1 — Chapter13

The three clips and reference video now have English frame titles. Original clip timing4.008s,120frames,640×360,30fps,VP8/Opus and original audio packets/PCM are preserved. The new English reference is8.008s /240frames. Actual HTML MAIN/SECOND exports and both invalid-plan rejections were tested offline. No generative model, paid service or upload was used. The accompanying probe JSON is an FFmpeg/Matroska-measured summary, not a claim that ffprobe was executed.

The original VALIDATION.txt contains historical author records, not current execution evidence. Current review reports are in the v1.1 review bundle. English hosting URLs are planned and unpublished; no KDP readiness is claimed.
