# Publication preparation skill (practice example)

Purpose: check the practice manuscript’s structure against supplied rules.

- Do not change meaning without separate approval.
- Use terms.csv as the source of preferred terms.
- Use requirements.json as the source of formatting rules.
- Use metadata.json only for publication details.
- Show a preliminary change list first.
- Require human visual review of the prepared DOCX/PDF.
