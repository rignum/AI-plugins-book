Technical route

prepare_manuscript.py demonstrates the same bounded OOXML operations: one heading style, termbase replacements, one link address, static contents, and core metadata. It is not a universal DOCX editor.

Example command:
python prepare_manuscript.py ../INPUT/manuscript_draft.docx ../INPUT/terms.csv ../INPUT/requirements.json ../INPUT/metadata.json prepared.docx report.csv
