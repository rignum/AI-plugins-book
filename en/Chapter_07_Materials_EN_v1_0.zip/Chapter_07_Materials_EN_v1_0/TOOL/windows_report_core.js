(function(root,factory){
 const api=factory(); if(typeof module==='object'&&module.exports) module.exports=api; root.WindowsReportTool=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
 const KNOWN=new Set(['COLLECTED','EMPTY','NOT_COLLECTED','ACCESS_DENIED','UNSUPPORTED','ERROR','PARTIAL']);
 function n(v){return typeof v==='number'&&Number.isFinite(v)}
 function fmt(v,d=1){return n(v)?v.toFixed(d):'—'}
 function pct(free,total){return total>0?free/total*100:null}
 function requireStatus(obj,name,issues){if(!obj||typeof obj!=='object'){issues.push(`missing section ${name}`);return null;} if(!KNOWN.has(obj.status)){issues.push(`section ${name}: unknown or missing status`);} return obj.status;}
 function analyze(data,name='report.json'){
   const r={filename:name,valid:true,issues:[],warnings:[],facts:[],signals:[],unknowns:[],statuses:{},disks:[],program_count:null,event_count:null};
   if(!data||typeof data!=='object'||Array.isArray(data)){r.valid=false;r.issues.push("JSON root must be an object");return r;}
   if(data.schema_version!=='1.0') r.warnings.push(`schema_version: expected 1.0, received ${data.schema_version??"unspecified"}`);
   if(data.is_fictional_example!==true) r.warnings.push("file is not marked as a fictional practice example");
   const sections=['system','storage','installed_programs','system_events','autostart','large_files'];
   for(const s of sections) r.statuses[s]=requireStatus(data[s],s,r.issues);
   const sys=data.system||{};
   if(r.statuses.system==='COLLECTED'){
     if(sys.os&&sys.os.caption) r.facts.push(`Windows: ${sys.os.caption}, ${sys.os.architecture||"architecture unspecified"}`);
     if(Array.isArray(sys.cpu)&&sys.cpu[0]) r.facts.push(`CPU: ${sys.cpu[0].name||"unspecified"}, cores ${sys.cpu[0].cores??'—'}, logical processors ${sys.cpu[0].logical_processors??'—'}`);
     if(sys.memory&&n(sys.memory.total_gb)) r.facts.push(`Memory: ${fmt(sys.memory.total_gb,1)} GB`);
   } else if(r.statuses.system) r.unknowns.push(`system: ${r.statuses.system}`);
   const st=data.storage||{};
   if(r.statuses.storage==='COLLECTED'){
     if(!Array.isArray(st.items)){r.issues.push("storage.items must be an array");}
     else for(const d of st.items){
       if(!d||!d.device||!n(d.total_gb)||!n(d.free_gb)||d.total_gb<=0){r.issues.push(`invalid disk record ${d&&d.device?d.device:"unnamed"}`);continue;}
       const p=pct(d.free_gb,d.total_gb); const attention=p<10||d.free_gb<30;
       const row={device:d.device,total_gb:d.total_gb,free_gb:d.free_gb,free_percent:p,attention}; r.disks.push(row);
       r.facts.push(`${d.device}: free ${fmt(d.free_gb,1)} GB of ${fmt(d.total_gb,1)} GB (${fmt(p,1)} %)`);
       if(attention) r.signals.push(`${d.device}: below the practice threshold “below 10 % OR below 30 GB”`);
       if(n(d.free_percent)&&Math.abs(d.free_percent-p)>0.2) r.warnings.push(`${d.device}: stored free_percent differs from recalculation`);
     }
   } else if(r.statuses.storage) r.unknowns.push(`storage: ${r.statuses.storage}`);
   const ip=data.installed_programs||{};
   if(r.statuses.installed_programs==='COLLECTED'){
     if(!Array.isArray(ip.items)){r.issues.push("installed_programs.items must be an array");}
     else {r.program_count=ip.items.length; r.facts.push(`Program registrations found: ${ip.items.length}; source is not a complete application list`);}
   } else if(r.statuses.installed_programs) r.unknowns.push(`installed_programs: ${r.statuses.installed_programs}`);
   const ev=data.system_events||{};
   if(r.statuses.system_events==='COLLECTED'||r.statuses.system_events==='PARTIAL'){
     if(!Array.isArray(ev.items)){r.issues.push("system_events.items must be an array");}
     else {r.event_count=ev.items.length; r.facts.push(`System events in the supplied sample: ${ev.items.length}`);}
     if(r.statuses.system_events==='PARTIAL'||ev.possibly_truncated===true) r.unknowns.push("system_events: sample is incomplete or possibly truncated");
   } else if(r.statuses.system_events==='EMPTY') r.unknowns.push("system_events: source checked, no records for the selected period; not “no problems”");
   else if(r.statuses.system_events) r.unknowns.push(`system_events: ${r.statuses.system_events}; source should not be considered fully checked`);
   for(const s of ['autostart','large_files']){
     const stt=r.statuses[s];
     if(stt&&stt!=='COLLECTED') r.unknowns.push(`${s}: ${stt}`);
   }
   if(r.issues.length) r.valid=false;
   return r;
 }
 function textSummary(r){
   const L=[]; L.push(`File: ${r.filename}`); L.push(`Structure status: ${r.valid?'OK':'INVALID'}`); L.push('');
   L.push("Section statuses:"); for(const [k,v] of Object.entries(r.statuses)) L.push(`- ${k}: ${v||"undetermined"}`); L.push('');
   L.push("Facts:"); (r.facts.length?r.facts:["no confirmed facts"]).forEach(x=>L.push('- '+x)); L.push('');
   L.push("Signals:"); (r.signals.length?r.signals:["no practice-threshold signals"]).forEach(x=>L.push('- '+x)); L.push('');
   L.push("Unknown/incomplete:"); (r.unknowns.length?r.unknowns:["no additional notes"]).forEach(x=>L.push('- '+x));
   if(r.warnings.length){L.push('');L.push("Warnings:");r.warnings.forEach(x=>L.push('- '+x));}
   if(r.issues.length){L.push('');L.push("Structural errors:");r.issues.forEach(x=>L.push('- '+x));}
   return L.join('\n');
 }
 return {analyze,textSummary,fmt};
});