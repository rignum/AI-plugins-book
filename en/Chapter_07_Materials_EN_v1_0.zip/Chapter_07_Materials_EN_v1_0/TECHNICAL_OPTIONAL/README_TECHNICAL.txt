TECHNICAL EXTENSION — CHAPTER 7

This folder is not needed for the main exercise.

Contents:
- Collect-WindowsReport.ps1 — bounded practice Windows-information reader;
- test_fixture.py — static fixture and prohibited-command checks;
- plugin_packaging_windows_health — sample Skill/plugin packaging;
- SOURCES.txt and VALIDATION.txt — technical sources and verification limits.

The main reader uses prepared JSON, the local browser viewer, and ChatGPT. PowerShell and Python are optional.

Collect locally only on a computer you are authorized to manage and where organizational rules permit it. Do not change Execution Policy or elevate privileges for this exercise. Review the resulting JSON before sharing it with external AI.
