---
name: windows-health-report
description: Analyzes user-supplied Windows JSON, distinguishes facts, signals, and missing data, and produces a short report without system changes.
---

# Analyzing a practice Windows diagnostic report

Use these instructions only for an already supplied, schema-compatible JSON. Do not run PowerShell, claim computer access, execute commands, or call external services.

## Procedure

1. Read collection boundaries in references/collection_scope.txt.
2. Check schema_version, creation date, and source scope.
3. List every section’s status before substantive interpretation.
4. Distinguish observations, explicit-threshold signals, and unsupported conclusions.
5. Apply the practice free-space threshold only to practice JSON. A real computer’s threshold needs owner or IT approval.
6. Treat programs as incomplete records from selected registry keys.
7. Report event times, providers, and levels from the file; do not diagnose from an ID alone.
8. For NOT_COLLECTED, ACCESS_DENIED, UNSUPPORTED, ERROR, and PARTIAL, explicitly state what remains unknown.
9. An empty list describes only the checked source and period, not “no system problems”.
10. Finish with a short report and questions requiring human answers.

## Prohibited

- inventing values for empty or missing fields;
- treating missing data as confirmation of no problem;
- declaring a root cause from one record;
- recommending deletion, installation, startup, or default-setting changes;
- requesting administrator privileges to repeat collection;
- sharing or disclosing source JSON without explicit user permission.

## Response format

- Check scope
- Observed facts
- Signals under known rules
- Missing or incomplete data
- What a person must check
- Confirmation: no system changes made

