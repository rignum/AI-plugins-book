# English localization QA — Chapter8

Review candidate; not a published download. Source author VALIDATION.txt records are translated historical records, not evidence of tests run in this localization session. Current actual tests are listed in BOOK02_PRACTICE_FUNCTIONAL_QA.csv and qa logs.

Scope: Distinguish FAIL/ERROR/NOT_RUN/zero tests; preserve intended failing exercise and passing answer key.

No source files were changed. Machine-generated caches are omitted only as documented. No external service was invoked. For chapter13, four WebM remain Russian in-frame and block complete localization. Chapter15 reference paragraph3 mismatch remains open. Full-book visual and download-hosting checks are pending.
