TECHNICAL EXTENSION — CHAPTER 8

This folder is not needed for the main exercise.

The main reader uses source files and saved INPUT reports, local TOOL/test_report_viewer.html, and ChatGPT. No Python installation is needed.

To reproduce the check yourself:
1. Use a separate practice copy of project_before.
2. Confirm that Python 3 is allowed on your computer/in your organization.
3. On Windows, use run_checks.bat if appropriate. It must run only this practice folder’s tests and save reports/last_check.txt.
4. Before correction, expect one FAIL and two ok results.
5. Compare closed with answer_key/office_queue.py or apply the minimal fix manually in a copy.
6. Repeat the same tests. Expect three ok results and final OK after correction.

Do not change security settings, Execution Policy, PATH, or administrator privileges for the exercise. Do not run unfamiliar external code. These files belong only to a fictional practice project.
