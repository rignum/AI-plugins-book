---
name: project-check-report
description: Interprets a small-project check log, separating facts, possible explanations, and unverified questions.
---

# Interpreting a project check report

Use only user-supplied files. Do not run commands, install dependencies, or edit source files.

## Review procedure

1. Find command, actual output, final status, and exit code. Flag anything missing that prevents confirmation of execution or outcome.
2. List identified tests; distinguish PASS/OK, FAIL, ERROR, skipped tests, and absent tests.
3. For FAIL, compare expected and actual values exactly as reported. Do not call the cause confirmed until comparing it with supplied code.
4. Distinguish environment failures (missing interpreter/dependency) from program test results.
5. Ran 0 tests means the project was not meaningfully checked.
6. If all visible tests passed, refer only to those tests and file versions. Do not promise a bug-free project.
7. Before recommending a change, identify its file and smallest necessary scope. Do not claim application or rechecking until the user supplies a new log.

## Response format

- Execution: confirmed / unconfirmed / not performed
- Report facts
- Failed checks and exact discrepancy
- Possible explanation supported by supplied code
- Unknown and unchecked items
- Next safe step

Do not present an expected report as an actual run on the user’s computer. Do not claim test execution without a command run in an available environment and its actual output.
