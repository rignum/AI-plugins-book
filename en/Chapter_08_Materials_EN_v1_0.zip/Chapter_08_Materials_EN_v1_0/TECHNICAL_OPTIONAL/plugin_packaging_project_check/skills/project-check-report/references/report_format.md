# Report-reading rules

- PASS or OK confirms only the successfully completed check described in the report.
- FAIL usually means expected and actual results differ.
- ERROR indicates an exception or obstacle during execution; establish the root cause from traceback and source.
- NOT_RUN means the check did not start, neither PASS nor FAIL.
- No discovered tests does not confirm program correctness.
