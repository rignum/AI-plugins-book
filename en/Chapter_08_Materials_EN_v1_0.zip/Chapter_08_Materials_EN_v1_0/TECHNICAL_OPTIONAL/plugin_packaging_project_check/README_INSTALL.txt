PRACTICE PACKAGE project-check-report

skills/project-check-report contains instructions for interpreting test reports. It neither runs code, installs libraries, nor changes project files.

In a Skill-capable environment, use its current installation method. Menu names and import rules can change. If the installed package is unavailable, copy SKILL.md into a separate conversation as permanent instructions.

Supply fresh inputs for each analysis: actual reports/last_check.txt, tests, and only the source needed to explain them. First confirm there are no work secrets or personal data.
