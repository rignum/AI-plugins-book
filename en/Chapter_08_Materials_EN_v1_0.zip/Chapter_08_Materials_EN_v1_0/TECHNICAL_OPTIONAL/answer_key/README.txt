Exercise answer key. One line in the closed branch changes:
counts["open"] += 1  ->  counts["closed"] += 1

Open this folder only after trying to find the error yourself.
