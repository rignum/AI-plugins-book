Practice project “Office request counter”

WHAT THE PROJECT DOES
count_requests counts requests with open and closed statuses.
Three supplied tests cover a mixed list, capitalization/spaces, and an empty list.

HOW TO RUN CHECKS
1. Confirm organizational permission to run practice Python files.
2. Open this folder in File Explorer.
3. Double-click run_checks.bat.
4. Read the full window output. The same record is saved to reports/last_check.txt.
5. After completion, press any key to close the window.

SOFTWARE AND DATA
Actual execution needs Python 3 available as python. No third-party packages.
Tests use only three short fictional records, with no network, documents, or databases.
run_checks.bat runs only this folder’s tests and creates/updates reports/last_check.txt.

ATTENTION
One defect is deliberate. The first report should show one failure and two successful tests.
Do not fix files before the first run; observe an actual test failure first.
