(function(root,factory){
 const api=factory(); if(typeof module==='object'&&module.exports) module.exports=api; root.TestReportTool=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
 function pick(text,re,group=1){const m=text.match(re);return m?m[group]:null}
 function analyze(text,name='report.txt'){
   const r={filename:name,command:null,declaredStatus:null,exitCode:null,ran:null,tests:[],failures:0,errors:0,overall:'UNKNOWN',evidence:[],warnings:[]};
   if(typeof text!=='string'||!text.trim()){r.overall='INVALID';r.warnings.push("empty report");return r;}
   r.command=pick(text,/^Command:\s*(.+)$/mi);
   r.declaredStatus=pick(text,/^Status:\s*(\S+)/mi);
   const ex=pick(text,/^Exit code:\s*(-?\d+)/mi); r.exitCode=ex===null?null:Number(ex);
   const rn=pick(text,/Ran\s+(\d+)\s+tests?/i); r.ran=rn===null?null:Number(rn);
   const lines=text.split(/\r?\n/);
   for(const line of lines){
     const m=line.match(/^(test_[^(\s]+).*\.\.\.\s+(ok|FAIL|ERROR|skipped.*)$/i);
     if(m) r.tests.push({name:m[1],status:m[2]});
   }
   r.failures=r.tests.filter(t=>/^FAIL$/i.test(t.status)).length;
   r.errors=r.tests.filter(t=>/^ERROR$/i.test(t.status)).length;
   if(r.declaredStatus==='NOT_RUN'){r.overall='NOT_RUN';r.warnings.push("command was not executed in this environment");}
   else if(r.ran===0){r.overall='NO_TESTS';r.warnings.push("0 tests found: code 0 and OK do not establish meaningful verification");}
   else if(r.errors>0||/FAILED\s*\(errors=/i.test(text)){r.overall='ERROR';}
   else if(r.failures>0||/FAILED\s*\(failures=/i.test(text)){r.overall='FAIL';}
   else if((r.ran??0)>0&&/\nOK\s*$/mi.test(text)&&r.exitCode===0){r.overall='PASS';}
   else if(r.declaredStatus==='PASS'&&(r.ran??0)>0){r.overall='PASS_WITH_LIMITED_EVIDENCE';r.warnings.push("PASS is present, but standard report evidence is incomplete");}
   if(r.command) r.evidence.push(`Command: ${r.command}`); else r.warnings.push("Command line missing");
   if(r.ran!==null) r.evidence.push(`Tests run: ${r.ran}`); else if(r.overall!=='NOT_RUN') r.warnings.push("Ran ... tests line missing");
   if(r.exitCode!==null) r.evidence.push(`Exit code: ${r.exitCode}`);
   if(r.tests.length) r.evidence.push(`Test rows recognized: ${r.tests.length}`);
   if(r.overall==='PASS') r.evidence.push("All recognized tests completed successfully in this report");
   if(r.overall==='FAIL') r.evidence.push("A check failed: expected and actual values differ");
   if(r.overall==='ERROR') r.evidence.push("ERROR: test did not reach its normal comparison");
   return r;
 }
 function summary(r){
   const L=[`File: ${r.filename}`,`Interpreted result: ${r.overall}`,`Stated status: ${r.declaredStatus||"unspecified"}`,`Tests run: ${r.ran===null?"not established":r.ran}`,`Exit code: ${r.exitCode===null?"unspecified":r.exitCode}`,''];
   L.push("Tests:"); (r.tests.length?r.tests:[{name:"no recognized rows",status:'—'}]).forEach(t=>L.push(`- ${t.name}: ${t.status}`));
   L.push('');L.push("Evidence:");(r.evidence.length?r.evidence:["none"]).forEach(x=>L.push('- '+x));
   if(r.warnings.length){L.push('');L.push("Warnings:");r.warnings.forEach(x=>L.push('- '+x));}
   return L.join('\n');
 }
 return {analyze,summary};
});