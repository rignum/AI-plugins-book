EXAMPLE SKILL PACKAGE FOR PREPARING AN OFFER DRAFT

Folder contents show the boundary between instructions and tools:
- skills/prepare-client-offer/SKILL.md — AI rules and questions for users;
- tools/tool_contract.json — example operations and fields;
- plugin.json — practice package index for the book.

This directory is not by itself an installable plugin for a particular
ChatGPT version. It has no active CRM, warehouse, or store connections.
Do not load confidential client data into the practice project.

In a supported environment, a developer separately implements catalog search,
inventory reading, and draft preparation. Configure the data source,
authentication, and minimum permissions. The baseline allows only reading
and creating a local report. Request creation, client changes, and
reservation are outside the contract.

Do not put secret access keys in a Skill. Secrets belong in the configured
environment, not prompts or CSVs. Before enabling any write,
a specialist checks current provider documentation, permissions, and confirmations.
