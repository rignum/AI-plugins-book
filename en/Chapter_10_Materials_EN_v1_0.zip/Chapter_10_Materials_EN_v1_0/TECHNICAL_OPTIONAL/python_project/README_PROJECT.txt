PRACTICE OFFER-DRAFT PROJECT

data/catalog.csv — practice product and price catalog.
data/inventory.csv — one practice warehouse; stock and reservations per SKU.
data/customer_request.csv — client request without personal data.
data/match_decisions.csv — explicit request-to-catalog match decisions.
data/snapshot.json — snapshot/check times and permitted age.
data/snapshot_stale.json — same scenario with deliberately stale stock.
src/prepare_offer.py — deterministic validation and draft calculation.
tests/test_offer.py — ten positive and negative checks.
run_offer.bat — normal practice report.
run_stale_snapshot.bat — stale-snapshot scenario.
examples/second_request/ — second example, same rules, new request number.
run_second_offer.bat — draft for another request.
run_tests.bat — automated checks.
reports/ — text and JSON output location.

Product-name matching is separate from arithmetic. The script accepts
only explicit MATCHED with SKU, AMBIGUOUS with candidates, or NOT_FOUND.
It does not infer names from free text.

Availability rule for this practice file only:
available = on_hand − reserved.
Real CRMs/stores may have more complex states and multiple locations.
Check the particular system’s data model before adapting.
