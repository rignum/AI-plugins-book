CHAPTER 10. FIRST PRACTICE OFFER RUN

All names, prices, requests, and inventory are fictional.
No connection to a store, CRM, warehouse, internet, or payment system.
Scripts create no order and reserve no stock.

Requirements:
- extract into a separate folder;
- Windows 10 or 11;
- installed Python 3 available as python or py -3.
No third-party libraries. If scripts are prohibited by organizational rules,
do not bypass the rule; read the report in materials.

Normal practice run:
1. Without changing files, double-click run_offer.bat.
2. Open reports/last_offer.txt.
3. Compare with ../materials/EXPECTED_OFFER.txt.
4. Read line statuses: in draft, no available stock,
   clarification needed, or no match.
5. Confirm “Order created: no” and
   “Quantity reserved for client: no”.

Stale-snapshot check:
1. Double-click run_stale_snapshot.bat.
2. Open reports/stale_offer.txt.
3. Compare with ../materials/EXPECTED_STALE_OFFER.txt.
4. Stale snapshots produce no totals.

Another request:
1. Double-click run_second_offer.bat.
2. Open reports/second_offer.txt.
3. Compare with ../materials/EXPECTED_SECOND_OFFER.txt in the archive.
4. Confirm a new practice draft number and unchanged rules.

Automated checks:
- double-click run_tests.bat;
- expect ten passing tests.

Do not use your own data on the first attempt.
Before editing CSVs, keep original practice copies. Change only
agreed fields. Do not resave a CSV in a spreadsheet application
without checking UTF-8, headers, and comma delimiter were retained.

Every price retains its catalog currency. CHF and EUR are separate.
No combined total without an approved exchange rate and rule.
Tax, discounts, delivery, price validity, and legal terms are not calculated.
