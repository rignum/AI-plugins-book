(function(global){
'use strict';
class InputError extends Error { constructor(msg){super(msg);this.name='InputError';} }
function fail(msg){ throw new InputError(msg); }
function csvLine(line){
  const out=[]; let cur='', q=false;
  for(let i=0;i<line.length;i++){
    const c=line[i];
    if(q){
      if(c==='"' && line[i+1]==='"'){cur+='"';i++;}
      else if(c==='"'){q=false;}
      else cur+=c;
    } else {
      if(c==='"') q=true;
      else if(c===','){out.push(cur);cur='';}
      else cur+=c;
    }
  }
  if(q) fail("Unclosed quote in CSV.");
  out.push(cur); return out;
}
function parseCSV(text, expected, label){
  const lines=String(text).replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim()!=='');
  if(!lines.length) fail(`${label}: empty file.`);
  const head=csvLine(lines[0]).map(x=>x.trim());
  if(head.join(',')!==expected.join(',')) fail(`${label}: expected columns ${expected.join(', ')}.`);
  return lines.slice(1).map((line,idx)=>{
    const vals=csvLine(line); if(vals.length!==head.length) fail(`${label}: row ${idx+2} has an invalid field count.`);
    const o={}; head.forEach((h,j)=>o[h]=vals[j].trim()); return o;
  });
}
function positiveInt(v, field){ if(!/^\d+$/.test(v)) fail(`${field}: positive integer required.`); const n=Number(v); if(n<=0) fail(`${field}: value must be greater than zero.`); return n; }
function nonnegativeInt(v, field){ if(!/^\d+$/.test(v)) fail(`${field}: nonnegative integer required.`); return Number(v); }
function moneyCents(v, field){ if(!/^\d+(?:\.\d{1,2})?$/.test(v)) fail(`${field}: price must be nonnegative with at most two decimal places.`); const [a,b='']=v.split('.'); return Number(a)*100+Number(b.padEnd(2,'0')); }
function fmtMoney(c){ return (c/100).toFixed(2); }
function timestamp(v, field){ if(typeof v!=='string'||!/(Z|[+-]\d{2}:\d{2})$/.test(v)) fail(`${field}: timestamp must include a time zone.`); const ms=Date.parse(v); if(!Number.isFinite(ms)) fail(`${field}: invalid timestamp ${v}.`); return ms; }
function ageMinutes(check, asof, field){ const d=check-asof; if(d<0) fail(`${field}: source time is after check time.`); return Math.floor(d/60000); }
function load(files){
  const names=['catalog.csv','inventory.csv','customer_request.csv','match_decisions.csv','snapshot.json'];
  const map={}; for(const f of files){ if(names.includes(f.name)){ if(map[f.name]) fail(`File ${f.name} selected more than once.`); map[f.name]=f.text; } }
  const missing=names.filter(n=>!(n in map)); if(missing.length) fail(`Required files not selected: ${missing.join(', ')}.`);
  const catalogRows=parseCSV(map['catalog.csv'],['sku','name','aliases','unit_price','currency'],"Catalog");
  const inventoryRows=parseCSV(map['inventory.csv'],['sku','location','on_hand','reserved'],"Inventory");
  const requestRows=parseCSV(map['customer_request.csv'],['line_id','customer_text','quantity'],"Customer request");
  const decisionRows=parseCSV(map['match_decisions.csv'],['line_id','match_status','selected_sku','candidates','reason'],"Matching");
  let snapshot; try{snapshot=JSON.parse(map['snapshot.json']);}catch(e){fail("snapshot.json: invalid JSON.");}
  return {catalogRows,inventoryRows,requestRows,decisionRows,snapshot};
}
function build(files){
  const {catalogRows,inventoryRows,requestRows,decisionRows,snapshot}=load(files);
  const catalog={};
  for(const r of catalogRows){
    if(!r.sku||catalog[r.sku]) fail(`Catalog: empty or duplicate SKU ${r.sku||"(blank)"}.`);
    if(!r.name) fail(`Catalog: product ${r.sku} has no name.`);
    if(!/^[A-Z]{3}$/.test(r.currency)) fail(`Catalog: product ${r.sku} currency must be a three-letter code.`);
    catalog[r.sku]={...r, unit_price_cents:moneyCents(r.unit_price,`Price ${r.sku}`)};
  }
  if(!Object.keys(catalog).length) fail("Empty catalog.");
  const inventory={};
  for(const r of inventoryRows){
    if(!r.sku||inventory[r.sku]) fail(`Inventory: empty or duplicate SKU ${r.sku||"(blank)"}.`);
    const on=nonnegativeInt(r.on_hand,`on_hand ${r.sku}`), res=nonnegativeInt(r.reserved,`reserved ${r.sku}`);
    if(res>on) fail(`Inventory: reserved exceeds on_hand for ${r.sku}.`);
    inventory[r.sku]={...r,on_hand_n:on,reserved_n:res,available:on-res};
  }
  if(!requestRows.length) fail("Client request has no lines.");
  const req=[], ids=new Set();
  for(const r of requestRows){
    if(!r.line_id||ids.has(r.line_id)) fail(`Request: empty or duplicate line_id ${r.line_id||"(blank)"}.`); ids.add(r.line_id);
    if(!r.customer_text) fail(`Request: line ${r.line_id} has no description.`);
    req.push({...r, quantity_n:positiveInt(r.quantity,`Quantity ${r.line_id}`)});
  }
  const decisions={};
  for(const r of decisionRows){
    if(!ids.has(r.line_id)||decisions[r.line_id]) fail(`Matching: unknown or duplicate line_id ${r.line_id||"(blank)"}.`);
    const cand=r.candidates? r.candidates.split('|').map(x=>x.trim()).filter(Boolean):[];
    if(r.match_status==='MATCHED'){
      if(!r.selected_sku||!catalog[r.selected_sku]) fail(`Matching: MATCHED for ${r.line_id} must choose a catalog SKU.`);
      if(cand.length && !cand.includes(r.selected_sku)) fail(`Matching: selected SKU ${r.line_id} is absent from candidates.`);
    } else if(r.match_status==='AMBIGUOUS'){
      if(r.selected_sku||cand.length<2) fail(`Matching: AMBIGUOUS for ${r.line_id} requires at least two candidates and empty selected_sku.`);
      if(cand.some(s=>!catalog[s])) fail(`Matching: ${r.line_id} contains an unknown candidate SKU.`);
    } else if(r.match_status==='NOT_FOUND'){
      if(r.selected_sku||cand.length) fail(`Matching: NOT_FOUND for ${r.line_id} must have no SKU.`);
    } else fail(`Matching: unknown status ${r.match_status} for ${r.line_id}.`);
    decisions[r.line_id]={...r,candidates_a:cand};
  }
  const miss=[...ids].filter(id=>!decisions[id]); if(miss.length) fail(`Matching: missing lines ${miss.join(', ')}.`);
  const loc=String(snapshot.location||'').trim(); if(!loc) fail("snapshot.json: location missing.");
  for(const sku of Object.keys(inventory)) if(inventory[sku].location!==loc) fail(`Inventory: warehouse for ${sku} differs from snapshot location.`);
  const checked=timestamp(snapshot.checked_at,'checked_at'), catTime=timestamp(snapshot.catalog_as_of,'catalog_as_of'), invTime=timestamp(snapshot.inventory_as_of,'inventory_as_of');
  const catAge=ageMinutes(checked,catTime,'catalog_as_of'), invAge=ageMinutes(checked,invTime,'inventory_as_of');
  const maxCat=Number(snapshot.max_catalog_age_minutes), maxInv=Number(snapshot.max_inventory_age_minutes);
  if(!Number.isInteger(maxCat)||!Number.isInteger(maxInv)||maxCat<0||maxInv<0) fail("snapshot.json: freshness limits must be nonnegative integer minutes.");
  const requestId=String(snapshot.request_id||'').trim(); if(!requestId) fail("snapshot.json: request_id missing.");
  const stale=[]; if(catAge>maxCat) stale.push(`Catalog age ${catAge} min. exceeds the allowed ${maxCat} min.`); if(invAge>maxInv) stale.push(`Inventory age ${invAge} min. exceeds the allowed ${maxInv} min.`);
  const report={offer_id:`OF-${requestId}`,status:stale.length?'BLOCKED_STALE_DATA':'DRAFT_FOR_REVIEW',training_data:Boolean(snapshot.training_data),location:loc,catalog_as_of:snapshot.catalog_as_of,catalog_age_minutes:catAge,inventory_as_of:snapshot.inventory_as_of,inventory_age_minutes:invAge,checked_at:snapshot.checked_at,max_catalog_age_minutes:maxCat,max_inventory_age_minutes:maxInv,stale_reasons:stale,order_created:false,inventory_reserved:false,lines:[],subtotals:{}};
  if(stale.length){ for(const r of req) report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,status:'BLOCKED_STALE_DATA'}); return report; }
  const subt={};
  for(const r of req){
    const d=decisions[r.line_id];
    if(d.match_status==='AMBIGUOUS'){report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,status:'NEEDS_CLARIFICATION',candidates:d.candidates_a,reason:d.reason});continue;}
    if(d.match_status==='NOT_FOUND'){report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,status:'NOT_FOUND',reason:d.reason});continue;}
    const sku=d.selected_sku,item=catalog[sku],stock=inventory[sku];
    if(!stock){report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,sku,product:item.name,status:'NO_INVENTORY_DATA'});continue;}
    if(stock.available<r.quantity_n){report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,sku,product:item.name,unit_price:fmtMoney(item.unit_price_cents),currency:item.currency,on_hand:stock.on_hand_n,reserved:stock.reserved_n,available_in_snapshot:stock.available,status:stock.available===0?'FOUND_NO_AVAILABLE_STOCK':'INSUFFICIENT_STOCK'});continue;}
    const total=item.unit_price_cents*r.quantity_n; subt[item.currency]=(subt[item.currency]||0)+total;
    report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,sku,product:item.name,unit_price:fmtMoney(item.unit_price_cents),currency:item.currency,line_total:fmtMoney(total),on_hand:stock.on_hand_n,reserved:stock.reserved_n,available_in_snapshot:stock.available,status:'IN_DRAFT_OFFER'});
  }
  for(const cur of Object.keys(subt).sort()) report.subtotals[cur]=fmtMoney(subt[cur]);
  if(!report.lines.some(x=>x.status==='IN_DRAFT_OFFER')) report.status='NO_OFFER_LINES_REVIEW';
  return report;
}
function renderText(r){
  const overall={DRAFT_FOR_REVIEW:"draft for review",BLOCKED_STALE_DATA:"calculation stopped: stale data",NO_OFFER_LINES_REVIEW:"no confirmed lines; review required"}[r.status]||r.status;
  const labels={BLOCKED_STALE_DATA:"calculation blocked until data is refreshed",NEEDS_CLARIFICATION:"clarify which product is intended",NOT_FOUND:"no catalog match",NO_INVENTORY_DATA:"product found, no stock data in snapshot",FOUND_NO_AVAILABLE_STOCK:"product found, no available snapshot quantity",INSUFFICIENT_STOCK:"product found, insufficient snapshot quantity"};
  const reasons={NEEDS_CLARIFICATION:"No automatic choice between variants made.",NOT_FOUND:"No substitute proposed.",NO_INVENTORY_DATA:"A missing row does not mean zero stock.",FOUND_NO_AVAILABLE_STOCK:"Product found in catalog, but all listed stock is already reserved.",INSUFFICIENT_STOCK:"Requested quantity exceeds snapshot availability; no partial line added."};
  const o=["Practice customer offer",`Draft number: ${r.offer_id}`,`Status: ${overall}`,`Practice data: ${r.training_data?"yes":"no"}`,`Warehouse: ${r.location}`,`Catalog: ${r.catalog_as_of} (age at check: ${r.catalog_age_minutes} min.)`,`Inventory: ${r.inventory_as_of} (age at check: ${r.inventory_age_minutes} min.)`,`Check time: ${r.checked_at}`,"Order created: no","Quantity reserved for client: no",''];
  if(r.stale_reasons.length){o.push("WARNING: offer calculation blocked by stale data."); r.stale_reasons.forEach(x=>o.push('- '+x)); o.push("Obtain fresh catalog and inventory data first."); r.lines.forEach(x=>o.push(`${x.line_id} | ${x.customer_text} | ${x.quantity_requested} pcs | ${labels[x.status]||x.status}`)); return o.join('\n')+'\n';}
  o.push("Lines included in the draft:"); const inc=r.lines.filter(x=>x.status==='IN_DRAFT_OFFER'); if(!inc.length)o.push("- No confirmed lines."); inc.forEach(x=>o.push(`- ${x.sku} ${x.product}: ${x.quantity_requested} pcs × ${x.currency} ${x.unit_price} = ${x.currency} ${x.line_total}; snapshot availability ${x.available_in_snapshot} pcs`));
  o.push('',"Amounts are grouped by currency; do not add currencies without a separate rate and conversion rule."); const curs=Object.keys(r.subtotals); if(curs.length)curs.forEach(c=>o.push(`Subtotal ${c}: ${c} ${r.subtotals[c]}`)); else o.push("Subtotals not calculated.");
  o.push('',"Lines requiring clarification or review:");
  r.lines.filter(x=>x.status!=='IN_DRAFT_OFFER').forEach(x=>{let extra=''; if(x.available_in_snapshot!==undefined) extra+=` Snapshot availability ${x.available_in_snapshot} pcs, requested ${x.quantity_requested} pcs`; if(x.candidates?.length) extra+=` Possible variants: ${x.candidates.join(', ')}.`; o.push(`- ${x.line_id} ${x.customer_text}: ${labels[x.status]||x.status}.${extra} ${reasons[x.status]||''}`.trimEnd());});
  o.push('',"This draft uses a practice snapshot. It is not a reservation, availability confirmation, or order.","Before sending, refresh price and stock in the live system and check terms, delivery, and tax.");
  return o.join('\n')+'\n';
}
function run(files){try{const report=build(files);return {ok:true,report,text:renderText(report)};}catch(e){if(e.name!=='InputError')throw e;return{ok:false,error:e.message,text:`STATUS: ERROR\nReason: ${e.message}\n`};}}
global.OfferTool={parseCSV,build,renderText,run,fmtMoney};
})(typeof window!=='undefined'?window:globalThis);
