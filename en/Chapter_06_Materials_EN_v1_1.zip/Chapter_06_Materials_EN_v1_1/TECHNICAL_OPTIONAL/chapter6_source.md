# Chapter 6 Technical log analysis

## Determining operating time and fault downtime from event records

In this chapter, we will create a practice tool for parsing the log of a fictional packaging machine. Each log line contains a date, time, event type, and short explanation. Using START, ERROR, and STOP events, the program will reconstruct intervals of operation, fault downtime, and pauses after a stop.

The chapter’s main rule is that an ordinary program performs calculations under agreed rules. AI helps write instructions, explain results, and prepare a technical report, but must not invent missing events or an unclosed interval’s end time.

By the end, you will have a practice-format description, normal and problematic logs, an analysis script, test-run results, and Skill instructions. All records and names were invented for this book, not taken from a proprietary format or real enterprise materials.

### What you will learn

- to read log lines and locate dates, times, and events;
- to check record order and recognize ambiguous timestamps;
- to reconstruct machine states between events;
- to count operation, fault downtime, and intervals after STOP separately;
- to mark an unfinished interval without assuming its end time;
- to compare two shifts using the same metrics;
- run an ordinary script on a log copy and check its report;
- to describe format limitations and apply the rules to another practice log.

## 6.1. The employee’s task

Imagine a shift supervisor receiving a text log from a packaging machine. At the end of the day, the supervisor wants to answer simple questions: when the machine operated, how long a fault-related stop lasted, how many times an error was recorded, and how two shifts differ.

A log may contain dozens or hundreds of lines. Reading manually makes it easy to miss a repeated event, mistake a pause between shifts for a malfunction, or count time after the last record. Asking AI to “calculate downtime” without precise rules may lead it to interpret the same records differently.

Before processing, therefore, agree on four things:

1. what each record means;
2. which machine state applies between adjacent events;
3. which events open and close the measured interval;
4. what to do with incorrect ordering, repetition, or a missing ending.

Our practice model has only three events. They are defined unambiguously and do not attempt to cover every behavior of actual equipment.

## 6.2. Practice materials and log format

The package has two normal logs for shift comparison and separate edge-case logs. Each file covers one machine and shift.

Filenames follow `MACHINE__YYYY-MM-DD__SHIFT.log`. For example, `PK01__2026-09-22__A.log` means machine `PK01`, September 22, 2026, shift A. Every nonempty row is written as:

```text
YYYY-MM-DD HH:MM:SS|EVENT|DETAIL
```

A vertical bar separates three fields. Time uses a 24-hour clock and seconds. All records in a practice file have the filename’s date. No time zone is specified: this is illustrative local time.

| Row component | Example | Purpose |
|---|---|---|
| Date and time | `2026-09-22 08:45:00` | Identify when the event happened |
| Event | `ERROR` | Changes or confirms the machine state |
| Detail | `E-17: film feed jam` | Helps a person understand the record |

The explanation is not used to calculate duration. It must not be used as a reason to change an event’s meaning. For example, “the operator checked the sensor” alone means neither START nor STOP.

## 6.3. Reading a single record

Open PK01__2026-09-22__A.log in an ordinary text editor. It contains the reference sequence from the chapter’s task:

```text
2026-09-22 08:00:00|START|Production starts, batch P-301
2026-09-22 08:45:00|ERROR|E-17: film feed jam
2026-09-22 09:00:00|START|Film feed restored
2026-09-22 10:00:00|STOP|Batch P-301 production ends
```

The first part of each line is a timestamp. The second is an event code. The third is a human-readable explanation. This is called structured text: information is stored in predefined fields rather than an arbitrary paragraph.

Confirm that records are separated by newlines and fields by `|`. A spreadsheet editor may display the file as one column. That does not change the file; specify the delimiter or use the supplied script for correct parsing.

## 6.4. Checking times and record order

Before calculating, the program checks the date, time format, and line sequence. The practice log follows these rules:

- read dates and times only in YYYY-MM-DD HH:MM:SS format;
- dates in lines must match the date in the file name;
- time may advance or equal the previous timestamp but must not move backward;
- preserve original line order; the program does not reorder records by time;
- for identical times, use line order in the file; the interval between those events is zero minutes;
- flag matching times with a warning because second-level precision does not establish which event physically occurred first.

Why not silently sort the lines? A record appearing earlier because of an incorrect clock or export error may reveal an important problem. Sorting would hide it and create the impression that the file was valid.

If time moves backward, the date does not match the filename, a line has an invalid format, or an event code is unknown, the entire log receives “Data error” status. Its intervals are excluded from the comparison totals. First check the source record and agree on a correction.

## 6.5. Machine states and event meanings

A state is an operating condition that persists until the next event. We are not trying to guess the packaging machine’s internal design. Three states are sufficient for the exercise.

| Current state | Event | New state | Meaning |
|---|---|---|---|
| Stopped | `START` | Running | An operating interval began |
| Running | `ERROR` | Fault downtime | An error interrupted operation |
| Fault downtime | `START` | Running | Machine restarted after the error was resolved |
| Running or fault downtime | `STOP` | Stopped | Current interval ended |

The file’s initial state is considered “Stopped.” The first meaningful record must therefore be START. After STOP, time no longer counts as operation or fault downtime. A later START begins a new operating interval.

Some sequences violate the rules. For example, another `START` while the machine is already running does not create a new start: that log receives “Data error” status. A `STOP` while the machine is already stopped is also a sequence error. An `ERROR` during a stop cannot be counted as emergency downtime because no preceding operating interval is open.

If another ERROR arrives during an already recorded fault, the program counts it as a separate error signal without starting a second parallel downtime interval. The fault interval continues until the next START or STOP.

## 6.6. Calculating operating intervals

The program examines each adjacent pair of events. It first identifies the state in effect after the previous event. It then calculates the difference between the timestamps and assigns it to that state.

In the reference log, the calculation looks like this:

| Interval | State between events | Calculation |
|---|---|---:|
| 08:00–08:45 | Running | 45 operating minutes |
| 08:45–09:00 | Fault downtime | 15 downtime minutes |
| 09:00–10:00 | Running | 60 operating minutes |

Total: 45 + 60 = 105 minutes of operation and 15 minutes of fault downtime. The first and last timestamps are 120 minutes apart; that time is divided between operation and fault downtime. The sum reconciles: 105 + 15 = 120.

An interval begins at the event that puts the machine into the state. For example, ERROR at 08:45 means fault downtime begins at 08:45. The next START at 09:00 closes the interval. In this practice example, duration is measured in minutes to two decimal places if the log contains seconds.

This arithmetic is valid only under the accepted event meanings. In an actual installation, ERROR may mean a warning rather than a stop. Before applying the tool, the equipment owner must approve which event actually opens downtime and which closes it.

## 6.7. What time after `STOP` means

If the last record is STOP at 10:00, the log says nothing about what happened after 10:00. The shift may have ended, the equipment may have been serviced, or the file may have been cut off. The program therefore extends neither operation nor downtime beyond that point.

If a later `START` follows `STOP` in the same file, the interval is known. For example, `STOP` at 08:10 and `START` at 08:30 are 20 minutes apart. The script displays this separately as an interval between stopping and restarting. It counts as neither operation nor fault downtime and is not labeled a production incident.

Measuring time after the last STOP requires a separate observation boundary—for example, a confirmed shift end time. This chapter’s format has no such boundary, so we add nothing after the final STOP.

Shift B’s log contains this measurable interval:

```text
2026-09-22 07:30:00|START|Production starts, order Q-204
2026-09-22 08:10:00|STOP|Scheduled shift pause
2026-09-22 08:30:00|START|Production resumes
2026-09-22 09:00:00|ERROR|E-22: box-position sensor triggered
2026-09-22 09:20:00|START|Sensor checked, production resumed
2026-09-22 10:10:00|STOP|Practice observation interval ends
```

This sequence has 40 operating minutes, 20 minutes between stopping and restarting, 30 operating minutes, 20 fault-downtime minutes, and another 50 operating minutes. The script reports 120 operating minutes, 20 fault-downtime minutes, and a separate 20-minute stopped interval. It adds no time after `STOP` at 10:10.

## 6.8. Incomplete interval

If a file ends after START, its state remains “Running.” We know when operation began but not when it ended. If the last record is ERROR, the fault’s start is known, but the recovery time is not.

Such an interval is called incomplete. The program assigns “Incomplete” status to the log, identifies the currently open state, and shows only durations between events whose times are known. It does not substitute the file creation time, the computer's current time, the end of the shift, or the time of the last line for a missing event.

For example, START at 08:00 and ERROR at 08:30 reliably establish 30 minutes of operation. Fault downtime after 08:30 remains open: without another record, its duration is unknown. The report must show this uncertainty clearly rather than present a complete shift total.

If STOP is missing, do not add it automatically. First check the complete source, export log, and approved observation boundary. In this book, we leave the record unchanged and show why the calculation is incomplete.

## 6.9. Counting error frequency

The report must distinguish the number of ERROR signals from the number of separate downtime intervals. Two error events during one continuous fault state are two signals but one downtime interval.

For comparing completed shifts, error-signal frequency per operating hour can be reported:

frequency = number of ERROR events / (operating minutes / 60)

Shift A has one ERROR event and 105 minutes of operation. Its frequency is approximately 0.571 events per operating hour. Shift B has one event and 120 minutes of operation—0.500 events per operating hour.

This is a supporting metric, not an equipment reliability assessment. An actual report may require another definition: number of failures, repeated signals, time between failures, production output, or planned shift time. If a shift is incomplete or has structural errors, this metric must not be compared with valid shifts.

## 6.10. Comparing two shifts

The normal folder has two logs for the same machine and date. Compare metrics after the script has checked both files:

| Shift | Operation | Fault downtime | Post-STOP interval | Errors |
|---|---:|---:|---:|---:|
| A | 105 min | 15 min | 0 min | 1 |
| B | 120 min | 20 min | 20 min | 1 |

Shift B contains more operating time and more fault downtime, but also a separate 20-minute pause between STOP and another START. Do not add that pause to fault downtime unless it is defined as a fault. Nor can you conclude that shift B is more efficient simply because it has more operating minutes: its observed interval is different.

When comparing, record each metric’s units and boundaries. Compare shifts using the same event rule, time precision, and log selection method. If a shift contains several machines, compare each machine before producing a combined total.

## 6.11. What the script does and what AI does

A parser is a small program that reads records in a defined format and extracts fields. The practice script uses Python’s standard libraries. It runs on an ordinary computer without a GPU or external model.

The script performs fixed checks: parses fields, recognizes allowed events, checks timestamp order and state sequence, calculates intervals, writes a summary table, and saves a report. Identical files and rules produce identical calculations.

AI can help prepare instructions, explain a warning, or turn verified metrics into connected prose. It must not change minutes, repair the log, or infer an error’s cause from one short description.

Separate the result into three levels:

1. Source record—exactly what is written in the file.
2. **Script calculation** — durations computed under the approved rules.
3. Technical explanation—what the supervisor can conclude after reviewing the calculation and equipment context.

The third level requires a person. For example, “box position sensor” does not prove that the sensor is at fault: the cause could be box position, a cable, a setting, or a communication failure.

## 6.12. Creating reusable Skill instructions

A Skill stores persistent rules for a recurring task: when to apply it, which files to expect, where to stop, and how to format the response. For our project, persistent instructions must tell the assistant to:

- use only the practice format description unless the user approves another specification;
- not guess fields or the purpose of unfamiliar event codes;
- preserve source files and work on copies;
- not sort records when time order is invalid;
- not present an incomplete interval as completed;
- show operation, fault downtime, and the interval after STOP separately;
- state whether the script actually ran;
- not state a malfunction’s cause when the log has only a code or short explanation.

Processing rules must not be mixed with a particular shift’s data. The Skill retains event meanings and report format. Log files, date, machine, and shift number change with each run. If ERROR has a different meaning in another project, create a separate specification and a new set of checks.

The package includes `plugin_packaging_log`, containing a portable plugin description, Skill folder, and script. Current OpenAI documentation says a Skill can contain instructions and supporting materials; a plugin may include a Skill, MCP server, or both [1–3]. Placing a script beside instructions does not mean ChatGPT can access computer folders or has run Python. Automatic execution needs an appropriate authorized runtime or connected tool. Skills availability and installation steps depend on the product and workspace settings; check official help before publishing the book.

## 6.13. Trial run

For the first run, ask a technical specialist to extract the package into a separate folder. Run tests first, then analyze the two normal logs. The script creates four output files:

- `summary.csv` — summary metrics for each log;
- `intervals.csv` — intervals between adjacent events;
- `report.txt` and `run_record.txt` — text explanation and run information.

The Windows command is in `README_START.txt`. The script takes an input-log folder and a separate output folder. It does not modify originals, access the network, send records to an external model, or connect to an equipment controller.

If only a Skill without code execution is available, AI can explain the format and prepare a command, but must not claim the calculation is complete. Run the script separately in an authorized environment and give AI the summary to explain. Confirm permission to transfer work logs to that environment.

## 6.14. Testing normal and problematic files

The normal folder contains shifts A and B. `test_cases` contains edge-case files. Every test uses a copy rather than overwriting an original log.

| Case | File content | Expected behavior |
|---|---|---|
| Normal shift | Chronological events ending in `STOP` | A: 105 operating minutes, 15 downtime minutes |
| Shift with a pause | 20 min between `STOP` and a new `START` | Report 20 min separately, not as a fault |
| Equal time | `ERROR` and the next `START` share a timestamp | Retain row order, use zero duration, issue a warning |
| Repeated `START` | Machine is already running | Mark log invalid; exclude metrics from comparison |
| Backward time | Timestamp precedes the previous one | Do not sort or include the log in totals |
| Missing closing event | Last state is operation or fault | Mark “Incomplete”; do not estimate the open interval |

Verification covers more than correct numbers. Each file needs a clear status, the original error cause must remain visible, and incomplete logs must not enter complete-shift comparisons.

## 6.15. Reuse and adaptation

To analyze a new shift, copy its `.log` into a separate folder and check filename, date, and machine ID. Do not change the permanent meaning of `ERROR` without the log owner’s confirmation. Retain the source version, command, and result record so that the metrics can be explained a month later.

If the source changes format, first prepare a new example and field description. Check that dates, times, and event codes can still be read unambiguously. Do not extend the parser through guesses based on a similar name or one successful line.

Applying it to another machine requires confirmation that its events have the same meaning. The same STOP code may mean a manual stop in one log and the end of a production cycle in another. An identical-looking line does not guarantee the same rule.

## 6.16. Additional capabilities

Export to a spreadsheet. The CSV files summary.csv and intervals.csv open in Excel and other spreadsheet applications. Before reporting, check the delimiter, encoding, headings, and value types. CSV does not preserve Excel workbook formatting or formulas.

Cycle comparison. If each cycle has a stable number and start and end boundaries, add them to the specification. Do not identify cycles through approximate time intervals until the supervisor confirms how to distinguish one cycle from the next.

**Several machines.** A folder may contain different machine codes. The script reports each file separately, retaining date, shift, and equipment code. Sum across machines only after verifying that units and event meanings are comparable.

**Service connection.** Calling analysis directly from ChatGPT requires an execution environment or server tool with explicitly limited permissions. Send only the agreed dataset to the server; define read, write, retention, and deletion permissions separately. The practice example needs no external connection.

## Chapter conclusions

A log can be analyzed only once its record format and event meanings are known. Each duration belongs to the state in effect between two adjacent timestamps. The reference sequence yields 105 minutes of operation and 15 minutes of fault downtime.

The script does not sort backward-time rows, treat a stop-to-start gap as a fault, or continue after the last event without a defined observation boundary. It marks open intervals incomplete.

Ordinary code calculates durations and checks sequence. A Skill retains rules and response format. A person confirms event meanings and fault causes. A plugin alone does not provide computer access or mean code has run.

## Self-check

1. Why do the 15 minutes from ERROR to the next START count as fault downtime?
2. What must the program do if a line’s time is earlier than the preceding line’s?
3. Can the interval after the final STOP be counted if the log has no observation end time?
4. How does another ERROR event differ from a new fault interval?
5. How should a log ending in the “Running” state be shown?
6. Why must an event code’s meaning on another machine be confirmed with the log owner?
7. What should be checked before adding the script to a plugin?

## Specification for your future tool

| Question | Your answer |
|---|---|
| Which log will be analyzed? | |
| Who approves event-code meanings? | |
| What timestamp precision does the file specify? | |
| How are equal timestamps handled? | |
| Which event closes an operating interval? | |
| What counts as fault downtime? | |
| Which boundary ends observation? | |
| Which rows must stop the entire calculation? | |
| Where does the script run, and who can access logs? | |
| Who checks the final report? | |

## Sources on current Skills and plugin functionality

Checked September 25, 2026. Feature availability and interface names can change; check official pages before releasing the book.

1. OpenAI Help Center, “Skills in ChatGPT”: https://help.openai.com/en/articles/20001066-skills-in-chatgpt
2. OpenAI Developers, “Build skills”: https://developers.openai.com/plugins/build/skills
3. OpenAI Developers, “Package your plugin”: https://developers.openai.com/plugins/build/plugins
