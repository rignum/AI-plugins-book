TECHNICAL EXTENSION — CHAPTER 6

This folder is not needed for the main exercise.

It contains the original Python analyzer, automated tests, and practice Skill/plugin packaging. These are for readers interested in the internals and for technical specialists.

The main reader uses TOOL/log_analyzer.html and need not install Python or open a command line.

If you try Python, use practice-log copies. The script handles only this chapter’s fictional format, not real equipment logs.

Run the saved tests from this folder: python -m unittest test_analyze_logs.py -v
