(function(global){
'use strict';
class InputError extends Error { constructor(msg){super(msg);this.name='InputError';} }
function fail(msg){ throw new InputError(msg); }
function csvLine(line){
  const out=[]; let cur='', q=false;
  for(let i=0;i<line.length;i++){
    const c=line[i];
    if(q){
      if(c==='"' && line[i+1]==='"'){cur+='"';i++;}
      else if(c==='"'){q=false;}
      else cur+=c;
    } else {
      if(c==='"') q=true;
      else if(c===','){out.push(cur);cur='';}
      else cur+=c;
    }
  }
  if(q) fail('В CSV обнаружена незакрытая кавычка.');
  out.push(cur); return out;
}
function parseCSV(text, expected, label){
  const lines=String(text).replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim()!=='');
  if(!lines.length) fail(`${label}: файл пуст.`);
  const head=csvLine(lines[0]).map(x=>x.trim());
  if(head.join(',')!==expected.join(',')) fail(`${label}: ожидаются столбцы ${expected.join(', ')}.`);
  return lines.slice(1).map((line,idx)=>{
    const vals=csvLine(line); if(vals.length!==head.length) fail(`${label}: строка ${idx+2} содержит неверное число полей.`);
    const o={}; head.forEach((h,j)=>o[h]=vals[j].trim()); return o;
  });
}
function positiveInt(v, field){ if(!/^\d+$/.test(v)) fail(`${field}: требуется целое положительное число.`); const n=Number(v); if(n<=0) fail(`${field}: значение должно быть больше нуля.`); return n; }
function nonnegativeInt(v, field){ if(!/^\d+$/.test(v)) fail(`${field}: требуется целое число не меньше нуля.`); return Number(v); }
function moneyCents(v, field){ if(!/^\d+(?:\.\d{1,2})?$/.test(v)) fail(`${field}: цена должна быть неотрицательной и иметь не более двух знаков после точки.`); const [a,b='']=v.split('.'); return Number(a)*100+Number(b.padEnd(2,'0')); }
function fmtMoney(c){ return (c/100).toFixed(2); }
function timestamp(v, field){ if(typeof v!=='string'||!/(Z|[+-]\d{2}:\d{2})$/.test(v)) fail(`${field}: временная метка должна содержать часовой пояс.`); const ms=Date.parse(v); if(!Number.isFinite(ms)) fail(`${field}: неверная временная метка ${v}.`); return ms; }
function ageMinutes(check, asof, field){ const d=check-asof; if(d<0) fail(`${field}: время источника позже времени проверки.`); return Math.floor(d/60000); }
function load(files){
  const names=['catalog.csv','inventory.csv','customer_request.csv','match_decisions.csv','snapshot.json'];
  const map={}; for(const f of files){ if(names.includes(f.name)){ if(map[f.name]) fail(`Файл ${f.name} выбран больше одного раза.`); map[f.name]=f.text; } }
  const missing=names.filter(n=>!(n in map)); if(missing.length) fail(`Не выбраны обязательные файлы: ${missing.join(', ')}.`);
  const catalogRows=parseCSV(map['catalog.csv'],['sku','name','aliases','unit_price','currency'],'Каталог');
  const inventoryRows=parseCSV(map['inventory.csv'],['sku','location','on_hand','reserved'],'Остатки');
  const requestRows=parseCSV(map['customer_request.csv'],['line_id','customer_text','quantity'],'Запрос клиента');
  const decisionRows=parseCSV(map['match_decisions.csv'],['line_id','match_status','selected_sku','candidates','reason'],'Сопоставление');
  let snapshot; try{snapshot=JSON.parse(map['snapshot.json']);}catch(e){fail('snapshot.json: неверный JSON.');}
  return {catalogRows,inventoryRows,requestRows,decisionRows,snapshot};
}
function build(files){
  const {catalogRows,inventoryRows,requestRows,decisionRows,snapshot}=load(files);
  const catalog={};
  for(const r of catalogRows){
    if(!r.sku||catalog[r.sku]) fail(`Каталог: пустой или повторный SKU ${r.sku||'(пусто)'}.`);
    if(!r.name) fail(`Каталог: у ${r.sku} нет названия.`);
    if(!/^[A-Z]{3}$/.test(r.currency)) fail(`Каталог: у ${r.sku} валюта должна быть трёхбуквенным кодом.`);
    catalog[r.sku]={...r, unit_price_cents:moneyCents(r.unit_price,`Цена ${r.sku}`)};
  }
  if(!Object.keys(catalog).length) fail('Каталог пуст.');
  const inventory={};
  for(const r of inventoryRows){
    if(!r.sku||inventory[r.sku]) fail(`Остатки: пустой или повторный SKU ${r.sku||'(пусто)'}.`);
    const on=nonnegativeInt(r.on_hand,`on_hand ${r.sku}`), res=nonnegativeInt(r.reserved,`reserved ${r.sku}`);
    if(res>on) fail(`Остатки: reserved больше on_hand для ${r.sku}.`);
    inventory[r.sku]={...r,on_hand_n:on,reserved_n:res,available:on-res};
  }
  if(!requestRows.length) fail('Запрос клиента не содержит строк.');
  const req=[], ids=new Set();
  for(const r of requestRows){
    if(!r.line_id||ids.has(r.line_id)) fail(`Запрос: пустой или повторный line_id ${r.line_id||'(пусто)'}.`); ids.add(r.line_id);
    if(!r.customer_text) fail(`Запрос: строка ${r.line_id} не содержит описания.`);
    req.push({...r, quantity_n:positiveInt(r.quantity,`Количество ${r.line_id}`)});
  }
  const decisions={};
  for(const r of decisionRows){
    if(!ids.has(r.line_id)||decisions[r.line_id]) fail(`Сопоставление: неизвестный или повторный line_id ${r.line_id||'(пусто)'}.`);
    const cand=r.candidates? r.candidates.split('|').map(x=>x.trim()).filter(Boolean):[];
    if(r.match_status==='MATCHED'){
      if(!r.selected_sku||!catalog[r.selected_sku]) fail(`Сопоставление: MATCHED для ${r.line_id} должен выбирать SKU из каталога.`);
      if(cand.length && !cand.includes(r.selected_sku)) fail(`Сопоставление: выбранный SKU ${r.line_id} отсутствует среди candidates.`);
    } else if(r.match_status==='AMBIGUOUS'){
      if(r.selected_sku||cand.length<2) fail(`Сопоставление: AMBIGUOUS для ${r.line_id} требует минимум два candidates и пустой selected_sku.`);
      if(cand.some(s=>!catalog[s])) fail(`Сопоставление: ${r.line_id} содержит неизвестный кандидат SKU.`);
    } else if(r.match_status==='NOT_FOUND'){
      if(r.selected_sku||cand.length) fail(`Сопоставление: NOT_FOUND для ${r.line_id} не должен содержать SKU.`);
    } else fail(`Сопоставление: неизвестный статус ${r.match_status} для ${r.line_id}.`);
    decisions[r.line_id]={...r,candidates_a:cand};
  }
  const miss=[...ids].filter(id=>!decisions[id]); if(miss.length) fail(`Сопоставление: отсутствуют строки ${miss.join(', ')}.`);
  const loc=String(snapshot.location||'').trim(); if(!loc) fail('snapshot.json: не указан location.');
  for(const sku of Object.keys(inventory)) if(inventory[sku].location!==loc) fail(`Остатки: склад для ${sku} не совпадает с location снимка.`);
  const checked=timestamp(snapshot.checked_at,'checked_at'), catTime=timestamp(snapshot.catalog_as_of,'catalog_as_of'), invTime=timestamp(snapshot.inventory_as_of,'inventory_as_of');
  const catAge=ageMinutes(checked,catTime,'catalog_as_of'), invAge=ageMinutes(checked,invTime,'inventory_as_of');
  const maxCat=Number(snapshot.max_catalog_age_minutes), maxInv=Number(snapshot.max_inventory_age_minutes);
  if(!Number.isInteger(maxCat)||!Number.isInteger(maxInv)||maxCat<0||maxInv<0) fail('snapshot.json: пределы свежести должны быть целыми неотрицательными минутами.');
  const requestId=String(snapshot.request_id||'').trim(); if(!requestId) fail('snapshot.json: отсутствует request_id.');
  const stale=[]; if(catAge>maxCat) stale.push(`Возраст каталога ${catAge} мин. превышает допустимые ${maxCat} мин.`); if(invAge>maxInv) stale.push(`Возраст остатков ${invAge} мин. превышает допустимые ${maxInv} мин.`);
  const report={offer_id:`OF-${requestId}`,status:stale.length?'BLOCKED_STALE_DATA':'DRAFT_FOR_REVIEW',training_data:Boolean(snapshot.training_data),location:loc,catalog_as_of:snapshot.catalog_as_of,catalog_age_minutes:catAge,inventory_as_of:snapshot.inventory_as_of,inventory_age_minutes:invAge,checked_at:snapshot.checked_at,max_catalog_age_minutes:maxCat,max_inventory_age_minutes:maxInv,stale_reasons:stale,order_created:false,inventory_reserved:false,lines:[],subtotals:{}};
  if(stale.length){ for(const r of req) report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,status:'BLOCKED_STALE_DATA'}); return report; }
  const subt={};
  for(const r of req){
    const d=decisions[r.line_id];
    if(d.match_status==='AMBIGUOUS'){report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,status:'NEEDS_CLARIFICATION',candidates:d.candidates_a,reason:d.reason});continue;}
    if(d.match_status==='NOT_FOUND'){report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,status:'NOT_FOUND',reason:d.reason});continue;}
    const sku=d.selected_sku,item=catalog[sku],stock=inventory[sku];
    if(!stock){report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,sku,product:item.name,status:'NO_INVENTORY_DATA'});continue;}
    if(stock.available<r.quantity_n){report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,sku,product:item.name,unit_price:fmtMoney(item.unit_price_cents),currency:item.currency,on_hand:stock.on_hand_n,reserved:stock.reserved_n,available_in_snapshot:stock.available,status:stock.available===0?'FOUND_NO_AVAILABLE_STOCK':'INSUFFICIENT_STOCK'});continue;}
    const total=item.unit_price_cents*r.quantity_n; subt[item.currency]=(subt[item.currency]||0)+total;
    report.lines.push({line_id:r.line_id,customer_text:r.customer_text,quantity_requested:r.quantity_n,sku,product:item.name,unit_price:fmtMoney(item.unit_price_cents),currency:item.currency,line_total:fmtMoney(total),on_hand:stock.on_hand_n,reserved:stock.reserved_n,available_in_snapshot:stock.available,status:'IN_DRAFT_OFFER'});
  }
  for(const cur of Object.keys(subt).sort()) report.subtotals[cur]=fmtMoney(subt[cur]);
  if(!report.lines.some(x=>x.status==='IN_DRAFT_OFFER')) report.status='NO_OFFER_LINES_REVIEW';
  return report;
}
function renderText(r){
  const overall={DRAFT_FOR_REVIEW:'черновик для проверки',BLOCKED_STALE_DATA:'расчёт остановлен: данные устарели',NO_OFFER_LINES_REVIEW:'нет подтверждённых строк; требуется проверка'}[r.status]||r.status;
  const labels={BLOCKED_STALE_DATA:'расчёт заблокирован до обновления данных',NEEDS_CLARIFICATION:'нужно уточнить, какой товар имеется в виду',NOT_FOUND:'в каталоге нет совпадения',NO_INVENTORY_DATA:'товар найден, но в снимке нет сведений об остатке',FOUND_NO_AVAILABLE_STOCK:'товар найден, свободного количества по снимку нет',INSUFFICIENT_STOCK:'товар найден, но по снимку количества недостаточно'};
  const reasons={NEEDS_CLARIFICATION:'Автоматический выбор между вариантами не выполнялся.',NOT_FOUND:'Замена другим товаром не предлагалась.',NO_INVENTORY_DATA:'Отсутствие строки не означает нулевой остаток.',FOUND_NO_AVAILABLE_STOCK:'Товар найден в каталоге, но весь указанный запас уже зарезервирован.',INSUFFICIENT_STOCK:'Запрошено больше единиц, чем доступно по снимку; частичная позиция не добавлена.'};
  const o=['Учебное предложение клиенту',`Номер черновика: ${r.offer_id}`,`Статус: ${overall}`,`Учебные данные: ${r.training_data?'да':'нет'}`,`Склад: ${r.location}`,`Каталог: ${r.catalog_as_of} (возраст при проверке: ${r.catalog_age_minutes} мин.)`,`Остатки: ${r.inventory_as_of} (возраст при проверке: ${r.inventory_age_minutes} мин.)`,`Время проверки: ${r.checked_at}`,'Заказ создан: нет','Количество зарезервировано для клиента: нет',''];
  if(r.stale_reasons.length){o.push('ПРЕДУПРЕЖДЕНИЕ: расчёт предложения заблокирован из-за устаревших данных.'); r.stale_reasons.forEach(x=>o.push('- '+x)); o.push('Сначала получите свежие данные по каталогу и остаткам.'); r.lines.forEach(x=>o.push(`${x.line_id} | ${x.customer_text} | ${x.quantity_requested} шт. | ${labels[x.status]||x.status}`)); return o.join('\n')+'\n';}
  o.push('Позиции, включённые в черновик:'); const inc=r.lines.filter(x=>x.status==='IN_DRAFT_OFFER'); if(!inc.length)o.push('- Нет подтверждённых позиций.'); inc.forEach(x=>o.push(`- ${x.sku} ${x.product}: ${x.quantity_requested} шт. × ${x.currency} ${x.unit_price} = ${x.currency} ${x.line_total}; снимок показывает доступно ${x.available_in_snapshot} шт.`));
  o.push('','Суммы сгруппированы по валюте; складывать их между собой нельзя без отдельного курса и правила пересчёта.'); const curs=Object.keys(r.subtotals); if(curs.length)curs.forEach(c=>o.push(`Промежуточная сумма ${c}: ${c} ${r.subtotals[c]}`)); else o.push('Промежуточные суммы не рассчитаны.');
  o.push('','Позиции, требующие уточнения или проверки:');
  r.lines.filter(x=>x.status!=='IN_DRAFT_OFFER').forEach(x=>{let extra=''; if(x.available_in_snapshot!==undefined) extra+=` По снимку доступно ${x.available_in_snapshot} шт., запрошено ${x.quantity_requested} шт.`; if(x.candidates?.length) extra+=` Возможные варианты: ${x.candidates.join(', ')}.`; o.push(`- ${x.line_id} ${x.customer_text}: ${labels[x.status]||x.status}.${extra} ${reasons[x.status]||''}`.trimEnd());});
  o.push('','Это черновик по учебному снимку данных. Он не является резервированием, подтверждением наличия или заказом.','Перед отправкой обновите остатки и цену в рабочей системе и проверьте условия, доставку и налоги.');
  return o.join('\n')+'\n';
}
function run(files){try{const report=build(files);return {ok:true,report,text:renderText(report)};}catch(e){if(e.name!=='InputError')throw e;return{ok:false,error:e.message,text:`STATUS: ERROR\nПричина: ${e.message}\n`};}}
global.OfferTool={parseCSV,build,renderText,run,fmtMoney};
})(typeof window!=='undefined'?window:globalThis);
