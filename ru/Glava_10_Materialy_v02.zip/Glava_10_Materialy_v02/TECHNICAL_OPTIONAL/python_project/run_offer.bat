@echo off
setlocal
cd /d "%~dp0"
if not exist reports mkdir reports
where python >nul 2>nul
if not errorlevel 1 (
  python src\prepare_offer.py --project . --output reports\last_offer.txt
  goto show_report
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 src\prepare_offer.py --project . --output reports\last_offer.txt
  goto show_report
)
echo NOT_RUN: Python 3 was not found. The offer was not calculated.
echo NOT_RUN: Python 3 was not found. The offer was not calculated.>reports\last_offer.txt
goto pause_end
:show_report
if exist reports\last_offer.txt start "" notepad reports\last_offer.txt
:pause_end
pause
