@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if not errorlevel 1 (
  python -m unittest discover -s tests -v
  goto pause_end
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m unittest discover -s tests -v
  goto pause_end
)
echo NOT_RUN: Python 3 was not found. Tests were not run.
:pause_end
pause
