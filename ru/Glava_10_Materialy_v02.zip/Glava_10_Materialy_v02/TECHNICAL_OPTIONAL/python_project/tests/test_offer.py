import csv
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
from prepare_offer import ValidationError, build_report


class OfferTests(unittest.TestCase):
    def test_main_offer_groups_totals_by_currency(self):
        report = build_report(PROJECT / "data")
        self.assertEqual(report["status"], "DRAFT_FOR_REVIEW")
        self.assertEqual(report["offer_id"], "OF-REQ-DEMO-1001")
        self.assertEqual(report["subtotals"], {"CHF": "156.70", "EUR": "159.00"})
        self.assertFalse(report["order_created"])
        self.assertFalse(report["inventory_reserved"])

    def test_second_request_reuses_the_same_rules_with_a_new_id(self):
        report = build_report(PROJECT / "examples" / "second_request")
        self.assertEqual(report["offer_id"], "OF-REQ-DEMO-1002")
        self.assertEqual(report["subtotals"], {"CHF": "99.70", "EUR": "159.00"})
        self.assertTrue(all(line["status"] == "IN_DRAFT_OFFER" for line in report["lines"]))

    def test_available_is_on_hand_minus_reserved(self):
        report = build_report(PROJECT / "data")
        keyboard = next(line for line in report["lines"] if line["line_id"] == "L01")
        self.assertEqual(keyboard["available_in_snapshot"], 8)
        self.assertEqual(keyboard["status"], "IN_DRAFT_OFFER")

    def test_found_but_fully_reserved_is_not_offered(self):
        report = build_report(PROJECT / "data")
        monitor = next(line for line in report["lines"] if line["line_id"] == "L04")
        self.assertEqual(monitor["status"], "FOUND_NO_AVAILABLE_STOCK")
        self.assertNotIn("line_total", monitor)

    def test_ambiguous_and_missing_products_are_not_guessed(self):
        report = build_report(PROJECT / "data")
        ambiguous = next(line for line in report["lines"] if line["line_id"] == "L05")
        missing = next(line for line in report["lines"] if line["line_id"] == "L06")
        self.assertEqual(ambiguous["status"], "NEEDS_CLARIFICATION")
        self.assertEqual(ambiguous["candidates"], ["ADP-51", "ADP-81"])
        self.assertEqual(missing["status"], "NOT_FOUND")

    def test_stale_stock_snapshot_blocks_the_offer(self):
        report = build_report(PROJECT / "data", "snapshot_stale.json")
        self.assertEqual(report["status"], "BLOCKED_STALE_DATA")
        self.assertEqual(report["inventory_age_minutes"], 45)
        self.assertFalse(report["subtotals"])
        self.assertTrue(all(line["status"] == "BLOCKED_STALE_DATA" for line in report["lines"]))

    def test_insufficient_quantity_is_not_partially_quoted(self):
        with tempfile.TemporaryDirectory() as temp:
            data_dir = Path(temp) / "data"
            shutil.copytree(PROJECT / "data", data_dir)
            request_path = data_dir / "customer_request.csv"
            with request_path.open(encoding="utf-8", newline="") as source:
                rows = list(csv.DictReader(source))
            for row in rows:
                if row["line_id"] == "L02":
                    row["quantity"] = "5"
            with request_path.open("w", encoding="utf-8", newline="") as target:
                writer = csv.DictWriter(target, fieldnames=["line_id", "customer_text", "quantity"])
                writer.writeheader()
                writer.writerows(rows)
            report = build_report(data_dir)
            mouse = next(line for line in report["lines"] if line["line_id"] == "L02")
            self.assertEqual(mouse["available_in_snapshot"], 4)
            self.assertEqual(mouse["status"], "INSUFFICIENT_STOCK")
            self.assertNotIn("line_total", mouse)

    def test_invalid_reservation_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            data_dir = Path(temp) / "data"
            shutil.copytree(PROJECT / "data", data_dir)
            inventory_path = data_dir / "inventory.csv"
            with inventory_path.open(encoding="utf-8", newline="") as source:
                rows = list(csv.DictReader(source))
            rows[0]["reserved"] = "13"
            with inventory_path.open("w", encoding="utf-8", newline="") as target:
                writer = csv.DictWriter(target, fieldnames=["sku", "location", "on_hand", "reserved"])
                writer.writeheader()
                writer.writerows(rows)
            with self.assertRaisesRegex(ValidationError, "exceeds on_hand"):
                build_report(data_dir)

    def test_mixed_warehouse_rows_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            data_dir = Path(temp) / "data"
            shutil.copytree(PROJECT / "data", data_dir)
            inventory_path = data_dir / "inventory.csv"
            with inventory_path.open(encoding="utf-8", newline="") as source:
                rows = list(csv.DictReader(source))
            rows[0]["location"] = "OTHER_LOCATION"
            with inventory_path.open("w", encoding="utf-8", newline="") as target:
                writer = csv.DictWriter(target, fieldnames=["sku", "location", "on_hand", "reserved"])
                writer.writeheader()
                writer.writerows(rows)
            with self.assertRaisesRegex(ValidationError, "does not match the snapshot location"):
                build_report(data_dir)

    def test_zero_quantity_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            data_dir = Path(temp) / "data"
            shutil.copytree(PROJECT / "data", data_dir)
            request_path = data_dir / "customer_request.csv"
            with request_path.open(encoding="utf-8", newline="") as source:
                rows = list(csv.DictReader(source))
            rows[0]["quantity"] = "0"
            with request_path.open("w", encoding="utf-8", newline="") as target:
                writer = csv.DictWriter(target, fieldnames=["line_id", "customer_text", "quantity"])
                writer.writeheader()
                writer.writerows(rows)
            with self.assertRaisesRegex(ValidationError, "greater than zero"):
                build_report(data_dir)


if __name__ == "__main__":
    unittest.main()
