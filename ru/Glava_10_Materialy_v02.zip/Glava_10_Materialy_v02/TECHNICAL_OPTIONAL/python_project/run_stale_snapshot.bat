@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if not errorlevel 1 (
  python src\prepare_offer.py --project . --snapshot snapshot_stale.json --output reports\stale_offer.txt
  goto pause_end
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 src\prepare_offer.py --project . --snapshot snapshot_stale.json --output reports\stale_offer.txt
  goto pause_end
)
echo NOT_RUN: Python 3 was not found. The stale-snapshot test was not run.
:pause_end
pause
