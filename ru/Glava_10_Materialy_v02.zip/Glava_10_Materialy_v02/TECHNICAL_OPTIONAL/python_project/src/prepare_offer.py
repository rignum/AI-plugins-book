from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Any


CENT = Decimal("0.01")
MONEY_PATTERN = re.compile(r"^[0-9]+(?:\.[0-9]{1,2})?$")


class ValidationError(ValueError):
    pass


def read_csv(path: Path) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as source:
            return list(csv.DictReader(source))
    except OSError as exc:
        raise ValidationError(f"Cannot read {path.name}: {exc}") from exc


def parse_timestamp(value: str, field: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"Invalid timestamp in {field}: {value}") from exc
    if parsed.tzinfo is None:
        raise ValidationError(f"Timestamp in {field} must include a time-zone offset.")
    return parsed


def age_minutes(checked_at: datetime, as_of: datetime, field: str) -> int:
    seconds = (checked_at - as_of).total_seconds()
    if seconds < 0:
        raise ValidationError(f"{field} is later than checked_at.")
    return int(seconds // 60)


def positive_integer(value: str, field: str) -> int:
    if not value.isdigit():
        raise ValidationError(f"{field} must be a whole positive number.")
    number = int(value)
    if number <= 0:
        raise ValidationError(f"{field} must be greater than zero.")
    return number


def nonnegative_integer(value: str, field: str) -> int:
    if not value.isdigit():
        raise ValidationError(f"{field} must be a whole number zero or greater.")
    return int(value)


def parse_money(value: str, field: str) -> Decimal:
    if not MONEY_PATTERN.fullmatch(value):
        raise ValidationError(f"{field} must be a non-negative amount with up to two decimals.")
    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise ValidationError(f"{field} is not a valid amount.") from exc
    return amount.quantize(CENT, rounding=ROUND_HALF_UP)


def load_catalog(data_dir: Path) -> dict[str, dict[str, Any]]:
    rows = read_csv(data_dir / "catalog.csv")
    catalog: dict[str, dict[str, Any]] = {}
    for row in rows:
        sku = row.get("sku", "").strip()
        if not sku or sku in catalog:
            raise ValidationError(f"Catalog has an empty or duplicate SKU: {sku!r}")
        currency = row.get("currency", "").strip()
        if not re.fullmatch(r"[A-Z]{3}", currency):
            raise ValidationError(f"Catalog currency must be a three-letter code for {sku}.")
        name = row.get("name", "").strip()
        if not name:
            raise ValidationError(f"Catalog item {sku} has no name.")
        catalog[sku] = {
            "sku": sku,
            "name": name,
            "aliases": row.get("aliases", "").strip(),
            "unit_price": parse_money(row.get("unit_price", ""), f"price for {sku}"),
            "currency": currency,
        }
    if not catalog:
        raise ValidationError("The catalog is empty.")
    return catalog


def load_inventory(data_dir: Path) -> dict[str, dict[str, Any]]:
    rows = read_csv(data_dir / "inventory.csv")
    inventory: dict[str, dict[str, Any]] = {}
    for row in rows:
        sku = row.get("sku", "").strip()
        if not sku or sku in inventory:
            raise ValidationError(f"Inventory has an empty or duplicate SKU: {sku!r}")
        on_hand = nonnegative_integer(row.get("on_hand", ""), f"on_hand for {sku}")
        reserved = nonnegative_integer(row.get("reserved", ""), f"reserved for {sku}")
        if reserved > on_hand:
            raise ValidationError(f"Reserved quantity exceeds on_hand for {sku}.")
        inventory[sku] = {
            "sku": sku,
            "location": row.get("location", "").strip(),
            "on_hand": on_hand,
            "reserved": reserved,
            "available": on_hand - reserved,
        }
    return inventory


def load_request(data_dir: Path) -> list[dict[str, Any]]:
    rows = read_csv(data_dir / "customer_request.csv")
    if not rows:
        raise ValidationError("The customer request has no lines.")
    result = []
    seen: set[str] = set()
    for row in rows:
        line_id = row.get("line_id", "").strip()
        if not line_id or line_id in seen:
            raise ValidationError(f"Request has an empty or duplicate line_id: {line_id!r}")
        seen.add(line_id)
        description = row.get("customer_text", "").strip()
        if not description:
            raise ValidationError(f"Request line {line_id} has no description.")
        result.append({
            "line_id": line_id,
            "customer_text": description,
            "quantity": positive_integer(row.get("quantity", ""), f"quantity for {line_id}"),
        })
    return result


def load_decisions(data_dir: Path, request_lines: list[dict[str, Any]], catalog: dict[str, dict[str, Any]]) -> dict[str, dict[str, str]]:
    rows = read_csv(data_dir / "match_decisions.csv")
    decisions: dict[str, dict[str, str]] = {}
    valid_ids = {line["line_id"] for line in request_lines}
    for row in rows:
        line_id = row.get("line_id", "").strip()
        status = row.get("match_status", "").strip()
        if line_id not in valid_ids or line_id in decisions:
            raise ValidationError(f"Match file has an unknown or duplicate line_id: {line_id!r}")
        selected = row.get("selected_sku", "").strip()
        candidates = [item.strip() for item in row.get("candidates", "").split("|") if item.strip()]
        reason = row.get("reason", "").strip()
        if status == "MATCHED":
            if not selected or selected not in catalog:
                raise ValidationError(f"Matched line {line_id} must select a SKU in the catalog.")
            if candidates and selected not in candidates:
                raise ValidationError(f"Selected SKU for {line_id} is missing from candidates.")
        elif status == "AMBIGUOUS":
            if selected or len(candidates) < 2:
                raise ValidationError(f"Ambiguous line {line_id} needs at least two candidates and no selected SKU.")
            if any(sku not in catalog for sku in candidates):
                raise ValidationError(f"Ambiguous line {line_id} contains an unknown candidate SKU.")
        elif status == "NOT_FOUND":
            if selected or candidates:
                raise ValidationError(f"Not-found line {line_id} cannot select or list a catalog SKU.")
        else:
            raise ValidationError(f"Unknown match status for {line_id}: {status!r}")
        decisions[line_id] = {
            "match_status": status,
            "selected_sku": selected,
            "candidates": candidates,
            "reason": reason,
        }
    if set(decisions) != valid_ids:
        missing = ", ".join(sorted(valid_ids - set(decisions)))
        raise ValidationError(f"Match file is missing request lines: {missing}")
    return decisions


def format_money(amount: Decimal) -> str:
    return f"{amount.quantize(CENT, rounding=ROUND_HALF_UP):.2f}"


def build_report(data_dir: Path, snapshot_name: str = "snapshot.json") -> dict[str, Any]:
    catalog = load_catalog(data_dir)
    inventory = load_inventory(data_dir)
    request_lines = load_request(data_dir)
    decisions = load_decisions(data_dir, request_lines, catalog)

    try:
        snapshot = json.loads((data_dir / snapshot_name).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValidationError(f"Cannot read snapshot metadata {snapshot_name}: {exc}") from exc

    snapshot_location = str(snapshot.get("location", "")).strip()
    if not snapshot_location:
        raise ValidationError("Snapshot metadata must identify a location.")
    for sku, row in inventory.items():
        if row["location"] != snapshot_location:
            raise ValidationError(
                f"Inventory location for {sku} does not match the snapshot location."
            )

    checked_at = parse_timestamp(snapshot.get("checked_at"), "checked_at")
    catalog_as_of = parse_timestamp(snapshot.get("catalog_as_of"), "catalog_as_of")
    inventory_as_of = parse_timestamp(snapshot.get("inventory_as_of"), "inventory_as_of")
    catalog_age = age_minutes(checked_at, catalog_as_of, "catalog_as_of")
    inventory_age = age_minutes(checked_at, inventory_as_of, "inventory_as_of")

    try:
        max_catalog_age = int(snapshot["max_catalog_age_minutes"])
        max_inventory_age = int(snapshot["max_inventory_age_minutes"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValidationError("Snapshot freshness limits must be whole minutes.") from exc
    if max_catalog_age < 0 or max_inventory_age < 0:
        raise ValidationError("Snapshot freshness limits cannot be negative.")
    request_id = str(snapshot.get("request_id", "")).strip()
    if not request_id:
        raise ValidationError("Snapshot metadata must include a request_id.")

    stale_reasons = []
    if catalog_age > max_catalog_age:
        stale_reasons.append(f"Возраст каталога {catalog_age} мин. превышает допустимые {max_catalog_age} мин.")
    if inventory_age > max_inventory_age:
        stale_reasons.append(f"Возраст остатков {inventory_age} мин. превышает допустимые {max_inventory_age} мин.")

    report: dict[str, Any] = {
        "offer_id": f"OF-{request_id}",
        "status": "BLOCKED_STALE_DATA" if stale_reasons else "DRAFT_FOR_REVIEW",
        "training_data": bool(snapshot.get("training_data", False)),
        "location": snapshot_location,
        "catalog_as_of": catalog_as_of.isoformat(),
        "catalog_age_minutes": catalog_age,
        "inventory_as_of": inventory_as_of.isoformat(),
        "inventory_age_minutes": inventory_age,
        "checked_at": checked_at.isoformat(),
        "max_catalog_age_minutes": max_catalog_age,
        "max_inventory_age_minutes": max_inventory_age,
        "stale_reasons": stale_reasons,
        "order_created": False,
        "inventory_reserved": False,
        "lines": [],
        "subtotals": {},
    }

    if stale_reasons:
        for line in request_lines:
            report["lines"].append({
                "line_id": line["line_id"],
                "customer_text": line["customer_text"],
                "quantity_requested": line["quantity"],
                "status": "BLOCKED_STALE_DATA",
                "reason": "Refresh both approved data sources before preparing a quote.",
            })
        return report

    subtotals: dict[str, Decimal] = {}
    for line in request_lines:
        decision = decisions[line["line_id"]]
        status = decision["match_status"]

        if status == "AMBIGUOUS":
            report["lines"].append({
                "line_id": line["line_id"],
                "customer_text": line["customer_text"],
                "quantity_requested": line["quantity"],
                "status": "NEEDS_CLARIFICATION",
                "candidates": decision["candidates"],
                "reason": decision["reason"],
            })
            continue
        if status == "NOT_FOUND":
            report["lines"].append({
                "line_id": line["line_id"],
                "customer_text": line["customer_text"],
                "quantity_requested": line["quantity"],
                "status": "NOT_FOUND",
                "reason": decision["reason"],
            })
            continue

        sku = decision["selected_sku"]
        item = catalog[sku]
        stock = inventory.get(sku)
        if stock is None:
            report["lines"].append({
                "line_id": line["line_id"],
                "customer_text": line["customer_text"],
                "quantity_requested": line["quantity"],
                "sku": sku,
                "product": item["name"],
                "status": "NO_INVENTORY_DATA",
                "reason": "The item is in the catalog, but this snapshot has no stock row for it.",
            })
            continue

        price = item["unit_price"]
        currency = item["currency"]
        if stock["available"] < line["quantity"]:
            line_status = "FOUND_NO_AVAILABLE_STOCK" if stock["available"] == 0 else "INSUFFICIENT_STOCK"
            report["lines"].append({
                "line_id": line["line_id"],
                "customer_text": line["customer_text"],
                "quantity_requested": line["quantity"],
                "sku": sku,
                "product": item["name"],
                "unit_price": format_money(price),
                "currency": currency,
                "on_hand": stock["on_hand"],
                "reserved": stock["reserved"],
                "available_in_snapshot": stock["available"],
                "status": line_status,
                "reason": "The product is identified, but the snapshot does not show enough available units.",
            })
            continue

        line_total = (price * line["quantity"]).quantize(CENT, rounding=ROUND_HALF_UP)
        subtotals[currency] = subtotals.get(currency, Decimal("0.00")) + line_total
        report["lines"].append({
            "line_id": line["line_id"],
            "customer_text": line["customer_text"],
            "quantity_requested": line["quantity"],
            "sku": sku,
            "product": item["name"],
            "unit_price": format_money(price),
            "currency": currency,
            "line_total": format_money(line_total),
            "on_hand": stock["on_hand"],
            "reserved": stock["reserved"],
            "available_in_snapshot": stock["available"],
            "status": "IN_DRAFT_OFFER",
            "reason": "Unique catalog match and enough quantity in the training snapshot; nothing is reserved.",
        })

    report["subtotals"] = {
        currency: format_money(amount)
        for currency, amount in sorted(subtotals.items())
    }
    if not any(line["status"] == "IN_DRAFT_OFFER" for line in report["lines"]):
        report["status"] = "NO_OFFER_LINES_REVIEW"
    return report


def render_text(report: dict[str, Any]) -> str:
    overall_status = {
        "DRAFT_FOR_REVIEW": "черновик для проверки",
        "BLOCKED_STALE_DATA": "расчёт остановлен: данные устарели",
        "NO_OFFER_LINES_REVIEW": "нет подтверждённых строк; требуется проверка",
    }.get(report["status"], report["status"])
    line_status = {
        "BLOCKED_STALE_DATA": "расчёт заблокирован до обновления данных",
        "NEEDS_CLARIFICATION": "нужно уточнить, какой товар имеется в виду",
        "NOT_FOUND": "в каталоге нет совпадения",
        "NO_INVENTORY_DATA": "товар найден, но в снимке нет сведений об остатке",
        "FOUND_NO_AVAILABLE_STOCK": "товар найден, свободного количества по снимку нет",
        "INSUFFICIENT_STOCK": "товар найден, но по снимку количества недостаточно",
    }
    line_reason = {
        "NEEDS_CLARIFICATION": "Автоматический выбор между вариантами не выполнялся.",
        "NOT_FOUND": "Замена другим товаром не предлагалась.",
        "NO_INVENTORY_DATA": "Отсутствие строки не означает нулевой остаток.",
        "FOUND_NO_AVAILABLE_STOCK": "Товар найден в каталоге, но весь указанный запас уже зарезервирован.",
        "INSUFFICIENT_STOCK": "Запрошено больше единиц, чем доступно по снимку; частичная позиция не добавлена.",
        "BLOCKED_STALE_DATA": "Обновите каталог и остатки перед подготовкой предложения.",
    }
    lines = [
        "Учебное предложение клиенту",
        f"Номер черновика: {report['offer_id']}",
        f"Статус: {overall_status}",
        f"Учебные данные: {'да' if report['training_data'] else 'нет'}",
        f"Склад: {report['location']}",
        f"Каталог: {report['catalog_as_of']} (возраст при проверке: {report['catalog_age_minutes']} мин.)",
        f"Остатки: {report['inventory_as_of']} (возраст при проверке: {report['inventory_age_minutes']} мин.)",
        f"Время проверки: {report['checked_at']}",
        "Заказ создан: нет",
        "Количество зарезервировано для клиента: нет",
        "",
    ]
    if report["stale_reasons"]:
        lines.append("ПРЕДУПРЕЖДЕНИЕ: расчёт предложения заблокирован из-за устаревших данных.")
        lines.extend(f"- {reason}" for reason in report["stale_reasons"])
        lines.append("Сначала получите свежие данные по каталогу и остаткам.")
        for item in report["lines"]:
            label = line_status.get(item["status"], item["status"])
            lines.append(f"{item['line_id']} | {item['customer_text']} | {item['quantity_requested']} шт. | {label}")
        return "\n".join(lines) + "\n"

    lines.append("Позиции, включённые в черновик:")
    included = [item for item in report["lines"] if item["status"] == "IN_DRAFT_OFFER"]
    if not included:
        lines.append("- Нет подтверждённых позиций.")
    for item in included:
        lines.append(
            f"- {item['sku']} {item['product']}: {item['quantity_requested']} шт. × "
            f"{item['currency']} {item['unit_price']} = {item['currency']} {item['line_total']}; "
            f"снимок показывает доступно {item['available_in_snapshot']} шт."
        )

    lines.append("")
    lines.append("Суммы сгруппированы по валюте; складывать их между собой нельзя без отдельного курса и правила пересчёта.")
    if report["subtotals"]:
        for currency, total in report["subtotals"].items():
            lines.append(f"Промежуточная сумма {currency}: {currency} {total}")
    else:
        lines.append("Промежуточные суммы не рассчитаны.")

    lines.extend(["", "Позиции, требующие уточнения или проверки:"])
    for item in report["lines"]:
        if item["status"] == "IN_DRAFT_OFFER":
            continue
        candidates = ""
        if item.get("candidates"):
            candidates = " Возможные варианты: " + ", ".join(item["candidates"]) + "."
        label = line_status.get(item["status"], item["status"])
        availability = ""
        if "available_in_snapshot" in item:
            availability = (
                f" По снимку доступно {item['available_in_snapshot']} шт., "
                f"запрошено {item['quantity_requested']} шт."
            )
        lines.append(
            f"- {item['line_id']} {item['customer_text']}: {label}."
            f"{availability}{candidates} {line_reason.get(item['status'], '')}"
        )

    lines.extend([
        "",
        "Это черновик по учебному снимку данных. Он не является резервированием, подтверждением наличия или заказом.",
        "Перед отправкой обновите остатки и цену в рабочей системе и проверьте условия, доставку и налоги.",
    ])
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Prepare a draft offer from approved CSV snapshots.")
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--data", type=Path, default=Path("data"))
    parser.add_argument("--snapshot", default="snapshot.json")
    parser.add_argument("--output", type=Path, default=Path("reports/last_offer.txt"))
    args = parser.parse_args()
    project_dir = args.project.resolve()
    data_dir = args.data if args.data.is_absolute() else project_dir / args.data
    output_path = args.output if args.output.is_absolute() else project_dir / args.output

    try:
        report = build_report(data_dir, args.snapshot)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(render_text(report), encoding="utf-8")
        json_path = output_path.with_suffix(".json")
        json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(render_text(report))
        return 0
    except ValidationError as exc:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(f"STATUS: ERROR\nПричина: {exc}\n", encoding="utf-8")
        print(f"Ошибка входных данных: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
