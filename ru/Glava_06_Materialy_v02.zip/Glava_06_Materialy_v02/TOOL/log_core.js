(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  root.LogTool=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  const filenameRe=/^([A-Za-z0-9-]+)__([0-9]{4}-[0-9]{2}-[0-9]{2})__([A-Za-z0-9-]+)\.log$/;
  const EVENTS=new Set(['START','ERROR','STOP']);
  function r2(n){return Math.round((n+Number.EPSILON)*100)/100;}
  function r3(n){return Math.round((n+Number.EPSILON)*1000)/1000;}
  function fmt2(n){return n==null?'':r2(n).toFixed(2);}
  function fmt3(n){return n==null?'':r3(n).toFixed(3);}
  function parseDateTime(s){
    const m=/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/.exec(s);
    if(!m)return null;
    const [_,ys,mos,ds,hs,mis,ss]=m; const y=+ys,mo=+mos,d=+ds,h=+hs,mi=+mis,se=+ss;
    const t=Date.UTC(y,mo-1,d,h,mi,se); const dt=new Date(t);
    if(dt.getUTCFullYear()!==y||dt.getUTCMonth()!==mo-1||dt.getUTCDate()!==d||dt.getUTCHours()!==h||dt.getUTCMinutes()!==mi||dt.getUTCSeconds()!==se)return null;
    return {ms:t,date:`${ys}-${mos}-${ds}`,text:s};
  }
  function minutes(a,b){return r2((b-a)/60000);}
  function analyzeFile(file){
    const result={filename:file.name,machine_id:'',work_date:'',shift_id:'',status:'INVALID',event_rows:0,error_events:0,recorded_work_min:null,recorded_fault_min:null,stopped_gap_min:null,event_span_min:null,errors_per_running_hour:null,open_state:'',issues:[],intervals:[]};
    const fm=filenameRe.exec(file.name);
    let fileDate=null;
    if(!fm){result.issues.push('имя файла должно иметь вид MACHINE__YYYY-MM-DD__SHIFT.log');return result;}
    result.machine_id=fm[1]; fileDate=fm[2]; result.work_date=fileDate; result.shift_id=fm[3];
    const rawLines=String(file.text||'').replace(/^\uFEFF/,'').split(/\r?\n/);
    const events=[]; let prev=null; let readFatal=false;
    result.event_rows=rawLines.filter(x=>x.trim()&&!x.trimStart().startsWith('#')).length;
    rawLines.forEach((raw,i)=>{
      if(readFatal)return; const line=raw.trim(); if(!line||line.startsWith('#'))return;
      const parts=line.split('|');
      if(parts.length!==3){result.issues.push(`строка ${i+1}: ожидались ровно три поля, разделённые символом |`);readFatal=true;return;}
      const [rawTime0,rawCode0,rawDetail0]=parts.map(x=>x.trim()); const parsed=parseDateTime(rawTime0);
      if(!parsed){result.issues.push(`строка ${i+1}: дата или время не соответствует формату YYYY-MM-DD HH:MM:SS`);readFatal=true;return;}
      if(parsed.date!==fileDate){result.issues.push(`строка ${i+1}: дата не совпадает с датой в имени файла`);readFatal=true;return;}
      const code=rawCode0.toUpperCase();
      if(!EVENTS.has(code)){result.issues.push(`строка ${i+1}: неизвестное событие '${rawCode0}'`);readFatal=true;return;}
      if(!rawDetail0){result.issues.push(`строка ${i+1}: отсутствует пояснение события`);readFatal=true;return;}
      if(prev!==null){
        if(parsed.ms<prev){result.issues.push(`строка ${i+1}: время меньше предыдущей записи; строки не сортировались`);readFatal=true;return;}
        if(parsed.ms===prev) result.issues.push(`строка ${i+1}: одинаковая временная метка; сохранён порядок строк, длительность равна нулю`);
      }
      events.push({moment:parsed.ms,timeText:parsed.text,code,detail:rawDetail0,line:i+1}); prev=parsed.ms;
    });
    if(readFatal)return result;
    if(!events.length){result.issues.push('в файле нет записей событий');return result;}
    if(events[0].code!=='START'){result.issues.push('первая запись события должна быть START');return result;}
    let state='STOPPED',work=0,fault=0,gap=0,fatal=false;
    for(let idx=0;idx<events.length;idx++){
      const e=events[idx];
      if(idx>0){const p=events[idx-1], mins=minutes(p.moment,e.moment); const cat=state==='RUNNING'?'RUNNING':state==='FAULT'?'FAULT':'STOPPED_GAP'; result.intervals.push({file:file.name,from_line:p.line,to_line:e.line,start:p.timeText,end:e.timeText,state:cat,minutes:mins}); if(state==='RUNNING')work+=mins; else if(state==='FAULT')fault+=mins; else gap+=mins;}
      let next=null;
      if(e.code==='START'){
        if(state==='STOPPED'||state==='FAULT')next='RUNNING'; else {result.issues.push(`строка ${e.line}: повторный START при состоянии RUNNING`);fatal=true;}
      } else if(e.code==='ERROR'){
        result.error_events++;
        if(state==='RUNNING')next='FAULT';
        else if(state==='FAULT'){result.issues.push(`строка ${e.line}: повторный ERROR внутри одного аварийного интервала; простой продолжается`);next='FAULT';}
        else {result.issues.push(`строка ${e.line}: ERROR зарегистрирован, когда рабочий интервал не открыт`);fatal=true;}
      } else { // STOP
        if(state==='RUNNING'||state==='FAULT')next='STOPPED'; else {result.issues.push(`строка ${e.line}: STOP зарегистрирован, когда машина уже остановлена`);fatal=true;}
      }
      if(fatal)break; state=next;
    }
    if(fatal){result.intervals=[];return result;}
    result.recorded_work_min=r2(work); result.recorded_fault_min=r2(fault); result.stopped_gap_min=r2(gap); result.event_span_min=minutes(events[0].moment,events[events.length-1].moment); result.open_state=state==='STOPPED'?'':state;
    const hasWarnings=result.issues.length>0;
    if(state!=='STOPPED') result.status=hasWarnings?'INCOMPLETE_WITH_WARNINGS':'INCOMPLETE';
    else {result.status=hasWarnings?'OK_WITH_WARNINGS':'OK'; if(work>0)result.errors_per_running_hour=r3(result.error_events/(work/60));}
    return result;
  }
  function csvEscape(v){const s=String(v??''); return /[",\n\r;]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;}
  function summaryRow(r){return [r.filename,r.machine_id,r.work_date,r.shift_id,r.status,r.event_rows,r.error_events,fmt2(r.recorded_work_min),fmt2(r.recorded_fault_min),fmt2(r.stopped_gap_min),fmt2(r.event_span_min),fmt3(r.errors_per_running_hour),r.open_state,r.issues.join('; ')];}
  function summaryCsv(results){const h=['file','machine_id','work_date','shift_id','status','event_rows','error_events','recorded_work_min','recorded_fault_min','stopped_gap_min','event_span_min','errors_per_running_hour','open_state','issues']; return '\uFEFF'+[h,...results.map(summaryRow)].map(r=>r.map(csvEscape).join(',')).join('\r\n')+'\r\n';}
  function intervalsCsv(results){const h=['file','from_line','to_line','start','end','state','minutes']; const rows=[]; results.forEach(r=>r.intervals.forEach(x=>rows.push([x.file,x.from_line,x.to_line,x.start,x.end,x.state,fmt2(x.minutes)]))); return '\uFEFF'+[h,...rows].map(r=>r.map(csvEscape).join(',')).join('\r\n')+'\r\n';}
  function reportText(results){const lines=['ОТЧЁТ АНАЛИЗА УЧЕБНЫХ ЖУРНАЛОВ','Показатели относятся только к интервалам между явными записями событий.','Время после последнего STOP не добавляется.','']; for(const r of results){lines.push(`Файл: ${r.filename}`);lines.push(`Машина: ${r.machine_id||'не определена'}; дата: ${r.work_date||'не определена'}; смена: ${r.shift_id||'не определена'}`);lines.push(`Статус: ${r.status}`); if(r.recorded_work_min!=null){lines.push(`Работа между событиями: ${fmt2(r.recorded_work_min)} мин`);lines.push(`Аварийный простой между событиями: ${fmt2(r.recorded_fault_min)} мин`);lines.push(`Интервал после STOP до следующего события: ${fmt2(r.stopped_gap_min)} мин`);lines.push(`Разница между первой и последней меткой: ${fmt2(r.event_span_min)} мин`);if(r.errors_per_running_hour!=null)lines.push(`Событий ERROR на час работы: ${fmt3(r.errors_per_running_hour)}`);}else lines.push('Числовая сводка для сравнения не сформирована.'); if(r.open_state)lines.push(`Открытое состояние: ${r.open_state}. Его продолжительность не оценивалась.`); if(r.issues.length){lines.push('Замечания:'); r.issues.forEach(x=>lines.push('- '+x));} lines.push('');} return lines.join('\n');}
  function processFiles(files){return [...files].sort((a,b)=>a.name.localeCompare(b.name,'en',{sensitivity:'base'})).map(analyzeFile);}
  return {analyzeFile,processFiles,summaryCsv,intervalsCsv,reportText,fmt2,fmt3};
});
