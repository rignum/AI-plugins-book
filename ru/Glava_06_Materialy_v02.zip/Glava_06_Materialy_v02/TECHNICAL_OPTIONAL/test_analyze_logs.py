import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from analyze_logs import analyze_file


class AnalyzeLogTests(unittest.TestCase):
    def setUp(self):
        self.normal = ROOT / "materials" / "logs" / "normal"
        self.cases = ROOT / "materials" / "logs" / "test_cases"

    def test_control_example_is_105_work_and_15_fault(self):
        result = analyze_file(self.normal / "PK01__2026-09-22__A.log")
        self.assertEqual(result.status, "OK")
        self.assertEqual(str(result.work_minutes), "105.00")
        self.assertEqual(str(result.fault_minutes), "15.00")
        self.assertEqual(str(result.event_span_minutes), "120.00")
        self.assertEqual(result.error_events, 1)

    def test_stop_gap_is_separate_from_fault_downtime(self):
        result = analyze_file(self.normal / "PK01__2026-09-22__B.log")
        self.assertEqual(result.status, "OK")
        self.assertEqual(str(result.work_minutes), "120.00")
        self.assertEqual(str(result.fault_minutes), "20.00")
        self.assertEqual(str(result.stopped_gap_minutes), "20.00")
        self.assertEqual(str(result.event_span_minutes), "160.00")

    def test_equal_timestamp_uses_line_order_and_zero_duration(self):
        result = analyze_file(self.cases / "PK01__2026-09-23__EQUAL.log")
        self.assertEqual(result.status, "OK_WITH_WARNINGS")
        self.assertEqual(str(result.work_minutes), "60.00")
        self.assertEqual(str(result.fault_minutes), "0.00")
        self.assertTrue(any("одинаковая временная метка" in issue for issue in result.issues))

    def test_duplicate_start_invalidates_summary(self):
        result = analyze_file(self.cases / "PK01__2026-09-23__DUPSTART.log")
        self.assertEqual(result.status, "INVALID")
        self.assertIsNone(result.work_minutes)
        self.assertIsNone(result.fault_minutes)

    def test_backward_time_is_not_sorted(self):
        result = analyze_file(self.cases / "PK01__2026-09-23__BACKWARD.log")
        self.assertEqual(result.status, "INVALID")
        self.assertIsNone(result.work_minutes)
        self.assertTrue(any("не сортировались" in issue for issue in result.issues))

    def test_open_fault_is_incomplete_and_not_extrapolated(self):
        result = analyze_file(self.cases / "PK01__2026-09-23__OPEN.log")
        self.assertEqual(result.status, "INCOMPLETE")
        self.assertEqual(str(result.work_minutes), "30.00")
        self.assertEqual(str(result.fault_minutes), "0.00")
        self.assertEqual(result.open_state, "FAULT")
        self.assertIsNone(result.errors_per_running_hour)


if __name__ == "__main__":
    unittest.main()
