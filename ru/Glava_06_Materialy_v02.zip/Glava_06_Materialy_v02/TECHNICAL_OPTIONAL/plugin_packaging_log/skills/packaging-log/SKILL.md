---
name: packaging-log-review
description: Analyze a packaging-machine event log only when its filename and event format match the approved specification; report work, fault time, stopped gaps, warnings, and incomplete states without guessing.
---

# Анализ учебного журнала упаковочной машины

Use this workflow only for logs that match `references/format_spec.txt`. The included examples are fictional and do not define a real machine's behavior.

## Before analysis

1. Confirm the user has supplied the right machine, date, shift, and source file.
2. Compare the filename and every record with the format specification.
3. Preserve the original file. Analyze a copy and retain the input checksum.
4. If the date, event code, line structure, or event meaning differs, stop and ask for an approved specification update. Do not infer a mapping.

## Run and verify

1. Run `scripts/analyze_logs.py` only when the current environment has explicit access to the approved file and permission to execute Python.
2. If the script was not run, say so. Give the user the command or request the generated results; never claim the calculations are complete.
3. Treat `INVALID` as excluded from comparison. Treat `INCOMPLETE` as partial: show only intervals between explicit records and name the open state.
4. Keep `STOPPED_GAP` separate from both work and fault downtime. Do not add time after the last `STOP` without an approved observation boundary.
5. Report each source filename, status, event count, work minutes, fault minutes, stopped gap, warnings, and the run record.

## Explain, do not diagnose

The parser calculates durations from the approved transition rules. It does not identify the physical cause of an alarm. Do not turn short detail text into a diagnosis or a maintenance instruction. Ask a qualified machine owner to interpret unfamiliar codes.

## Supporting files

- Read `references/format_spec.txt` for the event meanings and data rules.
- Use `scripts/analyze_logs.py` only in a permitted execution environment.
- Review the generated `summary.csv`, `intervals.csv`, `report.txt`, and `run_record.txt` before presenting results.
