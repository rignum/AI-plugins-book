#!/usr/bin/env python3
"""Analyze the book's fictional packaging-machine event logs.

The parser uses only the Python standard library. It never edits input logs.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import re
import sys
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import List, Optional, Tuple


VERSION = "1.0.0"
FILENAME_RE = re.compile(r"^([A-Za-z0-9-]+)__([0-9]{4}-[0-9]{2}-[0-9]{2})__([A-Za-z0-9-]+)\.log$")
EVENTS = {"START", "ERROR", "STOP"}
CENT = Decimal("0.01")
THOUSANDTH = Decimal("0.001")


@dataclass
class Event:
    moment: datetime
    code: str
    detail: str
    line_number: int


@dataclass
class Interval:
    start: datetime
    end: datetime
    state: str
    minutes: Decimal
    from_line: int
    to_line: int


@dataclass
class ShiftResult:
    filename: str
    machine_id: str = ""
    work_date: str = ""
    shift_id: str = ""
    status: str = "INVALID"
    event_count: int = 0
    error_events: int = 0
    work_minutes: Optional[Decimal] = None
    fault_minutes: Optional[Decimal] = None
    stopped_gap_minutes: Optional[Decimal] = None
    event_span_minutes: Optional[Decimal] = None
    errors_per_running_hour: Optional[Decimal] = None
    open_state: str = ""
    issues: List[str] = field(default_factory=list)
    intervals: List[Interval] = field(default_factory=list)


def minutes_between(start: datetime, end: datetime) -> Decimal:
    seconds = int((end - start).total_seconds())
    return (Decimal(seconds) / Decimal(60)).quantize(CENT, rounding=ROUND_HALF_UP)


def display_decimal(value: Optional[Decimal], places: Decimal = CENT) -> str:
    if value is None:
        return ""
    return str(value.quantize(places, rounding=ROUND_HALF_UP))


def identify_file(path: Path, result: ShiftResult) -> Optional[date]:
    match = FILENAME_RE.fullmatch(path.name)
    if not match:
        result.issues.append(
            "имя файла должно иметь вид MACHINE__YYYY-MM-DD__SHIFT.log"
        )
        return None
    result.machine_id, raw_date, result.shift_id = match.groups()
    try:
        file_date = date.fromisoformat(raw_date)
    except ValueError:
        result.issues.append("дата в имени файла не существует")
        return None
    result.work_date = file_date.isoformat()
    return file_date


def read_events(path: Path, file_date: Optional[date], result: ShiftResult) -> List[Event]:
    events: List[Event] = []
    previous_time: Optional[datetime] = None
    try:
        lines = path.read_text(encoding="utf-8-sig").splitlines()
    except (OSError, UnicodeError) as exc:
        result.issues.append("файл не удалось прочитать как UTF-8: " + str(exc))
        return events

    result.event_count = sum(
        1 for raw_line in lines if raw_line.strip() and not raw_line.lstrip().startswith("#")
    )

    for line_number, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("|")
        if len(parts) != 3:
            result.issues.append(
                "строка {}: ожидались ровно три поля, разделённые символом |".format(line_number)
            )
            return []
        raw_time, raw_code, raw_detail = (part.strip() for part in parts)
        try:
            moment = datetime.strptime(raw_time, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            result.issues.append(
                "строка {}: дата или время не соответствует формату YYYY-MM-DD HH:MM:SS".format(line_number)
            )
            return []
        if file_date is not None and moment.date() != file_date:
            result.issues.append(
                "строка {}: дата не совпадает с датой в имени файла".format(line_number)
            )
            return []
        code = raw_code.upper()
        if code not in EVENTS:
            result.issues.append("строка {}: неизвестное событие {!r}".format(line_number, raw_code))
            return []
        if not raw_detail:
            result.issues.append("строка {}: отсутствует пояснение события".format(line_number))
            return []
        if previous_time is not None:
            if moment < previous_time:
                result.issues.append(
                    "строка {}: время меньше предыдущей записи; строки не сортировались".format(line_number)
                )
                return []
            if moment == previous_time:
                result.issues.append(
                    "строка {}: одинаковая временная метка; сохранён порядок строк, длительность равна нулю".format(line_number)
                )
        events.append(Event(moment, code, raw_detail, line_number))
        previous_time = moment

    if not events:
        result.issues.append("в файле нет записей событий")
    return events


def transition(state: str, event: Event, result: ShiftResult) -> Optional[str]:
    if event.code == "START":
        if state == "STOPPED" or state == "FAULT":
            return "RUNNING"
        result.issues.append(
            "строка {}: повторный START при состоянии RUNNING".format(event.line_number)
        )
        return None
    if event.code == "ERROR":
        result.error_events += 1
        if state == "RUNNING":
            return "FAULT"
        if state == "FAULT":
            result.issues.append(
                "строка {}: повторный ERROR внутри одного аварийного интервала; простой продолжается".format(event.line_number)
            )
            return "FAULT"
        result.issues.append(
            "строка {}: ERROR зарегистрирован, когда рабочий интервал не открыт".format(event.line_number)
        )
        return None
    if state in ("RUNNING", "FAULT"):
        return "STOPPED"
    result.issues.append(
        "строка {}: STOP зарегистрирован, когда машина уже остановлена".format(event.line_number)
    )
    return None


def analyze_file(path: Path) -> ShiftResult:
    result = ShiftResult(filename=path.name)
    file_date = identify_file(path, result)
    events = read_events(path, file_date, result)
    if result.issues and (not events or any("одинаковая временная метка" not in issue for issue in result.issues)):
        result.status = "INVALID"
        return result
    if not events:
        result.status = "INVALID"
        return result
    if events[0].code != "START":
        result.issues.append("первая запись события должна быть START")
        result.status = "INVALID"
        return result

    state = "STOPPED"
    work = Decimal("0")
    fault = Decimal("0")
    stopped_gap = Decimal("0")
    intervals: List[Interval] = []
    fatal = False

    for index, event in enumerate(events):
        if index > 0:
            previous = events[index - 1]
            minutes = minutes_between(previous.moment, event.moment)
            category = {
                "RUNNING": "RUNNING",
                "FAULT": "FAULT",
                "STOPPED": "STOPPED_GAP",
            }[state]
            intervals.append(
                Interval(previous.moment, event.moment, category, minutes, previous.line_number, event.line_number)
            )
            if state == "RUNNING":
                work += minutes
            elif state == "FAULT":
                fault += minutes
            else:
                stopped_gap += minutes

        new_state = transition(state, event, result)
        if new_state is None:
            fatal = True
            break
        state = new_state

    if fatal:
        result.status = "INVALID"
        return result

    result.work_minutes = work.quantize(CENT, rounding=ROUND_HALF_UP)
    result.fault_minutes = fault.quantize(CENT, rounding=ROUND_HALF_UP)
    result.stopped_gap_minutes = stopped_gap.quantize(CENT, rounding=ROUND_HALF_UP)
    result.event_span_minutes = minutes_between(events[0].moment, events[-1].moment)
    result.open_state = "" if state == "STOPPED" else state
    result.intervals = intervals

    if state != "STOPPED":
        result.status = "INCOMPLETE_WITH_WARNINGS" if result.issues else "INCOMPLETE"
    else:
        result.status = "OK_WITH_WARNINGS" if result.issues else "OK"
        if work > 0:
            rate = Decimal(result.error_events) / (work / Decimal(60))
            result.errors_per_running_hour = rate.quantize(THOUSANDTH, rounding=ROUND_HALF_UP)
    return result


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_csv(path: Path, headers: List[str], rows: List[dict]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def summary_row(result: ShiftResult) -> dict:
    return {
        "file": result.filename,
        "machine_id": result.machine_id,
        "work_date": result.work_date,
        "shift_id": result.shift_id,
        "status": result.status,
        "event_rows": result.event_count,
        "error_events": result.error_events,
        "recorded_work_min": display_decimal(result.work_minutes),
        "recorded_fault_min": display_decimal(result.fault_minutes),
        "stopped_gap_min": display_decimal(result.stopped_gap_minutes),
        "event_span_min": display_decimal(result.event_span_minutes),
        "errors_per_running_hour": display_decimal(result.errors_per_running_hour, THOUSANDTH),
        "open_state": result.open_state,
        "issues": "; ".join(result.issues),
    }


def make_report(results: List[ShiftResult]) -> str:
    lines = [
        "ОТЧЁТ АНАЛИЗА УЧЕБНЫХ ЖУРНАЛОВ",
        "Показатели относятся только к интервалам между явными записями событий.",
        "Время после последнего STOP не добавляется.",
        "",
    ]
    for result in results:
        lines.append("Файл: {}".format(result.filename))
        lines.append("Машина: {}; дата: {}; смена: {}".format(result.machine_id or "не определена", result.work_date or "не определена", result.shift_id or "не определена"))
        lines.append("Статус: {}".format(result.status))
        if result.work_minutes is not None:
            lines.append("Работа между событиями: {} мин".format(display_decimal(result.work_minutes)))
            lines.append("Аварийный простой между событиями: {} мин".format(display_decimal(result.fault_minutes)))
            lines.append("Интервал после STOP до следующего события: {} мин".format(display_decimal(result.stopped_gap_minutes)))
            lines.append("Разница между первой и последней меткой: {} мин".format(display_decimal(result.event_span_minutes)))
            if result.errors_per_running_hour is not None:
                lines.append("Событий ERROR на час работы: {}".format(display_decimal(result.errors_per_running_hour, THOUSANDTH)))
        else:
            lines.append("Числовая сводка для сравнения не сформирована.")
        if result.open_state:
            lines.append("Открытое состояние: {}. Его продолжительность не оценивалась.".format(result.open_state))
        if result.issues:
            lines.append("Замечания:")
            lines.extend("- " + issue for issue in result.issues)
        lines.append("")
    return "\n".join(lines)


def run(input_dir: Path, output_dir: Path) -> int:
    if not input_dir.is_dir():
        print("Не найдена входная папка: {}".format(input_dir), file=sys.stderr)
        return 2
    files = sorted(input_dir.glob("*.log"), key=lambda item: item.name.lower())
    if not files:
        print("В папке нет файлов .log: {}".format(input_dir), file=sys.stderr)
        return 2
    results = [analyze_file(path) for path in files]
    output_dir.mkdir(parents=True, exist_ok=True)

    summary_headers = [
        "file", "machine_id", "work_date", "shift_id", "status", "event_rows", "error_events",
        "recorded_work_min", "recorded_fault_min", "stopped_gap_min", "event_span_min",
        "errors_per_running_hour", "open_state", "issues",
    ]
    interval_headers = ["file", "from_line", "to_line", "start", "end", "state", "minutes"]
    write_csv(output_dir / "summary.csv", summary_headers, [summary_row(result) for result in results])
    interval_rows = []
    for result in results:
        for interval in result.intervals:
            interval_rows.append({
                "file": result.filename,
                "from_line": interval.from_line,
                "to_line": interval.to_line,
                "start": interval.start.isoformat(sep=" "),
                "end": interval.end.isoformat(sep=" "),
                "state": interval.state,
                "minutes": display_decimal(interval.minutes),
            })
    write_csv(output_dir / "intervals.csv", interval_headers, interval_rows)
    (output_dir / "report.txt").write_text(make_report(results), encoding="utf-8")

    record_lines = [
        "Учебный анализатор журналов версии {}".format(VERSION),
        "Время создания записи UTC: {}".format(datetime.now(timezone.utc).isoformat(timespec="seconds")),
        "Входная папка: {}".format(input_dir.resolve()),
        "Файлы и SHA-256:",
    ]
    record_lines.extend("{}  {}".format(sha256(path), path.name) for path in files)
    (output_dir / "run_record.txt").write_text("\n".join(record_lines) + "\n", encoding="utf-8")

    print("Обработано журналов: {}".format(len(results)))
    for result in results:
        print("{}: {}".format(result.filename, result.status))
    print("Результаты записаны в: {}".format(output_dir.resolve()))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Разбор учебных журналов упаковочной машины")
    parser.add_argument("--input-dir", required=True, type=Path, help="папка с файлами .log")
    parser.add_argument("--output-dir", required=True, type=Path, help="отдельная папка для результатов")
    args = parser.parse_args()
    return run(args.input_dir, args.output_dir)


if __name__ == "__main__":
    raise SystemExit(main())
