@echo off
setlocal
cd /d "%~dp0"
if not exist reports mkdir reports

where python >nul 2>nul
if not errorlevel 1 (
    python -m unittest discover -s tests -v > reports\last_tests.txt 2>&1
    set "TEST_RESULT=%ERRORLEVEL%"
    goto record_result
)

where py >nul 2>nul
if not errorlevel 1 (
    py -3 -m unittest discover -s tests -v > reports\last_tests.txt 2>&1
    set "TEST_RESULT=%ERRORLEVEL%"
    goto record_result
)

> reports\last_tests.txt echo Status: NOT_RUN
>> reports\last_tests.txt echo Reason: Python 3 was not found under command python or py.
goto open_report

:record_result
if "%TEST_RESULT%"=="0" (
    findstr /C:"Ran 0 tests" reports\last_tests.txt >nul
    if not errorlevel 1 (
        >> reports\last_tests.txt echo Status: ERROR_NO_TESTS
    ) else (
        >> reports\last_tests.txt echo Status: PASS
    )
) else (
    >> reports\last_tests.txt echo Status: FAIL
)

:open_report
start "" notepad.exe "reports\last_tests.txt"
pause
