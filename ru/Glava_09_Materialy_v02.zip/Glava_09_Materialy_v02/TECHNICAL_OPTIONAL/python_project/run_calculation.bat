@echo off
setlocal
cd /d "%~dp0"
if not exist reports mkdir reports

where python >nul 2>nul
if not errorlevel 1 (
    python src\material_calculator.py input.csv reports\last_calculation.txt >nul 2>&1
    if not exist reports\last_calculation.txt goto no_report
    goto open_report
)

where py >nul 2>nul
if not errorlevel 1 (
    py -3 src\material_calculator.py input.csv reports\last_calculation.txt >nul 2>&1
    if not exist reports\last_calculation.txt goto no_report
    goto open_report
)

:not_run
> reports\last_calculation.txt echo Status: NOT_RUN
>> reports\last_calculation.txt echo Reason: Python 3 was not found under command python or py.
goto open_report

:no_report
> reports\last_calculation.txt echo Status: NOT_RUN
>> reports\last_calculation.txt echo Reason: The report could not be created. Check folder permissions.

:open_report
start "" notepad.exe "reports\last_calculation.txt"
pause
