import sys
import unittest
from decimal import Decimal
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from material_calculator import (  # noqa: E402
    CalculationInputError,
    calculate,
    parse_input_rows,
    render_report,
)


def sample_rows():
    return [
        {"parameter": "room_length", "value": "5000", "unit": "mm"},
        {"parameter": "room_width", "value": "4000", "unit": "mm"},
        {"parameter": "reserve", "value": "10", "unit": "%"},
        {"parameter": "package_area", "value": "2.40", "unit": "m2"},
        {"parameter": "package_price", "value": "38.50", "unit": "CHF/package"},
    ]


class MaterialCalculatorTests(unittest.TestCase):
    def test_control_example_returns_ten_packs_and_chf_385(self):
        request = parse_input_rows(sample_rows())
        result = calculate(request)

        self.assertEqual(Decimal("20"), result.room_area_m2)
        self.assertEqual(Decimal("22.0"), result.required_area_m2)
        self.assertEqual(10, result.package_count)
        self.assertEqual(Decimal("24.00"), result.purchased_area_m2)
        self.assertEqual(Decimal("2.00"), result.surplus_area_m2)
        self.assertEqual(Decimal("385.00"), result.total_price_chf)

    def test_fractional_pack_count_is_rounded_up(self):
        rows = sample_rows()
        rows[0]["value"] = "3000"
        request = parse_input_rows(rows)
        result = calculate(request)

        self.assertEqual(Decimal("12"), result.room_area_m2)
        self.assertEqual(Decimal("13.2"), result.required_area_m2)
        self.assertEqual(6, result.package_count)
        self.assertEqual(Decimal("231.00"), result.total_price_chf)

    def test_exact_multiple_does_not_add_an_extra_pack(self):
        rows = sample_rows()
        rows[0]["value"] = "5000"
        rows[1]["value"] = "5000"
        rows[2]["value"] = "0"
        rows[3]["value"] = "2.50"
        request = parse_input_rows(rows)

        self.assertEqual(10, calculate(request).package_count)

    def test_zero_dimension_is_rejected(self):
        rows = sample_rows()
        rows[0]["value"] = "0"
        with self.assertRaisesRegex(CalculationInputError, "Длина должна быть"):
            parse_input_rows(rows)

    def test_negative_dimension_is_rejected(self):
        rows = sample_rows()
        rows[1]["value"] = "-4000"
        with self.assertRaisesRegex(CalculationInputError, "Ширина должна быть"):
            parse_input_rows(rows)

    def test_unknown_unit_is_rejected(self):
        rows = sample_rows()
        rows[0]["unit"] = "m"
        with self.assertRaisesRegex(CalculationInputError, "ожидается mm"):
            parse_input_rows(rows)

    def test_zero_and_upper_boundary_reserve_are_valid(self):
        rows = sample_rows()
        rows[2]["value"] = "0"
        self.assertEqual(Decimal("0"), parse_input_rows(rows).reserve_percent)
        rows[2]["value"] = "100"
        self.assertEqual(Decimal("100"), parse_input_rows(rows).reserve_percent)

    def test_lowest_valid_values_are_accepted(self):
        rows = sample_rows()
        rows[0]["value"] = "1"
        rows[1]["value"] = "1"
        rows[2]["value"] = "0"
        rows[3]["value"] = "0.01"
        rows[4]["value"] = "0.01"
        result = calculate(parse_input_rows(rows))

        self.assertEqual(1, result.package_count)
        self.assertEqual(Decimal("0.01"), result.total_price_chf)

    def test_upper_valid_limits_are_accepted(self):
        rows = sample_rows()
        rows[0]["value"] = "100000"
        rows[1]["value"] = "100000"
        rows[2]["value"] = "100"
        rows[3]["value"] = "100.00"
        rows[4]["value"] = "1000000.00"
        result = calculate(parse_input_rows(rows))

        self.assertEqual(200, result.package_count)
        self.assertEqual(Decimal("200000000.00"), result.total_price_chf)

    def test_reserve_above_upper_boundary_is_rejected(self):
        rows = sample_rows()
        rows[2]["value"] = "100.01"
        with self.assertRaisesRegex(CalculationInputError, "от 0 до 100"):
            parse_input_rows(rows)

    def test_zero_package_area_is_rejected(self):
        rows = sample_rows()
        rows[3]["value"] = "0"
        with self.assertRaisesRegex(CalculationInputError, "Площадь упаковки должна быть"):
            parse_input_rows(rows)

    def test_non_finite_value_is_rejected(self):
        rows = sample_rows()
        rows[2]["value"] = "NaN"
        with self.assertRaisesRegex(CalculationInputError, "NaN"):
            parse_input_rows(rows)

    def test_report_shows_rounding_rule_and_price_boundary(self):
        request = parse_input_rows(sample_rows())
        report = render_report(request, calculate(request))

        self.assertIn("ceil(22.00 / 2.40) = 10", report)
        self.assertIn("CHF 385.00", report)
        self.assertIn("Налоги, доставка и скидки не пересчитывались.", report)


if __name__ == "__main__":
    unittest.main()
