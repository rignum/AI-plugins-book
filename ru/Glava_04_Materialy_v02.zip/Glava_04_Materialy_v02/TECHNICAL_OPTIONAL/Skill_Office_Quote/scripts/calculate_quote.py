#!/usr/bin/env python3
"""Учебный расчёт предложения. Python 3, только стандартная библиотека.

Вызов: python calculate_quote.py catalog.json request_full.json
Читает два файла, печатает JSON; ничего не записывает и не отправляет.
Код выхода: 0 — успех, 2 — нужны исправления входных данных.
"""
import json
import re
import sys
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


def calculate(catalog, request):
    errors = []
    if not isinstance(catalog, dict) or not isinstance(request, dict):
        return {"status": "needs_review", "errors": ["Каталог и заявка должны быть объектами JSON"]}
    allowed_catalog = {"version", "seller", "currency", "scope_note", "services"}
    allowed_request = {"quote_id", "date", "client", "currency", "delivery_terms", "payment_terms", "valid_until", "items"}
    for label, obj, allowed in [("Каталог", catalog, allowed_catalog), ("Заявка", request, allowed_request)]:
        extra = set(obj) - allowed
        if extra:
            errors.append(label + ": неизвестные поля " + ", ".join(sorted(extra)))
    for key in ["version", "seller", "currency", "scope_note"]:
        if not isinstance(catalog.get(key), str) or not catalog[key].strip():
            errors.append("Каталог: отсутствует текстовое поле " + key)
    for key in ["quote_id", "date", "client", "currency", "delivery_terms", "payment_terms", "valid_until"]:
        if not isinstance(request.get(key), str) or not request[key].strip():
            errors.append("Заявка: отсутствует текстовое поле " + key)
    if isinstance(request.get("quote_id"), str) and not re.fullmatch(r"KP-[0-9]{3,8}", request["quote_id"]):
        errors.append("Номер должен иметь вид KP-001 и от 3 до 8 цифр")
    parsed_dates = {}
    for key in ["date", "valid_until"]:
        try:
            raw = request.get(key)
            if not isinstance(raw, str) or not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", raw):
                raise ValueError()
            parsed_dates[key] = date.fromisoformat(raw)
        except ValueError:
            errors.append("Заявка: неверная дата " + key + ", нужен формат ГГГГ-ММ-ДД")
    if len(parsed_dates) == 2 and parsed_dates["valid_until"] < parsed_dates["date"]:
        errors.append("Срок действия раньше даты предложения")
    if catalog.get("currency") != "EUR" or request.get("currency") != "EUR":
        errors.append("Учебный расчёт поддерживает только EUR без конвертации")

    services = catalog.get("services")
    lookup = {}
    if not isinstance(services, list) or not services:
        errors.append("Каталог: нужен непустой список services")
        services = []
    for index, service in enumerate(services, 1):
        prefix = "Каталог, услуга " + str(index) + ": "
        if not isinstance(service, dict):
            errors.append(prefix + "нужен объект")
            continue
        if set(service) != {"code", "name", "unit", "price"}:
            errors.append(prefix + "нужны только code, name, unit, price")
            continue
        if not all(isinstance(service[k], str) and service[k].strip() for k in service):
            errors.append(prefix + "все поля должны быть непустыми строками")
            continue
        code = service["code"]
        if code in lookup:
            errors.append(prefix + "повторный код " + code)
            continue
        if not re.fullmatch(r"[A-Z][A-Z0-9_]{0,29}", code):
            errors.append(prefix + "неверный код")
            continue
        if not re.fullmatch(r"(?:0|[1-9][0-9]{0,6})\.[0-9]{2}", service["price"]):
            errors.append(prefix + "цена должна быть строкой вида 18.00")
            continue
        price = Decimal(service["price"])
        if price <= 0:
            errors.append(prefix + "цена должна быть положительной")
            continue
        lookup[code] = service

    items = request.get("items")
    if not isinstance(items, list) or not items:
        errors.append("Заявка: нужен непустой список items")
        items = []
    rows = []
    seen = set()
    for index, item in enumerate(items, 1):
        prefix = "Заявка, позиция " + str(index) + ": "
        if not isinstance(item, dict) or set(item) != {"code", "quantity"}:
            errors.append(prefix + "нужны только code и quantity; цену задаёт каталог")
            continue
        code, quantity = item["code"], item["quantity"]
        if not isinstance(code, str) or code not in lookup:
            errors.append(prefix + "неизвестный код услуги " + str(code))
            continue
        if code in seen:
            errors.append(prefix + "повторный код услуги " + code)
            continue
        seen.add(code)
        if type(quantity) is not int or not 1 <= quantity <= 1000000:
            errors.append(prefix + "quantity должно быть целым числом от 1 до 1000000")
            continue
        service = lookup[code]
        amount = (Decimal(service["price"]) * quantity).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        rows.append({"code": code, "name": service["name"], "unit": service["unit"], "quantity": quantity, "price": service["price"], "amount": format(amount, ".2f")})
    if errors:
        return {"status": "needs_review", "errors": errors}
    total = sum((Decimal(row["amount"]) for row in rows), Decimal("0.00"))
    return {"status": "ok", "catalog_version": catalog["version"], "seller": catalog["seller"],
            "quote_id": request["quote_id"], "date": request["date"], "client": request["client"],
            "currency": "EUR", "rows": rows, "total": format(total, ".2f"),
            "delivery_terms": request["delivery_terms"], "payment_terms": request["payment_terms"],
            "valid_until": request["valid_until"], "scope_note": catalog["scope_note"]}


def reject_duplicate_keys(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError("Повторное поле JSON: " + key)
        obj[key] = value
    return obj


def main():
    if len(sys.argv) != 3:
        print(json.dumps({"status": "needs_review", "errors": ["Вызов: python calculate_quote.py catalog.json request_full.json"]}, ensure_ascii=False))
        return 2
    try:
        objects = []
        for filename in sys.argv[1:]:
            with open(filename, encoding="utf-8-sig") as stream:
                objects.append(json.load(stream, object_pairs_hook=reject_duplicate_keys))
        result = calculate(*objects)
    except (OSError, ValueError, InvalidOperation, UnicodeError) as exc:
        result = {"status": "needs_review", "errors": ["Не удалось прочитать или проверить входные данные: " + str(exc)]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "ok" else 2


if __name__ == "__main__":
    sys.exit(main())
