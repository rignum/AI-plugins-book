(function(root,factory){
 const api=factory(); if(typeof module==='object'&&module.exports) module.exports=api; root.WindowsReportTool=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
 const KNOWN=new Set(['COLLECTED','EMPTY','NOT_COLLECTED','ACCESS_DENIED','UNSUPPORTED','ERROR','PARTIAL']);
 function n(v){return typeof v==='number'&&Number.isFinite(v)}
 function fmt(v,d=1){return n(v)?v.toFixed(d):'—'}
 function pct(free,total){return total>0?free/total*100:null}
 function requireStatus(obj,name,issues){if(!obj||typeof obj!=='object'){issues.push(`отсутствует раздел ${name}`);return null;} if(!KNOWN.has(obj.status)){issues.push(`раздел ${name}: неизвестный или отсутствующий status`);} return obj.status;}
 function analyze(data,name='report.json'){
   const r={filename:name,valid:true,issues:[],warnings:[],facts:[],signals:[],unknowns:[],statuses:{},disks:[],program_count:null,event_count:null};
   if(!data||typeof data!=='object'||Array.isArray(data)){r.valid=false;r.issues.push('корневое значение JSON должно быть объектом');return r;}
   if(data.schema_version!=='1.0') r.warnings.push(`schema_version: ожидалась 1.0, получено ${data.schema_version??'не указано'}`);
   if(data.is_fictional_example!==true) r.warnings.push('файл не помечен как учебный вымышленный пример');
   const sections=['system','storage','installed_programs','system_events','autostart','large_files'];
   for(const s of sections) r.statuses[s]=requireStatus(data[s],s,r.issues);
   const sys=data.system||{};
   if(r.statuses.system==='COLLECTED'){
     if(sys.os&&sys.os.caption) r.facts.push(`Windows: ${sys.os.caption}, ${sys.os.architecture||'архитектура не указана'}`);
     if(Array.isArray(sys.cpu)&&sys.cpu[0]) r.facts.push(`Процессор: ${sys.cpu[0].name||'не указано'}, ядер ${sys.cpu[0].cores??'—'}, логических процессоров ${sys.cpu[0].logical_processors??'—'}`);
     if(sys.memory&&n(sys.memory.total_gb)) r.facts.push(`Оперативная память: ${fmt(sys.memory.total_gb,1)} ГБ`);
   } else if(r.statuses.system) r.unknowns.push(`system: ${r.statuses.system}`);
   const st=data.storage||{};
   if(r.statuses.storage==='COLLECTED'){
     if(!Array.isArray(st.items)){r.issues.push('storage.items должен быть массивом');}
     else for(const d of st.items){
       if(!d||!d.device||!n(d.total_gb)||!n(d.free_gb)||d.total_gb<=0){r.issues.push(`некорректная запись диска ${d&&d.device?d.device:'без имени'}`);continue;}
       const p=pct(d.free_gb,d.total_gb); const attention=p<10||d.free_gb<30;
       const row={device:d.device,total_gb:d.total_gb,free_gb:d.free_gb,free_percent:p,attention}; r.disks.push(row);
       r.facts.push(`${d.device}: свободно ${fmt(d.free_gb,1)} ГБ из ${fmt(d.total_gb,1)} ГБ (${fmt(p,1)} %)`);
       if(attention) r.signals.push(`${d.device}: значение ниже учебного порога «менее 10 % ИЛИ менее 30 ГБ»`);
       if(n(d.free_percent)&&Math.abs(d.free_percent-p)>0.2) r.warnings.push(`${d.device}: сохранённый free_percent не совпадает с пересчётом`);
     }
   } else if(r.statuses.storage) r.unknowns.push(`storage: ${r.statuses.storage}`);
   const ip=data.installed_programs||{};
   if(r.statuses.installed_programs==='COLLECTED'){
     if(!Array.isArray(ip.items)){r.issues.push('installed_programs.items должен быть массивом');}
     else {r.program_count=ip.items.length; r.facts.push(`Найденные регистрации программ: ${ip.items.length}; источник не считается полным перечнем приложений`);}
   } else if(r.statuses.installed_programs) r.unknowns.push(`installed_programs: ${r.statuses.installed_programs}`);
   const ev=data.system_events||{};
   if(r.statuses.system_events==='COLLECTED'||r.statuses.system_events==='PARTIAL'){
     if(!Array.isArray(ev.items)){r.issues.push('system_events.items должен быть массивом');}
     else {r.event_count=ev.items.length; r.facts.push(`События System в предоставленной выборке: ${ev.items.length}`);}
     if(r.statuses.system_events==='PARTIAL'||ev.possibly_truncated===true) r.unknowns.push('system_events: выборка помечена как неполная или возможно усечённая');
   } else if(r.statuses.system_events==='EMPTY') r.unknowns.push('system_events: источник проверен, но за выбранный период записей не найдено; это не означает «проблем нет»');
   else if(r.statuses.system_events) r.unknowns.push(`system_events: ${r.statuses.system_events}; источник не следует считать проверенным полностью`);
   for(const s of ['autostart','large_files']){
     const stt=r.statuses[s];
     if(stt&&stt!=='COLLECTED') r.unknowns.push(`${s}: ${stt}`);
   }
   if(r.issues.length) r.valid=false;
   return r;
 }
 function textSummary(r){
   const L=[]; L.push(`Файл: ${r.filename}`); L.push(`Статус структуры: ${r.valid?'OK':'INVALID'}`); L.push('');
   L.push('Статусы разделов:'); for(const [k,v] of Object.entries(r.statuses)) L.push(`- ${k}: ${v||'не определён'}`); L.push('');
   L.push('Факты:'); (r.facts.length?r.facts:['нет подтверждённых фактов']).forEach(x=>L.push('- '+x)); L.push('');
   L.push('Сигналы:'); (r.signals.length?r.signals:['нет сигналов по учебному порогу']).forEach(x=>L.push('- '+x)); L.push('');
   L.push('Неизвестно/неполно:'); (r.unknowns.length?r.unknowns:['нет дополнительных отметок']).forEach(x=>L.push('- '+x));
   if(r.warnings.length){L.push('');L.push('Предупреждения:');r.warnings.forEach(x=>L.push('- '+x));}
   if(r.issues.length){L.push('');L.push('Ошибки структуры:');r.issues.forEach(x=>L.push('- '+x));}
   return L.join('\n');
 }
 return {analyze,textSummary,fmt};
});