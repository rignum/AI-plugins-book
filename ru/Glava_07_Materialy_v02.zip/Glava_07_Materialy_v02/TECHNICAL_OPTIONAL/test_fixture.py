import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "materials" / "fictional_report.json"
SCRIPT = ROOT / "scripts" / "Collect-WindowsReport.ps1"


class DiagnosticPackageChecks(unittest.TestCase):
    def test_fixture_is_explicitly_fictional_and_has_expected_sections(self):
        data = json.loads(FIXTURE.read_text(encoding="utf-8"))
        self.assertTrue(data["is_fictional_example"])
        self.assertEqual(data["system"]["status"], "COLLECTED")
        self.assertEqual(data["storage"]["status"], "COLLECTED")
        self.assertEqual(data["installed_programs"]["returned_count"], 3)
        self.assertEqual(data["system_events"]["lookback_days"], 7)
        self.assertEqual(data["autostart"]["status"], "NOT_COLLECTED")
        self.assertEqual(data["large_files"]["status"], "NOT_COLLECTED")

    def test_storage_math_and_training_threshold(self):
        data = json.loads(FIXTURE.read_text(encoding="utf-8"))
        disks = {x["device"]: x for x in data["storage"]["items"]}
        c_drive = disks["C:"]
        d_drive = disks["D:"]
        c_pct = c_drive["free_gb"] / c_drive["total_gb"] * 100
        d_pct = d_drive["free_gb"] / d_drive["total_gb"] * 100
        self.assertAlmostEqual(c_pct, 5.078125)
        self.assertAlmostEqual(d_pct, 62.0)
        self.assertTrue(c_pct < 10 or c_drive["free_gb"] < 30)
        self.assertFalse(d_pct < 10 or d_drive["free_gb"] < 30)

    def test_fixture_does_not_include_raw_event_messages(self):
        data = json.loads(FIXTURE.read_text(encoding="utf-8"))
        for event in data["system_events"]["items"]:
            self.assertNotIn("message", event)
            self.assertIn(event["level"], {"Warning", "Error", "Critical"})

    def test_collector_is_bounded_and_has_no_mutating_or_network_commands(self):
        source = SCRIPT.read_text(encoding="utf-8")
        forbidden = [
            r"\bRemove-Item\b",
            r"\bSet-ItemProperty\b",
            r"\bRemove-ItemProperty\b",
            r"\bClear-EventLog\b",
            r"\bSet-ExecutionPolicy\b",
            r"\bInvoke-WebRequest\b",
            r"\bInvoke-RestMethod\b",
            r"\bStart-Process\b",
            r"\bUninstall-Package\b",
            r"\bDisable-ScheduledTask\b",
            r"\bStop-Service\b",
            r"\bSet-Service\b",
        ]
        for pattern in forbidden:
            self.assertIsNone(re.search(pattern, source, re.IGNORECASE), pattern)
        self.assertIn("Get-CimInstance", source)
        self.assertIn("Get-WinEvent", source)
        self.assertIn("-MaxEvents 20", source)
        self.assertIn("Win32_LogicalDisk", source)
        self.assertNotIn("Win32_Product", source)
        self.assertIn('status = "NOT_COLLECTED"', source)
        self.assertIn("Read-Host", source)
        self.assertIn('$env:OS -ne "Windows_NT"', source)
        self.assertIn("Test-Path -LiteralPath $fullOutputPath", source)
        self.assertIn("[System.IO.FileMode]::CreateNew", source)


if __name__ == "__main__":
    unittest.main()
