[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$OutputPath,

    [ValidateRange(1, 30)]
    [int]$Days = 7
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

if ($env:OS -ne "Windows_NT") {
    throw "Этот учебный сценарий предназначен только для Windows."
}

$powerShellVersion = $PSVersionTable.PSVersion
if ($powerShellVersion.Major -lt 5 -or ($powerShellVersion.Major -eq 5 -and $powerShellVersion.Minor -lt 1)) {
    throw "Требуется Windows PowerShell 5.1 или более новая версия PowerShell."
}

$fullOutputPath = [System.IO.Path]::GetFullPath($OutputPath)
if ([System.IO.Path]::GetExtension($fullOutputPath) -ne ".json") {
    throw "Укажите путь к новому файлу с расширением .json."
}
if (Test-Path -LiteralPath $fullOutputPath) {
    throw "Файл уже существует. Выберите новое имя; сценарий не перезаписывает отчёты."
}

Write-Host ""
Write-Host "Перед сбором будут прочитаны только локальные сведения:"
Write-Host "- Windows, процессор и объём памяти;"
Write-Host "- локальные фиксированные диски и свободное место;"
Write-Host "- записи зарегистрированных программ из выбранных разделов реестра;"
Write-Host "- до 20 событий уровня Critical, Error или Warning из журнала System за $Days дн."
Write-Host "Не читаются документы, полные сообщения событий, автозагрузка и содержимое файлов."
Write-Host "Создаётся новый JSON по выбранному пути; сеть не используется."
$confirmation = Read-Host "Продолжить сбор? Введите Да для согласия"
if ($confirmation -notmatch "^(?i:да|д|yes|y)$") {
    Write-Host "Сбор отменён. Диагностические источники не запрашивались."
    return
}

function Get-ReadStatus {
    param(
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord]$ErrorRecord
    )

    $errorId = [string]$ErrorRecord.FullyQualifiedErrorId
    if ($errorId -match "NoMatchingEventsFound|PathNotFound|ItemNotFound") {
        return "EMPTY"
    }
    if ($ErrorRecord.CategoryInfo.Category -eq "PermissionDenied" -or
        $ErrorRecord.Exception -is [System.UnauthorizedAccessException] -or
        $ErrorRecord.Exception -is [System.Security.SecurityException]) {
        return "ACCESS_DENIED"
    }
    return "ERROR"
}

$system = [ordered]@{
    status = "NOT_COLLECTED"
    os_status = "NOT_COLLECTED"
    os = $null
    cpu_status = "NOT_COLLECTED"
    cpu = @()
    memory_status = "NOT_COLLECTED"
    memory = $null
}

try {
    $osRecord = Get-CimInstance -ClassName Win32_OperatingSystem -Property Caption, Version, BuildNumber, OSArchitecture, TotalVisibleMemorySize, FreePhysicalMemory -ErrorAction Stop
    if ($null -eq $osRecord) {
        $system.os_status = "EMPTY"
    }
    else {
        $system.os_status = "COLLECTED"
        $system.os = [ordered]@{
            caption = [string]$osRecord.Caption
            version = [string]$osRecord.Version
            build = [string]$osRecord.BuildNumber
            architecture = [string]$osRecord.OSArchitecture
        }
        if ($null -ne $osRecord.TotalVisibleMemorySize -and
            $null -ne $osRecord.FreePhysicalMemory -and
            [double]$osRecord.TotalVisibleMemorySize -gt 0) {
            $system.memory_status = "COLLECTED"
            $system.memory = [ordered]@{
                total_gb = [math]::Round((([double]$osRecord.TotalVisibleMemorySize * 1KB) / 1GB), 2)
                available_gb = [math]::Round((([double]$osRecord.FreePhysicalMemory * 1KB) / 1GB), 2)
            }
        }
        else {
            $system.memory_status = "EMPTY"
        }
    }
}
catch {
    $system.os_status = Get-ReadStatus $_
    $system.memory_status = Get-ReadStatus $_
}

try {
    $cpuRecords = @(Get-CimInstance -ClassName Win32_Processor -Property Name, NumberOfCores, NumberOfLogicalProcessors -ErrorAction Stop)
    if ($cpuRecords.Count -eq 0) {
        $system.cpu_status = "EMPTY"
    }
    else {
        $system.cpu_status = "COLLECTED"
        $system.cpu = @(
            foreach ($cpuRecord in $cpuRecords) {
                [pscustomobject]@{
                    name = [string]$cpuRecord.Name
                    cores = [int]$cpuRecord.NumberOfCores
                    logical_processors = [int]$cpuRecord.NumberOfLogicalProcessors
                }
            }
        )
    }
}
catch {
    $system.cpu_status = Get-ReadStatus $_
}

$systemParts = @($system.os_status, $system.cpu_status, $system.memory_status)
if ($systemParts -contains "PARTIAL" -or $systemParts -contains "ERROR" -or $systemParts -contains "ACCESS_DENIED") {
    if ($systemParts -contains "COLLECTED") {
        $system.status = "PARTIAL"
    }
    elseif ($systemParts -contains "ACCESS_DENIED") {
        $system.status = "ACCESS_DENIED"
    }
    else {
        $system.status = "ERROR"
    }
}
elseif ($systemParts -contains "COLLECTED") {
    if ($systemParts -contains "EMPTY") {
        $system.status = "PARTIAL"
    }
    else {
        $system.status = "COLLECTED"
    }
}
else {
    $system.status = "EMPTY"
}

$storage = [ordered]@{
    status = "NOT_COLLECTED"
    items = @()
}
try {
    $diskRecords = @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DriveType=3" -Property DeviceID, FileSystem, Size, FreeSpace -ErrorAction Stop |
        Where-Object { $null -ne $_.Size -and [double]$_.Size -gt 0 })
    if ($diskRecords.Count -eq 0) {
        $storage.status = "EMPTY"
    }
    else {
        $storage.status = "COLLECTED"
        $storage.items = @(
            foreach ($diskRecord in $diskRecords) {
                $totalGb = [double]$diskRecord.Size / 1GB
                $freeGb = [double]$diskRecord.FreeSpace / 1GB
                [pscustomobject]@{
                    device = [string]$diskRecord.DeviceID
                    filesystem = [string]$diskRecord.FileSystem
                    total_gb = [math]::Round($totalGb, 2)
                    free_gb = [math]::Round($freeGb, 2)
                    free_percent = [math]::Round(($freeGb / $totalGb) * 100, 1)
                }
            }
        )
    }
}
catch {
    $storage.status = Get-ReadStatus $_
    $storage.items = @()
}

$programRoots = @(
    [pscustomobject]@{
        scope = "machine_64"
        path = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
    },
    [pscustomobject]@{
        scope = "machine_32"
        path = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    },
    [pscustomobject]@{
        scope = "current_user"
        path = "Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
    }
)

$programRecords = @()
$programSourceStatuses = @()
foreach ($programRoot in $programRoots) {
    $rootItems = @()
    $rootReadErrors = 0
    try {
        $programKeys = @(Get-ChildItem -LiteralPath $programRoot.path -ErrorAction Stop)
        foreach ($programKey in $programKeys) {
            try {
                $programEntry = Get-ItemProperty -LiteralPath $programKey.PSPath -ErrorAction Stop
                if (-not [string]::IsNullOrWhiteSpace([string]$programEntry.DisplayName)) {
                    $rootItems += [pscustomobject]@{
                        name = ([string]$programEntry.DisplayName).Trim()
                        version = ([string]$programEntry.DisplayVersion).Trim()
                        publisher = ([string]$programEntry.Publisher).Trim()
                    }
                }
            }
            catch {
                $rootReadErrors++
            }
        }

        if ($programKeys.Count -eq 0) {
            $rootStatus = "EMPTY"
        }
        elseif ($rootReadErrors -gt 0) {
            $rootStatus = "PARTIAL"
        }
        else {
            $rootStatus = "COLLECTED"
        }
    }
    catch {
        $rootStatus = Get-ReadStatus $_
    }

    $programRecords += $rootItems
    $programSourceStatuses += [pscustomobject]@{
        scope = $programRoot.scope
        status = $rootStatus
        returned_records = $rootItems.Count
        unreadable_entries = $rootReadErrors
    }
}

$uniquePrograms = @($programRecords | Sort-Object -Property name, version, publisher -Unique)
$programLimit = 100
$shownPrograms = @($uniquePrograms | Select-Object -First $programLimit)
$programStates = @($programSourceStatuses | ForEach-Object { $_.status })
$programsStatus = "ERROR"
if ($programStates -contains "PARTIAL" -or $programStates -contains "ERROR" -or $programStates -contains "ACCESS_DENIED" -or $uniquePrograms.Count -gt $programLimit) {
    if ($programStates -contains "COLLECTED" -or $programStates -contains "PARTIAL" -or $programStates -contains "EMPTY") {
        $programsStatus = "PARTIAL"
    }
    elseif ($programStates -contains "ACCESS_DENIED") {
        $programsStatus = "ACCESS_DENIED"
    }
}
elseif ($programStates -contains "COLLECTED") {
    $programsStatus = "COLLECTED"
}
elseif ($programStates -contains "EMPTY") {
    $programsStatus = "EMPTY"
}
elseif ($programStates -contains "ACCESS_DENIED") {
    $programsStatus = "ACCESS_DENIED"
}

$installedPrograms = [ordered]@{
    status = $programsStatus
    source_note = "Только записи в выбранных разделах регистрации удаления программ; это не исчерпывающий список."
    source_statuses = @($programSourceStatuses)
    returned_count = $shownPrograms.Count
    maximum_returned = $programLimit
    possibly_truncated = [bool]($uniquePrograms.Count -gt $programLimit)
    items = @($shownPrograms)
}

$since = (Get-Date).AddDays(-$Days)
$systemEvents = [ordered]@{
    status = "NOT_COLLECTED"
    channel = "System"
    lookback_days = $Days
    maximum_returned = 20
    possibly_truncated = $false
    items = @()
}
try {
    $eventFilter = @{
        LogName = "System"
        StartTime = $since
        Level = @(1, 2, 3)
    }
    $eventRecords = @(Get-WinEvent -FilterHashtable $eventFilter -MaxEvents 20 -ErrorAction Stop)
    $eventItems = @(
        foreach ($eventRecord in $eventRecords) {
            [pscustomobject]@{
                time = if ($eventRecord.TimeCreated) { $eventRecord.TimeCreated.ToString("o") } else { $null }
                id = [int]$eventRecord.Id
                provider = [string]$eventRecord.ProviderName
                level = [string]$eventRecord.LevelDisplayName
            }
        }
    )
    $systemEvents.items = @($eventItems)
    $systemEvents.possibly_truncated = [bool]($eventItems.Count -ge 20)
    if ($eventItems.Count -eq 0) {
        $systemEvents.status = "EMPTY"
    }
    elseif ($systemEvents.possibly_truncated) {
        $systemEvents.status = "PARTIAL"
    }
    else {
        $systemEvents.status = "COLLECTED"
    }
}
catch {
    $systemEvents.status = Get-ReadStatus $_
    $systemEvents.items = @()
}

$report = [ordered]@{
    schema_version = "1.0"
    generated_at = (Get-Date).ToString("o")
    collector_version = "0.1.0"
    scope = [ordered]@{
        machine_scope = "local"
        lookback_days = $Days
        maximum_system_events = 20
        event_messages_included = $false
        network_access = $false
    }
    system = $system
    storage = $storage
    installed_programs = $installedPrograms
    system_events = $systemEvents
    autostart = [ordered]@{
        status = "NOT_COLLECTED"
    }
    large_files = [ordered]@{
        status = "NOT_COLLECTED"
    }
}

$parentPath = [System.IO.Path]::GetDirectoryName($fullOutputPath)
if (-not [string]::IsNullOrWhiteSpace($parentPath) -and -not (Test-Path -LiteralPath $parentPath)) {
    New-Item -ItemType Directory -Path $parentPath -ErrorAction Stop | Out-Null
}
if (Test-Path -LiteralPath $fullOutputPath) {
    throw "Файл появился по указанному пути во время сбора. Он не был перезаписан."
}

$jsonText = ConvertTo-Json -InputObject $report -Depth 8
$utf8WithoutBom = New-Object System.Text.UTF8Encoding -ArgumentList $false
$outputBytes = $utf8WithoutBom.GetBytes($jsonText)
$outputStream = [System.IO.File]::Open(
    $fullOutputPath,
    [System.IO.FileMode]::CreateNew,
    [System.IO.FileAccess]::Write,
    [System.IO.FileShare]::None
)
try {
    $outputStream.Write($outputBytes, 0, $outputBytes.Length)
}
finally {
    $outputStream.Dispose()
}
Write-Host "Сбор завершён. Отчёт сохранён по выбранному пути. Откройте его и проверьте содержимое перед передачей кому-либо."
