"""Local task preview and mock Trello creation for Chapter 11.

This module never opens a network connection. The simulated create operation
writes fake card IDs to the local reports directory only.
"""

import argparse
import csv
import json
from collections import Counter
from datetime import date
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = PROJECT_ROOT / "data"
REPORTS_ROOT = PROJECT_ROOT / "reports"
OUTPUT_FIELDS = [
    "task_id", "title", "description", "owner_name", "owner_department", "member_id",
    "due_date", "board_id", "list_id", "list_name", "status", "review_reason",
    "source_ref", "external_key",
]


def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def resolve_owner(row, people):
    name = (row.get("owner_name") or "").strip()
    department = (row.get("owner_department") or "").strip()
    if not name:
        return "", "", "", "Ответственный не указан"
    matches = [p for p in people if p["display_name"].strip() == name]
    if department:
        matches = [p for p in matches if p["department"].strip().casefold() == department.casefold()]
    if len(matches) == 0:
        return name, department, "", "Участник не найден в справочнике"
    if len(matches) > 1:
        return name, department, "", "Несколько участников с таким именем; нужно уточнение"
    person = matches[0]
    return person["display_name"], person["department"], person["member_id"], ""


def validate_due(value):
    value = (value or "").strip()
    if not value:
        return "", "Срок не указан"
    try:
        parsed = date.fromisoformat(value)
    except ValueError:
        return value, "Срок не распознан как календарная дата YYYY-MM-DD"
    if parsed.isoformat() != value:
        return value, "Используйте дату в формате YYYY-MM-DD"
    return value, ""


def build_preview(data_root=DATA_ROOT):
    candidates = read_csv(data_root / "task_candidates.csv")
    people = read_csv(data_root / "people.csv")
    project = read_json(data_root / "project_map.json")
    duplicate_ids = {key for key, count in Counter(row["task_id"] for row in candidates).items() if count > 1}
    preview = []

    for row in candidates:
        task_id = row["task_id"].strip()
        title = row["title"].strip()
        decision = row["decision"].strip().upper()
        flags = []
        owner, department, member_id, owner_issue = resolve_owner(row, people)
        due, due_issue = validate_due(row.get("due_date"))

        if task_id in duplicate_ids:
            status = "ERROR"
            flags.append("Повторяется ID строки источника")
        elif decision in {"IDEA", "QUESTION", "DISCUSSION"}:
            status = "NOT_A_TASK"
            flags.append("Запись не подтверждена как поручение")
        elif decision != "TASK":
            status = "ERROR"
            flags.append("Неизвестный тип записи; требуется разметка")
        else:
            if not title:
                flags.append("Пустое название задачи")
            if owner_issue:
                flags.append(owner_issue)
            if due_issue:
                flags.append(due_issue)
            if row["project_key"].strip() != project["project_key"]:
                flags.append("Проект отсутствует в карте проекта")
            if not row["source_ref"].strip():
                flags.append("Не указан источник в протоколе")

            if not flags:
                status = "READY"
            else:
                owner_block = any("Ответственный" in f or "участник" in f or "участников" in f for f in flags)
                due_block = any("Срок" in f or "дат" in f for f in flags)
                if owner_block and due_block:
                    status = "NEEDS_OWNER_AND_DUE"
                elif owner_block:
                    status = "NEEDS_OWNER"
                elif due_block:
                    status = "NEEDS_DUE"
                else:
                    status = "ERROR"

        preview.append({
            "task_id": task_id,
            "title": title,
            "description": row["description"].strip(),
            "owner_name": owner,
            "owner_department": department,
            "member_id": member_id,
            "due_date": due,
            "board_id": project["board_id"],
            "list_id": project["default_list_id"],
            "list_name": project["default_list_name"],
            "status": status,
            "review_reason": "; ".join(flags),
            "source_ref": row["source_ref"].strip(),
            "external_key": f"{project['source_meeting_id']}:{task_id}",
        })
    return preview


def write_preview(rows, output_path):
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def load_approved_ids(data_root):
    path = data_root / "approved_task_ids.txt"
    return [line.strip() for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def simulate_create(data_root=DATA_ROOT, reports_root=REPORTS_ROOT, confirm=False):
    if not confirm:
        raise ValueError("Нужно отдельное подтверждение симуляции: передайте --confirm")
    preview = build_preview(data_root)
    by_id = {row["task_id"]: row for row in preview}
    approved_ids = load_approved_ids(data_root)
    if len(approved_ids) != len(set(approved_ids)):
        raise ValueError("В списке подтверждения есть повторяющийся task_id")
    for task_id in approved_ids:
        if task_id not in by_id:
            raise ValueError(f"Подтверждённая задача {task_id} отсутствует в предварительном списке")
        if by_id[task_id]["status"] != "READY":
            raise ValueError(f"Задача {task_id} не готова: {by_id[task_id]['status']}")

    reports_root.mkdir(parents=True, exist_ok=True)
    cards_path = reports_root / "simulated_trello_cards.json"
    ledger_path = reports_root / "operation_ledger.json"
    cards = json.loads(cards_path.read_text(encoding="utf-8")) if cards_path.exists() else []
    ledger = json.loads(ledger_path.read_text(encoding="utf-8")) if ledger_path.exists() else {}
    card_by_key = {card["external_key"]: card for card in cards}
    results = []
    created_count = 0

    for task_id in approved_ids:
        row = by_id[task_id]
        key = row["external_key"]
        existing = ledger.get(key) or card_by_key.get(key)
        if existing:
            card_id = existing["card_id"] if "card_id" in existing else existing["id"]
            results.append({"task_id": task_id, "status": "ALREADY_CREATED_IN_SIMULATION", "card_id": card_id})
            ledger[key] = {"card_id": card_id, "task_id": task_id}
            continue

        card_id = f"DEMO-CARD-{task_id}"
        card = {
            "id": card_id,
            "external_key": key,
            "board_id": row["board_id"],
            "list_id": row["list_id"],
            "name": row["title"],
            "description": f"{row['description']}\nИсточник: {row['source_ref']}\nКлюч: {key}",
            "member_id": row["member_id"],
            "due_date": row["due_date"],
            "simulated": True,
        }
        cards.append(card)
        card_by_key[key] = card
        ledger[key] = {"card_id": card_id, "task_id": task_id}
        results.append({"task_id": task_id, "status": "CREATED_IN_SIMULATION", "card_id": card_id})
        created_count += 1

    cards_path.write_text(json.dumps(cards, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result = {
        "mode": "LOCAL_SIMULATION_ONLY",
        "new_cards_this_run": created_count,
        "total_mock_cards": len(cards),
        "results": results,
        "network_requests_sent": 0,
    }
    (reports_root / "creation_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description="Local task preview and mock Trello simulation")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("preview", help="validate and write a local preview")
    create_parser = subparsers.add_parser("simulate-create", help="write local mock cards; never contacts Trello")
    create_parser.add_argument("--confirm", action="store_true", help="confirm the local simulation")
    args = parser.parse_args()

    if args.command == "preview":
        rows = build_preview()
        target = REPORTS_ROOT / "preview_tasks.csv"
        write_preview(rows, target)
        counts = Counter(row["status"] for row in rows)
        print(f"Предварительный список сохранён: {target}")
        print("Статусы:", ", ".join(f"{name}={count}" for name, count in sorted(counts.items())))
        print("Режим: локальная проверка; карточки не создавались.")
    else:
        result = simulate_create(confirm=args.confirm)
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
