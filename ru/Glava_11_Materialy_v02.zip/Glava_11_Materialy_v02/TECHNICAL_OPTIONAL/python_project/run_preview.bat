@echo off
setlocal
cd /d "%~dp0"
py -3 src\task_pipeline.py preview
if errorlevel 1 pause
