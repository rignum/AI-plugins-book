import csv
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SRC))
import task_pipeline


class TaskPipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.data = self.root / "data"
        self.reports = self.root / "reports"
        shutil.copytree(Path(__file__).resolve().parents[1] / "data", self.data)

    def tearDown(self):
        self.temp.cleanup()

    def rows_by_id(self):
        return {row["task_id"]: row for row in task_pipeline.build_preview(self.data)}

    def test_only_two_unambiguous_tasks_are_ready(self):
        rows = self.rows_by_id()
        self.assertEqual([key for key, row in rows.items() if row["status"] == "READY"], ["T-01", "T-02"])

    def test_missing_deadline_is_blocked(self):
        self.assertEqual(self.rows_by_id()["T-03"]["status"], "NEEDS_DUE")

    def test_duplicate_display_name_is_not_assigned(self):
        row = self.rows_by_id()["T-04"]
        self.assertEqual(row["status"], "NEEDS_OWNER")
        self.assertEqual(row["member_id"], "")

    def test_discussion_idea_is_not_a_task(self):
        self.assertEqual(self.rows_by_id()["T-05"]["status"], "NOT_A_TASK")

    def test_missing_owner_is_not_guessed(self):
        row = self.rows_by_id()["T-06"]
        self.assertEqual(row["status"], "NEEDS_OWNER")
        self.assertEqual(row["member_id"], "")

    def test_preview_does_not_create_cards(self):
        rows = task_pipeline.build_preview(self.data)
        task_pipeline.write_preview(rows, self.reports / "preview_tasks.csv")
        self.assertFalse((self.reports / "simulated_trello_cards.json").exists())

    def test_creation_requires_separate_confirmation(self):
        with self.assertRaisesRegex(ValueError, "отдельное подтверждение"):
            task_pipeline.simulate_create(self.data, self.reports, confirm=False)

    def test_blocked_task_cannot_be_approved(self):
        (self.data / "approved_task_ids.txt").write_text("T-01\nT-03\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "не готова"):
            task_pipeline.simulate_create(self.data, self.reports, confirm=True)

    def test_second_run_reuses_existing_mock_cards(self):
        first = task_pipeline.simulate_create(self.data, self.reports, confirm=True)
        second = task_pipeline.simulate_create(self.data, self.reports, confirm=True)
        cards = json.loads((self.reports / "simulated_trello_cards.json").read_text(encoding="utf-8"))
        self.assertEqual(first["new_cards_this_run"], 2)
        self.assertEqual(second["new_cards_this_run"], 0)
        self.assertEqual(len(cards), 2)

    def test_duplicate_approved_id_is_rejected(self):
        (self.data / "approved_task_ids.txt").write_text("T-01\nT-01\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "повторяющийся"):
            task_pipeline.simulate_create(self.data, self.reports, confirm=True)

    def test_unknown_decision_type_is_not_treated_as_a_task(self):
        path = self.data / "task_candidates.csv"
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        rows[0]["decision"] = "MAYBE"
        with path.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        self.assertEqual(self.rows_by_id()["T-01"]["status"], "ERROR")

    def test_repeated_source_task_id_is_blocked(self):
        path = self.data / "task_candidates.csv"
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        rows[1]["task_id"] = "T-01"
        with path.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        statuses = [row["status"] for row in task_pipeline.build_preview(self.data) if row["task_id"] == "T-01"]
        self.assertEqual(statuses, ["ERROR", "ERROR"])


if __name__ == "__main__":
    unittest.main()
