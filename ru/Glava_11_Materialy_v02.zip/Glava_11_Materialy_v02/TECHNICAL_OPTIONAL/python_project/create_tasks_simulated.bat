@echo off
setlocal
cd /d "%~dp0"
echo Учебный режим: будут записаны только локальные примеры; Trello не подключён.
py -3 src\task_pipeline.py simulate-create --confirm
if errorlevel 1 pause
