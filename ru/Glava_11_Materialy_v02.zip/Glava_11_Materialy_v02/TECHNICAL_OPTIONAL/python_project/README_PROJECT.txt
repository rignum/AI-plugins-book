УЧЕБНЫЙ ПРОЕКТ: задачи из протокола

ВАЖНО: этот проект не подключается к Trello и не отправляет сетевые запросы.
Сценарий create_tasks_simulated.bat имитирует ответ Trello и сохраняет фальшивые
карточки в project/reports/. Он не меняет доску, аккаунт или рабочие данные.

Порядок работы:
1. Просмотрите data/minutes.txt, data/people.csv и data/project_map.json.
2. Запустите run_preview.bat. Программа проверяет candidates и создаёт reports/preview_tasks.csv.
3. Сверьте его с materials/EXPECTED_PREVIEW.txt. Только T-01 и T-02 готовы.
4. Убедитесь, что data/approved_task_ids.txt содержит только T-01 и T-02.
5. Запустите create_tasks_simulated.bat. Скрипт требует флаг подтверждения, но выполняет только симуляцию.
6. Проверьте reports/simulated_trello_cards.json и reports/creation_result.json.
7. Запустите create_tasks_simulated.bat повторно. Новых учебных карточек появиться не должно.
8. Для автоматических проверок запустите run_tests.bat.

Требуется Python 3 без сторонних библиотек. Если команда py -3 отсутствует, можно
открыть терминал в папке project и выполнить:
  python src/task_pipeline.py preview
  python src/task_pipeline.py simulate-create --confirm
  python -m unittest discover -s tests -v

Файлы BOARD-DEMO-11, LIST-DEMO-11-READY и MEM-DEMO-* — вымышленные значения.
Их нельзя использовать в настоящем запросе Trello.
