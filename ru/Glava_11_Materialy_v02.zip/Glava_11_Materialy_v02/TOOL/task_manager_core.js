(function(global){
'use strict';
class InputError extends Error { constructor(msg){super(msg);this.name='InputError';} }
function fail(msg){throw new InputError(msg);}
function csvLine(line){
  const out=[]; let cur='', q=false;
  for(let i=0;i<line.length;i++){
    const c=line[i];
    if(q){ if(c==='"' && line[i+1]==='"'){cur+='"';i++;} else if(c==='"'){q=false;} else cur+=c; }
    else { if(c==='"')q=true; else if(c===','){out.push(cur);cur='';} else cur+=c; }
  }
  if(q) fail('В CSV обнаружена незакрытая кавычка.'); out.push(cur); return out;
}
function parseCSV(text, expected, label){
  const lines=String(text).replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim()!=='');
  if(!lines.length) fail(`${label}: файл пуст.`);
  const head=csvLine(lines[0]).map(x=>x.trim());
  if(head.join(',')!==expected.join(',')) fail(`${label}: ожидаются столбцы ${expected.join(', ')}.`);
  return lines.slice(1).map((line,idx)=>{const vals=csvLine(line);if(vals.length!==head.length)fail(`${label}: строка ${idx+2} содержит неверное число полей.`);const o={};head.forEach((h,j)=>o[h]=vals[j].trim());return o;});
}
function parseJson(text,label){try{return JSON.parse(text);}catch(e){fail(`${label}: неверный JSON.`);}}
function parseApproved(text){const ids=String(text).replace(/^\uFEFF/,'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);const set=new Set();for(const id of ids){if(set.has(id))fail(`Список подтверждения: повторяется ${id}.`);set.add(id);}return ids;}
function load(files){
  const names=['people.csv','project_map.json','task_candidates.csv','approved_task_ids.txt']; const map={};
  for(const f of files){if(names.includes(f.name)){if(map[f.name])fail(`Файл ${f.name} выбран больше одного раза.`);map[f.name]=f.text;}}
  const missing=names.filter(n=>!(n in map)); if(missing.length) fail(`Не выбраны обязательные файлы: ${missing.join(', ')}.`);
  return {
    people:parseCSV(map['people.csv'],['member_id','display_name','department'],'Справочник участников'),
    project:parseJson(map['project_map.json'],'Карта проекта'),
    candidates:parseCSV(map['task_candidates.csv'],['task_id','title','description','owner_name','owner_department','due_date','decision','source_ref','project_key'],'Кандидаты'),
    approved:parseApproved(map['approved_task_ids.txt'])
  };
}
function validDate(v){if(!/^\d{4}-\d{2}-\d{2}$/.test(v))return false;const d=new Date(v+'T00:00:00Z');return !Number.isNaN(d.getTime()) && d.toISOString().slice(0,10)===v;}
function resolveOwner(row,people){
  const name=(row.owner_name||'').trim(), dept=(row.owner_department||'').trim();
  if(!name)return {name:'',dept:'',memberId:'',issue:'Ответственный не указан'};
  let m=people.filter(p=>(p.display_name||'').trim()===name);
  if(dept)m=m.filter(p=>(p.department||'').trim().toLowerCase()===dept.toLowerCase());
  if(m.length===0)return {name,dept,memberId:'',issue:'Участник не найден в справочнике'};
  if(m.length>1)return {name,dept,memberId:'',issue:'Несколько участников с таким именем; нужно уточнение'};
  return {name:m[0].display_name,dept:m[0].department,memberId:m[0].member_id,issue:''};
}
function buildPreview(files){
  const {people,project,candidates,approved}=load(files);
  if(!project.source_meeting_id||!project.project_key||!project.board_id||!project.default_list_id)fail('Карта проекта: отсутствуют обязательные поля.');
  const counts={};for(const r of candidates)counts[(r.task_id||'').trim()]=(counts[(r.task_id||'').trim()]||0)+1;
  const rows=[];
  for(const r of candidates){
    const taskId=(r.task_id||'').trim(), title=(r.title||'').trim(), decision=(r.decision||'').trim().toUpperCase();
    const flags=[]; const owner=resolveOwner(r,people); let due=(r.due_date||'').trim();
    let dueIssue=''; if(!due)dueIssue='Срок не указан'; else if(!validDate(due))dueIssue='Срок не распознан как дата YYYY-MM-DD';
    let status;
    if(counts[taskId]>1){status='ERROR';flags.push('Повторяется ID строки источника');}
    else if(['IDEA','QUESTION','DISCUSSION'].includes(decision)){status='NOT_A_TASK';flags.push('Запись не подтверждена как поручение');}
    else if(decision!=='TASK'){status='ERROR';flags.push('Неизвестный тип записи; требуется разметка');}
    else {
      if(!title)flags.push('Пустое название задачи');
      if(owner.issue)flags.push(owner.issue);
      if(dueIssue)flags.push(dueIssue);
      if((r.project_key||'').trim()!==project.project_key)flags.push('Проект отсутствует в карте проекта');
      if(!(r.source_ref||'').trim())flags.push('Не указан источник в протоколе');
      if(!flags.length)status='READY'; else {
        const ob=flags.some(f=>f.toLowerCase().includes('ответствен')||f.toLowerCase().includes('участник'));
        const db=flags.some(f=>f.toLowerCase().includes('срок')||f.toLowerCase().includes('дат'));
        status=ob&&db?'NEEDS_OWNER_AND_DUE':ob?'NEEDS_OWNER':db?'NEEDS_DUE':'ERROR';
      }
    }
    rows.push({task_id:taskId,title,description:(r.description||'').trim(),owner_name:owner.name,owner_department:owner.dept,member_id:owner.memberId,due_date:due,board_id:project.board_id,list_id:project.default_list_id,list_name:project.default_list_name,status,review_reason:flags.join('; '),source_ref:(r.source_ref||'').trim(),external_key:`${project.source_meeting_id}:${taskId}`});
  }
  return {rows,approved,project};
}
function simulate(files,ledger){
  const p=buildPreview(files), by={}; for(const r of p.rows)by[r.task_id]=r;
  for(const id of p.approved){if(!by[id])fail(`Подтверждённая задача ${id} отсутствует в предварительном списке.`);if(by[id].status!=='READY')fail(`Задача ${id} не готова: ${by[id].status}.`);}
  const nextLedger=Object.assign({},ledger||{}), results=[]; let created=0;
  for(const id of p.approved){const r=by[id],key=r.external_key;if(nextLedger[key])results.push({task_id:id,status:'ALREADY_CREATED_IN_SIMULATION',card_id:nextLedger[key].card_id});else{const card=`DEMO-CARD-${id}`;nextLedger[key]={card_id:card,task_id:id};results.push({task_id:id,status:'CREATED_IN_SIMULATION',card_id:card});created++;}}
  return {mode:'LOCAL_SIMULATION_ONLY',new_cards_this_run:created,total_mock_cards:Object.keys(nextLedger).length,results,network_requests_sent:0,ledger:nextLedger};
}
function statusCounts(rows){const c={};for(const r of rows)c[r.status]=(c[r.status]||0)+1;return c;}
global.TaskManagerCore={InputError,buildPreview,simulate,statusCounts};
})(typeof window!=='undefined'?window:globalThis);
