@echo off
setlocal
cd /d "%~dp0"
py -3 src\process_catalog_images.py --manifest data\catalog_manifest.csv --input-dir input_images --output-dir output\catalog --confirm
if errorlevel 1 pause
