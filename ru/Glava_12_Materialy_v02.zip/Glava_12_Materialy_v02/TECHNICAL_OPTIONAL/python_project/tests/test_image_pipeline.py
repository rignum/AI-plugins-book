import csv
import hashlib
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import process_catalog_images as pipeline


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class CatalogImageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.temp_root = Path(self.temp.name)
        self.input_dir = self.temp_root / "input_images"
        shutil.copytree(ROOT / "input_images", self.input_dir)
        self.output_dir = self.temp_root / "output_images"

    def tearDown(self):
        self.temp.cleanup()

    def run_catalog(self):
        return pipeline.process_catalog(
            ROOT / "data" / "catalog_manifest.csv",
            self.input_dir,
            self.output_dir,
        )

    def test_all_manifest_rows_create_exact_canvas_size(self):
        summary, reports = self.run_catalog()
        self.assertEqual(summary["processed"], 5)
        self.assertEqual(summary["errors"], 0)
        for row in reports:
            with Image.open(self.output_dir / row["output_file"]) as result:
                self.assertEqual(result.size, (800, 600))

    def test_transparent_png_keeps_alpha(self):
        self.run_catalog()
        output = self.output_dir / "mug_800x600.png"
        with Image.open(output) as result:
            self.assertEqual(result.mode, "RGBA")
            self.assertEqual(result.getpixel((0, 0))[3], 0)
            self.assertGreater(result.getpixel((400, 300))[3], 0)

    def test_jpeg_from_transparent_source_uses_configured_white_matte(self):
        row = pipeline.validate_manifest(ROOT / "data" / "catalog_manifest.csv")[2]
        row.update({"format": "JPEG", "quality_value": 88, "background_rgb": (255, 255, 255)})
        target = self.output_dir / "mug_flattened.jpg"
        self.output_dir.mkdir(parents=True)
        pipeline.process_one(self.input_dir / "mug_alpha.png", row, target)
        with Image.open(target) as result:
            self.assertEqual(result.mode, "RGB")
            self.assertEqual(result.getpixel((0, 0)), (255, 255, 255))

    def test_exif_orientation_is_applied_before_resize_and_not_copied(self):
        _, reports = self.run_catalog()
        row = next(row for row in reports if row["source_file"] == "bottle_exif.jpg")
        self.assertEqual(row["source_size"], "900x600")
        self.assertEqual(row["oriented_size"], "600x900")
        self.assertEqual(row["exif_orientation"], 6)
        with Image.open(self.output_dir / row["output_file"]) as result:
            self.assertEqual(result.getexif(), {})

    def test_originals_are_unchanged(self):
        before = {path.name: digest(path) for path in self.input_dir.iterdir()}
        self.run_catalog()
        after = {path.name: digest(path) for path in self.input_dir.iterdir()}
        self.assertEqual(before, after)

    def test_preview_creates_no_processed_images(self):
        summary, rows = pipeline.preview_catalog(
            ROOT / "data" / "catalog_manifest.csv",
            self.input_dir,
            self.output_dir,
        )
        self.assertEqual(summary["mode"], "LOCAL_PREVIEW_ONLY")
        self.assertEqual(summary["ready"], 5)
        self.assertTrue((self.output_dir / "processing_preview.csv").is_file())
        self.assertEqual(list(self.output_dir.glob("*.jpg")) + list(self.output_dir.glob("*.png")), [])

    def test_aspect_ratio_calculation_for_wide_source(self):
        self.assertEqual(pipeline.contained_size((1200, 700), (800, 600)), (800, 467))

    def test_path_traversal_in_manifest_is_rejected(self):
        manifest = self.temp_root / "bad.csv"
        manifest.write_text(
            "source_file,output_file,width,height,fit,format,quality,background\n"
            "../secret.png,01.jpg,800,600,pad,JPEG,88,#FFFFFF\n",
            encoding="utf-8",
        )
        with self.assertRaisesRegex(ValueError, "имя PNG или JPEG"):
            pipeline.validate_manifest(manifest)

    def test_same_input_and_output_directory_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "отдельно от оригиналов"):
            pipeline.process_catalog(
                ROOT / "data" / "catalog_manifest.csv",
                self.input_dir,
                self.input_dir,
            )


if __name__ == "__main__":
    unittest.main()
