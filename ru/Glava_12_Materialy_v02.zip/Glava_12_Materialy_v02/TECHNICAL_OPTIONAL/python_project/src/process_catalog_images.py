"""Prepare a catalog image set from an explicit CSV manifest.

The script uses local CPU image operations only. It does not call ChatGPT,
external models, or network services, and it never writes into the source folder.
"""

import argparse
import csv
import hashlib
import json
import re
import sys
from pathlib import Path

from PIL import Image, ImageOps


ROOT = Path(__file__).resolve().parents[1]
REQUIRED_COLUMNS = {
    "source_file", "output_file", "width", "height", "fit", "format",
    "quality", "background",
}
ALLOWED_SOURCE_EXTENSIONS = {".jpg", ".jpeg", ".png"}
MAX_SOURCE_PIXELS = 25_000_000
MAX_TARGET_SIDE = 5_000
HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")
REPORT_COLUMNS = [
    "status", "source_file", "output_file", "source_size", "oriented_size",
    "target_size", "fit", "format", "quality", "source_had_alpha",
    "output_has_alpha", "exif_orientation", "exif_removed", "output_bytes",
    "message",
]
PREVIEW_COLUMNS = [
    "status", "source_file", "output_file", "source_size", "oriented_size",
    "target_size", "fit", "format", "quality", "background",
    "source_has_transparency", "exif_orientation", "message",
]


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_color(value):
    value = (value or "").strip()
    if value.lower() == "transparent":
        return None
    if not HEX_COLOR.fullmatch(value):
        raise ValueError("Фон должен быть словом transparent или цветом #RRGGBB")
    return tuple(int(value[index:index + 2], 16) for index in (1, 3, 5))


def contained_size(source_size, target_size):
    source_width, source_height = source_size
    target_width, target_height = target_size
    if min(source_width, source_height, target_width, target_height) <= 0:
        raise ValueError("Ширина и высота должны быть положительными")
    scale = min(target_width / source_width, target_height / source_height)
    return (
        max(1, round(source_width * scale)),
        max(1, round(source_height * scale)),
    )


def fit_image(image, target_size, strategy="pad", background=(255, 255, 255)):
    """Return an RGBA image using stretch, center crop, or contain-and-pad."""
    image = image.convert("RGBA")
    target_width, target_height = target_size
    if strategy == "stretch":
        return image.resize(target_size, Image.Resampling.LANCZOS)
    if strategy == "crop":
        scale = max(target_width / image.width, target_height / image.height)
        size = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
        resized = image.resize(size, Image.Resampling.LANCZOS)
        left = (resized.width - target_width) // 2
        top = (resized.height - target_height) // 2
        return resized.crop((left, top, left + target_width, top + target_height))
    if strategy == "pad":
        size = contained_size(image.size, target_size)
        resized = image.resize(size, Image.Resampling.LANCZOS)
        if background is None:
            canvas = Image.new("RGBA", target_size, (0, 0, 0, 0))
        else:
            canvas = Image.new("RGBA", target_size, (*background, 255))
        left = (target_width - resized.width) // 2
        top = (target_height - resized.height) // 2
        canvas.alpha_composite(resized, (left, top))
        return canvas
    raise ValueError(f"Неизвестный способ размещения: {strategy}")


def validate_manifest(path):
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = set(reader.fieldnames or [])
        missing = REQUIRED_COLUMNS - columns
        if missing:
            raise ValueError("В таблице не хватает столбцов: " + ", ".join(sorted(missing)))
        rows = list(reader)

    if not rows:
        raise ValueError("В таблице нет изображений")

    seen_outputs = set()
    clean_rows = []
    for line_number, raw in enumerate(rows, start=2):
        row = {key: (value or "").strip() for key, value in raw.items()}
        source = row["source_file"]
        output = row["output_file"]
        if not source or Path(source).name != source or Path(source).suffix.lower() not in ALLOWED_SOURCE_EXTENSIONS:
            raise ValueError(f"Строка {line_number}: укажите имя PNG или JPEG без пути к папке")
        if not output or Path(output).name != output:
            raise ValueError(f"Строка {line_number}: выходное имя должно быть именем файла без пути")
        output_key = output.casefold()
        if output_key in seen_outputs:
            raise ValueError(f"Строка {line_number}: выходное имя повторяется")
        seen_outputs.add(output_key)

        try:
            width = int(row["width"])
            height = int(row["height"])
        except ValueError as exc:
            raise ValueError(f"Строка {line_number}: ширина и высота должны быть целыми числами") from exc
        if min(width, height) <= 0 or max(width, height) > MAX_TARGET_SIDE:
            raise ValueError(f"Строка {line_number}: допустимый размер — от 1 до {MAX_TARGET_SIDE} пикселей по стороне")
        if row["fit"] not in {"pad", "crop", "stretch"}:
            raise ValueError(f"Строка {line_number}: способ должен быть pad, crop или stretch")

        fmt = row["format"].upper()
        extension = Path(output).suffix.lower()
        if fmt == "JPEG":
            if extension not in {".jpg", ".jpeg"}:
                raise ValueError(f"Строка {line_number}: для JPEG нужно расширение .jpg или .jpeg")
            try:
                quality = int(row["quality"])
            except ValueError as exc:
                raise ValueError(f"Строка {line_number}: укажите качество JPEG от 1 до 95") from exc
            if not 1 <= quality <= 95:
                raise ValueError(f"Строка {line_number}: укажите качество JPEG от 1 до 95")
            background = parse_color(row["background"])
            if background is None:
                raise ValueError(f"Строка {line_number}: JPEG не сохраняет прозрачность; задайте цвет фона")
        elif fmt == "PNG":
            if extension != ".png":
                raise ValueError(f"Строка {line_number}: для PNG нужно расширение .png")
            if row["quality"]:
                raise ValueError(f"Строка {line_number}: у PNG в этой инструкции поле качества оставляют пустым")
            background = parse_color(row["background"])
            quality = ""
        else:
            raise ValueError(f"Строка {line_number}: в упражнении поддерживаются только JPEG и PNG")

        row.update({"width": width, "height": height, "format": fmt,
                    "quality_value": quality, "background_rgb": background})
        clean_rows.append(row)
    return clean_rows


def process_one(source_path, row, target_path):
    with Image.open(source_path) as opened:
        source_size = opened.size
        if opened.width * opened.height > MAX_SOURCE_PIXELS:
            raise ValueError(f"Исходник больше учебного предела {MAX_SOURCE_PIXELS:,} пикселей")
        orientation = opened.getexif().get(274, 1)
        if opened.mode not in {"1", "L", "LA", "P", "RGB", "RGBA"}:
            raise ValueError(f"Режим цвета {opened.mode} не входит в упражнение; сначала подготовьте RGB или RGBA")
        original_has_alpha = (
            "A" in opened.getbands()
            or "transparency" in opened.info
        )
        icc_profile = opened.info.get("icc_profile")
        oriented = ImageOps.exif_transpose(opened)
        oriented_size = oriented.size
        rgba = oriented.convert("RGBA")
        has_visible_transparency = rgba.getchannel("A").getextrema()[0] < 255

    background = row["background_rgb"]
    framed = fit_image(
        rgba,
        (row["width"], row["height"]),
        row["fit"],
        background,
    )

    if row["format"] == "JPEG":
        if background is None:
            raise ValueError("JPEG требует непрозрачный фон")
        base = Image.new("RGBA", framed.size, (*background, 255))
        base.alpha_composite(framed)
        output = base.convert("RGB")
        output.save(
            target_path,
            format="JPEG",
            quality=row["quality_value"],
            optimize=True,
            exif=b"",
            icc_profile=icc_profile,
        )
        output_has_alpha = False
    else:
        if background is None:
            output = framed
        else:
            base = Image.new("RGBA", framed.size, (*background, 255))
            base.alpha_composite(framed)
            output = base.convert("RGB")
        output.save(
            target_path,
            format="PNG",
            optimize=True,
            icc_profile=icc_profile,
        )
        output_has_alpha = "A" in output.getbands()

    return {
        "source_size": f"{source_size[0]}x{source_size[1]}",
        "oriented_size": f"{oriented_size[0]}x{oriented_size[1]}",
        "source_had_alpha": "yes" if has_visible_transparency else "no",
        "output_has_alpha": "yes" if output_has_alpha else "no",
        "exif_orientation": orientation,
        "exif_removed": "yes",
    }


def process_catalog(manifest, input_dir, output_dir):
    manifest = Path(manifest)
    input_dir = Path(input_dir).resolve()
    output_dir = Path(output_dir).resolve()
    if not input_dir.is_dir():
        raise ValueError(f"Папка исходников не найдена: {input_dir}")
    if output_dir == input_dir or output_dir.is_relative_to(input_dir):
        raise ValueError("Выходная папка должна находиться отдельно от оригиналов")

    rows = validate_manifest(manifest)
    output_dir.mkdir(parents=True, exist_ok=True)
    reports = []
    for row in rows:
        source_path = input_dir / row["source_file"]
        target_path = output_dir / row["output_file"]
        report = {
            "status": "ERROR",
            "source_file": row["source_file"],
            "output_file": row["output_file"],
            "target_size": f"{row['width']}x{row['height']}",
            "fit": row["fit"],
            "format": row["format"],
            "quality": row["quality_value"],
            "output_bytes": "",
            "message": "",
        }
        try:
            if not source_path.is_file():
                raise FileNotFoundError("Исходный файл не найден")
            details = process_one(source_path, row, target_path)
            report.update(details)
            report["output_bytes"] = target_path.stat().st_size
            report["status"] = "OK"
            report["message"] = "Обработано по правилу из таблицы"
        except Exception as exc:  # each row is reported; no silent skipping
            if target_path.exists():
                target_path.unlink()
            report["message"] = f"{type(exc).__name__}: {exc}"
        reports.append(report)

    report_path = output_dir / "processing_report.csv"
    with report_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=REPORT_COLUMNS)
        writer.writeheader()
        writer.writerows(reports)
    ok_count = sum(row["status"] == "OK" for row in reports)
    summary = {
        "mode": "LOCAL_IMAGE_PROCESSING_ONLY",
        "processed": ok_count,
        "errors": len(reports) - ok_count,
        "report": str(report_path),
        "network_requests_sent": 0,
    }
    (output_dir / "run_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return summary, reports


def preview_catalog(manifest, input_dir, output_dir):
    """Validate the manifest and source headers without writing image files."""
    manifest = Path(manifest)
    input_dir = Path(input_dir).resolve()
    output_dir = Path(output_dir).resolve()
    if not input_dir.is_dir():
        raise ValueError(f"Папка исходников не найдена: {input_dir}")
    if output_dir == input_dir or output_dir.is_relative_to(input_dir):
        raise ValueError("Выходная папка должна находиться отдельно от оригиналов")
    rows = validate_manifest(manifest)
    output_dir.mkdir(parents=True, exist_ok=True)
    preview_rows = []
    for row in rows:
        record = {
            "status": "ERROR", "source_file": row["source_file"],
            "output_file": row["output_file"],
            "target_size": f"{row['width']}x{row['height']}",
            "fit": row["fit"], "format": row["format"],
            "quality": row["quality_value"],
            "background": row["background"],
            "source_size": "", "oriented_size": "",
            "source_has_transparency": "", "exif_orientation": "",
            "message": "",
        }
        try:
            source_path = input_dir / row["source_file"]
            if not source_path.is_file():
                raise FileNotFoundError("Исходный файл не найден")
            with Image.open(source_path) as opened:
                if opened.width * opened.height > MAX_SOURCE_PIXELS:
                    raise ValueError(f"Исходник больше учебного предела {MAX_SOURCE_PIXELS:,} пикселей")
                if opened.mode not in {"1", "L", "LA", "P", "RGB", "RGBA"}:
                    raise ValueError(f"Режим цвета {opened.mode} не входит в упражнение")
                record["source_size"] = f"{opened.width}x{opened.height}"
                record["exif_orientation"] = opened.getexif().get(274, 1)
                transparent = "A" in opened.getbands() or "transparency" in opened.info
                record["source_has_transparency"] = "yes" if transparent else "no"
                corrected = ImageOps.exif_transpose(opened)
                record["oriented_size"] = f"{corrected.width}x{corrected.height}"
            record["status"] = "READY"
            record["message"] = "Правила и исходник прошли предварительную проверку"
        except Exception as exc:
            record["message"] = f"{type(exc).__name__}: {exc}"
        preview_rows.append(record)

    preview_path = output_dir / "processing_preview.csv"
    with preview_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=PREVIEW_COLUMNS)
        writer.writeheader()
        writer.writerows(preview_rows)
    ready = sum(row["status"] == "READY" for row in preview_rows)
    return {
        "mode": "LOCAL_PREVIEW_ONLY",
        "ready": ready,
        "errors": len(preview_rows) - ready,
        "report": str(preview_path),
        "network_requests_sent": 0,
    }, preview_rows


def main(argv=None):
    parser = argparse.ArgumentParser(description="Локальная подготовка изображений каталога")
    parser.add_argument("--manifest", default="data/catalog_manifest.csv")
    parser.add_argument("--input-dir", default="input_images")
    parser.add_argument("--output-dir", default="output/catalog")
    parser.add_argument("--preview", action="store_true", help="проверить план и исходники без обработки")
    parser.add_argument("--confirm", action="store_true", help="подтвердить локальную обработку")
    args = parser.parse_args(argv)
    if args.preview and args.confirm:
        parser.error("выберите либо --preview, либо --confirm")
    if not args.preview and not args.confirm:
        print("Сначала выполните предварительную проверку с --preview. Для обработки после проверки укажите --confirm.", file=sys.stderr)
        return 2
    try:
        if args.preview:
            summary, reports = preview_catalog(args.manifest, args.input_dir, args.output_dir)
        else:
            summary, reports = process_catalog(args.manifest, args.input_dir, args.output_dir)
    except Exception as exc:
        print(f"Ошибка подготовки: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    count = summary.get("processed", summary.get("ready", 0))
    print(f"Готово: {count} из {len(reports)} изображений")
    print(f"Ошибок: {summary['errors']}")
    print(f"Отчёт: {summary['report']}")
    print("Сетевых запросов: 0; оригиналы не изменяются.")
    return 0 if summary["errors"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
