"""Create the chapter's original, fictional catalog-image fixtures."""

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "input_images"
OUT.mkdir(parents=True, exist_ok=True)


def font(size):
    candidates = [
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
        Path("C:/Windows/Fonts/arial.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def rounded(draw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def make_lamp():
    im = Image.new("RGB", (640, 960), "#f3eee7")
    d = ImageDraw.Draw(im)
    d.ellipse((120, 790, 520, 860), fill="#e3d9ce")
    d.rounded_rectangle((285, 500, 355, 805), radius=22, fill="#384b59")
    d.ellipse((225, 770, 415, 825), fill="#253743")
    d.line((320, 535, 320, 350), fill="#384b59", width=42)
    d.line((320, 370, 410, 220), fill="#384b59", width=38)
    d.polygon([(335, 175), (505, 220), (455, 365), (285, 320)], fill="#e1a34e")
    d.polygon([(307, 316), (460, 361), (453, 380), (300, 335)], fill="#b97932")
    d.ellipse((423, 350, 447, 374), fill="#f6d58f")
    d.text((42, 38), "DESK LAMP", font=font(27), fill="#41515a")
    im.save(OUT / "lamp_portrait.png", optimize=True)


def make_towels():
    im = Image.new("RGB", (1200, 700), "#e8f0f0")
    d = ImageDraw.Draw(im)
    # Folded towels: deliberately placed across the wide canvas so center-crop
    # trims their outer edges and the reader can see what is lost.
    rounded(d, (105, 355, 725, 575), 36, "#d5a979", "#b68252", 8)
    rounded(d, (350, 238, 1095, 455), 36, "#8daeb3", "#638b91", 8)
    rounded(d, (535, 115, 1130, 330), 36, "#f1d7a1", "#d7b974", 8)
    for x in range(145, 695, 36):
        d.line((x, 385, x, 545), fill="#c19061", width=4)
    for x in range(405, 1065, 42):
        d.line((x, 270, x, 423), fill="#78999e", width=4)
    d.text((45, 38), "FOLDED TOWELS", font=font(28), fill="#405358")
    im.save(OUT / "towels_wide.jpg", quality=94, optimize=True)


def make_mug():
    im = Image.new("RGBA", (460, 700), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    # Handle is drawn first; the cup body covers its inner left edge.
    d.ellipse((288, 244, 425, 445), fill=(0, 0, 0, 0), outline="#276d80", width=31)
    rounded(d, (75, 198, 330, 512), 34, "#2f8ca1", "#1d6073", 8)
    d.rectangle((94, 235, 120, 472), fill="#63b4c1")
    d.ellipse((75, 178, 330, 226), fill="#d2edf0", outline="#1d6073", width=8)
    d.arc((75, 178, 330, 226), 0, 180, fill="#1d6073", width=7)
    rounded(d, (105, 520, 300, 548), 12, "#a8d1d4")
    d.text((91, 346), "M", font=font(104), fill="#f2fbfb")
    im.save(OUT / "mug_alpha.png", optimize=True)


def make_clock():
    im = Image.new("RGB", (800, 800), "#f5efe1")
    d = ImageDraw.Draw(im)
    d.ellipse((120, 110, 680, 670), fill="#d8e4d8", outline="#607569", width=16)
    d.ellipse((165, 155, 635, 625), fill="#faf8f0", outline="#8a9a8c", width=7)
    cx, cy = 400, 390
    for hour in range(12):
        import math
        angle = (hour / 12) * 2 * math.pi - math.pi / 2
        x1 = cx + math.cos(angle) * 185
        y1 = cy + math.sin(angle) * 185
        x2 = cx + math.cos(angle) * 207
        y2 = cy + math.sin(angle) * 207
        d.line((x1, y1, x2, y2), fill="#41544a", width=8)
    d.line((cx, cy, 400, 250), fill="#34454d", width=16)
    d.line((cx, cy, 510, 430), fill="#34454d", width=12)
    d.ellipse((382, 372, 418, 408), fill="#c86f51")
    d.text((272, 710), "QUIET CLOCK", font=font(27), fill="#40534a")
    im.save(OUT / "clock_square.png", optimize=True)


def make_thermos_orientation():
    # Draw the correctly displayed portrait image, then store its pixels turned
    # sideways with EXIF Orientation=6. Correct software rotates it clockwise.
    upright = Image.new("RGB", (600, 900), "#edf1f5")
    d = ImageDraw.Draw(upright)
    d.ellipse((110, 800, 490, 860), fill="#d6dde2")
    rounded(d, (205, 220, 395, 780), 74, "#516f9a", "#344f77", 10)
    rounded(d, (240, 168, 360, 247), 20, "#d8e1ec", "#344f77", 8)
    d.rectangle((245, 340, 355, 690), fill="#7796bd")
    d.line((250, 397, 350, 397), fill="#9fb7d4", width=8)
    d.text((62, 44), "TRAVEL BOTTLE", font=font(26), fill="#3c4f64")
    raw = upright.transpose(Image.Transpose.ROTATE_90)
    exif = Image.Exif()
    exif[274] = 6
    exif[315] = "Учебный комплект. Демонстрационный автор"
    exif[306] = "2026:09:25 12:00:00"
    raw.save(OUT / "bottle_exif.jpg", quality=95, exif=exif)


if __name__ == "__main__":
    make_lamp()
    make_towels()
    make_mug()
    make_clock()
    make_thermos_orientation()
    print(f"Созданы пять учебных изображений: {OUT}")
