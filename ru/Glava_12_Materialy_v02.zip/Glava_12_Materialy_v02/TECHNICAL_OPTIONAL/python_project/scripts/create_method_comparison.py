"""Create a precise visual comparison from the actual image operations."""

from pathlib import Path
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from process_catalog_images import fit_image


SOURCE = ROOT / "input_images" / "towels_wide.jpg"
TARGET = ROOT.parent / "materials" / "comparison_methods.png"
TARGET.parent.mkdir(parents=True, exist_ok=True)

FONT_CANDIDATES = [
    Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    Path("C:/Windows/Fonts/arial.ttf"),
]


def load_font(size):
    for path in FONT_CANDIDATES:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def main():
    with Image.open(SOURCE) as opened:
        source = opened.convert("RGBA")

    target_size = (480, 360)
    options = [
        ("Растяжение", "Размер точный, пропорции меняются", "stretch"),
        ("Обрезка", "Пропорции целы, края могут исчезнуть", "crop"),
        ("Поля", "Пропорции целы, добавлен фон", "pad"),
    ]
    panel_w, panel_h = 500, 470
    canvas = Image.new("RGB", (panel_w * 3 + 80, panel_h + 130), "#edf0f2")
    draw = ImageDraw.Draw(canvas)
    title_font = load_font(30)
    body_font = load_font(21)
    small_font = load_font(18)
    draw.text((40, 24), "Один исходник — три разных результата", font=title_font, fill="#1f2a32")
    draw.text((40, 66), "Исходное изображение: 1200 × 700 пикселей  |  Полотно каталога: 800 × 600", font=body_font, fill="#3c4951")

    for index, (label, note, strategy) in enumerate(options):
        x = 25 + index * (panel_w + 20)
        y = 118
        draw.rounded_rectangle((x, y, x + panel_w, y + panel_h), radius=18, fill="white", outline="#c7cfd4", width=2)
        title_box = draw.textbbox((0, 0), label, font=title_font)
        draw.text((x + (panel_w - (title_box[2] - title_box[0])) // 2, y + 14), label, font=title_font, fill="#24323b")
        result = fit_image(source, target_size, strategy, (255, 255, 255)).convert("RGB")
        result.thumbnail((440, 330), Image.Resampling.LANCZOS)
        px = x + (panel_w - result.width) // 2
        py = y + 72
        canvas.paste(result, (px, py))
        draw.rectangle((px, py, px + result.width - 1, py + result.height - 1), outline="#6e7d85", width=2)
        note_box = draw.textbbox((0, 0), note, font=small_font)
        draw.text((x + (panel_w - (note_box[2] - note_box[0])) // 2, y + 423), note, font=small_font, fill="#3f4d55")

    canvas.save(TARGET, optimize=True)
    print(TARGET)


if __name__ == "__main__":
    main()
