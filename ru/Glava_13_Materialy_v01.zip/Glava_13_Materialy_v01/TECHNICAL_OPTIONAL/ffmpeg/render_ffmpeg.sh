#!/bin/sh
set -eu
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
IN="$BASE/INPUT/NORMAL/videos"
OUT="$BASE/TECHNICAL_OPTIONAL/ffmpeg/output"
mkdir -p "$OUT"
ffmpeg -y \
 -i "$IN/clip_01_start.webm" -i "$IN/clip_02_process.webm" -i "$IN/clip_03_finish.webm" \
 -filter_complex "[0:v]trim=start=0.5:end=3.0,setpts=PTS-STARTPTS,scale=640:360,fps=30[v0];[0:a]atrim=start=0.5:end=3.0,asetpts=PTS-STARTPTS[a0];[1:v]trim=start=0.5:end=3.5,setpts=PTS-STARTPTS,scale=640:360,fps=30[v1];[1:a]atrim=start=0.5:end=3.5,asetpts=PTS-STARTPTS[a1];[2:v]trim=start=1.0:end=3.5,setpts=PTS-STARTPTS,scale=640:360,fps=30[v2];[2:a]atrim=start=1.0:end=3.5,asetpts=PTS-STARTPTS[a2];[v0][a0][v1][a1][v2][a2]concat=n=3:v=1:a=1[v][a]" \
 -map "[v]" -map "[a]" -c:v libvpx -b:v 1000k -c:a libopus -b:a 96k "$OUT/training_video_no_subs.webm"
echo "Создан файл без прожига субтитров: $OUT/training_video_no_subs.webm"
echo "Готовые WebVTT можно подключать как отдельную дорожку в совместимом проигрывателе или прожечь отдельной командой после проверки поддержки фильтра subtitles."
