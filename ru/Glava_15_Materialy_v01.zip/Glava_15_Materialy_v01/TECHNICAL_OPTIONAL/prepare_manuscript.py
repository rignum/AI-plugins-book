from zipfile import ZipFile, ZIP_DEFLATED
from pathlib import Path
from xml.etree import ElementTree as ET
import csv, json, io, sys

W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
CP='http://schemas.openxmlformats.org/package/2006/metadata/core-properties'
DC='http://purl.org/dc/elements/1.1/'
NS={'w':W,'r':R,'rel':REL,'cp':CP,'dc':DC}
ET.register_namespace('w',W); ET.register_namespace('r',R)

def txt(p): return ''.join(t.text or '' for t in p.findall('.//w:t',NS))
def q(ns,tag): return '{%s}%s'%(ns,tag)

def transform(docx_in, terms_csv, requirements_json, metadata_json, docx_out, report_out):
    terms=list(csv.DictReader(open(terms_csv,encoding='utf-8-sig')))
    req=json.load(open(requirements_json,encoding='utf-8'))
    meta=json.load(open(metadata_json,encoding='utf-8'))
    with ZipFile(docx_in,'r') as zin:
        files={n:zin.read(n) for n in zin.namelist()}
    root=ET.fromstring(files['word/document.xml'])
    body=root.find('w:body',NS)
    issues=[]; fixes=[]
    # heading fixes
    for p in body.findall('.//w:p',NS):
        t=txt(p).strip()
        for hf in req.get('heading_fixes',[]):
            if t==hf['text']:
                pPr=p.find('w:pPr',NS)
                if pPr is None: pPr=ET.Element(q(W,'pPr')); p.insert(0,pPr)
                pStyle=pPr.find('w:pStyle',NS)
                old = pStyle.get(q(W,'val')) if pStyle is not None else 'Normal'
                if old != hf['style']:
                    issues.append(('HEADING_LEVEL',t,old,hf['style']))
                    if pStyle is None: pStyle=ET.SubElement(pPr,q(W,'pStyle'))
                    pStyle.set(q(W,'val'),hf['style']); fixes.append(('HEADING_LEVEL',t,hf['style']))
    # terms
    for tnode in root.findall('.//w:t',NS):
        s=tnode.text or ''
        original=s
        for row in terms:
            if row['variant'] in s:
                issues.append(('TERM',row['variant'],row['preferred'],'replace'))
                s=s.replace(row['variant'],row['preferred'])
        if s!=original: tnode.text=s
    # hyperlink
    relroot=ET.fromstring(files['word/_rels/document.xml.rels'])
    target=req.get('required_link',{})
    for h in root.findall('.//w:hyperlink',NS):
        if txt(h).strip()==target.get('label'):
            rid=h.get(q(R,'id'))
            for rel in relroot.findall('rel:Relationship',NS):
                if rel.get('Id')==rid:
                    old=rel.get('Target')
                    if old!=target.get('target'):
                        issues.append(('LINK',target.get('label'),old,target.get('target')))
                        rel.set('Target',target.get('target')); fixes.append(('LINK',target.get('label'),target.get('target')))
    files['word/_rels/document.xml.rels']=ET.tostring(relroot,encoding='utf-8',xml_declaration=True)
    # static TOC before first heading 1, if absent
    texts=[txt(p).strip() for p in body.findall('w:p',NS)]
    if req.get('toc_title') not in texts:
        headings=[]
        for p in body.findall('w:p',NS):
            pPr=p.find('w:pPr',NS); sty=''
            if pPr is not None:
                ps=pPr.find('w:pStyle',NS); sty=ps.get(q(W,'val')) if ps is not None else ''
            if sty in ('Heading1','Heading2','Heading3'):
                headings.append((int(sty[-1]),txt(p).strip()))
        def make_p(text, style=None, indent=0):
            p=ET.Element(q(W,'p'))
            pPr=ET.SubElement(p,q(W,'pPr'))
            if style:
                st=ET.SubElement(pPr,q(W,'pStyle')); st.set(q(W,'val'),style)
            if indent:
                ind=ET.SubElement(pPr,q(W,'ind')); ind.set(q(W,'left'),str(indent))
            r=ET.SubElement(p,q(W,'r')); tt=ET.SubElement(r,q(W,'t')); tt.text=text
            return p
        # insert before first Heading1
        children=list(body); idx=0
        for i,p in enumerate(children):
            if p.tag==q(W,'p'):
                pPr=p.find('w:pPr',NS); ps=pPr.find('w:pStyle',NS) if pPr is not None else None
                if ps is not None and ps.get(q(W,'val'))=='Heading1': idx=i; break
        inserts=[make_p(req.get('toc_title','Оглавление'),'Heading1')]
        for level,textv in headings:
            inserts.append(make_p(textv,None,(level-1)*360))
        for offset,p in enumerate(inserts): body.insert(idx+offset,p)
        fixes.append(('TOC',str(len(headings)),'entries'))
    files['word/document.xml']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    # metadata
    core=ET.fromstring(files['docProps/core.xml'])
    mapping=[(DC,'title','title'),(DC,'creator','creator'),(DC,'subject','subject'),(CP,'keywords','keywords')]
    for ns,tag,key in mapping:
        el=core.find('{%s}%s'%(ns,tag))
        if el is None: el=ET.SubElement(core,'{%s}%s'%(ns,tag))
        if (el.text or '') != meta.get(key,''):
            issues.append(('METADATA',key,el.text or '',meta.get(key,'')))
            el.text=meta.get(key,''); fixes.append(('METADATA',key,meta.get(key,'')))
    files['docProps/core.xml']=ET.tostring(core,encoding='utf-8',xml_declaration=True)
    with ZipFile(docx_out,'w',ZIP_DEFLATED) as zout:
        for n,b in files.items(): zout.writestr(n,b)
    with open(report_out,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f); w.writerow(['type','item','before','after'])
        for row in issues: w.writerow(row)
    return len(issues), len(fixes)

if __name__=='__main__':
    transform(*sys.argv[1:7])
