from pathlib import Path
from zipfile import ZipFile
import csv, json, tempfile, importlib.util
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prep',here/'prepare_manuscript.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=here.parent
with tempfile.TemporaryDirectory() as td:
 out=Path(td)/'out.docx'; rep=Path(td)/'rep.csv'
 m.transform(base/'INPUT/manuscript_draft.docx',base/'INPUT/terms.csv',base/'INPUT/requirements.json',base/'INPUT/metadata.json',out,rep)
 assert out.exists() and rep.exists()
 with ZipFile(out) as z:
  xml=z.read('word/document.xml').decode('utf-8')
  rel=z.read('word/_rels/document.xml.rels').decode('utf-8')
  core=z.read('docProps/core.xml').decode('utf-8')
 assert 'ИИ-помощник' in xml and 'ChatGPT' in xml and 'чек-лист' in xml
 assert 'https://help.openai.com/' in rel
 assert 'Как подготовить учебный материал к публикации' in core
 assert 'Оглавление' in xml
 print('5/5 checks passed')
