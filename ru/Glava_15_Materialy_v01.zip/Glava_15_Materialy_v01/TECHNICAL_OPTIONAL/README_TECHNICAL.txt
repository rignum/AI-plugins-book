Технический маршрут

prepare_manuscript.py показывает те же ограниченные преобразования на уровне OOXML: стиль одного заголовка, словарь терминов, адрес одной ссылки, статическое оглавление и core metadata. Он не является универсальным редактором DOCX.

Пример запуска:
python prepare_manuscript.py ../INPUT/manuscript_draft.docx ../INPUT/terms.csv ../INPUT/requirements.json ../INPUT/metadata.json prepared.docx report.csv
