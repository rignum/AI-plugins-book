from pathlib import Path
import csv,re,json

def read_csv(path):
    with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def read_manifest(path):
    with open(path,encoding='utf-8-sig',newline='') as f:return {r['field']:r['value'] for r in csv.DictReader(f)}
def load_docs(folder):
    return {p.name:p.read_text(encoding='utf-8') for p in Path(folder).glob('*.txt')}
def check_rule(rule,man,docs):
    t=rule['check_type']; target=rule['target']
    if t=='required_file':
        return ('COMPLIANT',f'Файл {target} найден.') if target in docs else ('DEVIATION',f'Файл {target} отсутствует.')
    if t=='conditional_file':
        k,v=rule['applies_if'].split('=',1)
        if man.get(k)!=v:return ('NOT_APPLICABLE',f'Условие {rule["applies_if"]} не выполнено.')
        return ('COMPLIANT',f'Файл {target} найден.') if target in docs else ('DEVIATION',f'Файл {target} обязателен, но отсутствует.')
    if t=='required_headings':
        if target not in docs:return ('DEVIATION',f'{target} отсутствует.')
        miss=[x for x in rule['argument'].split('|') if x not in docs[target]]
        return ('DEVIATION','Не найдены поля: '+', '.join(miss)) if miss else ('COMPLIANT','Все обязательные поля найдены.')
    if t=='data_period_not_after_submission':
        if target not in docs:return ('DEVIATION',f'{target} отсутствует.')
        m=re.search(r'Период данных:\s*(\d{4}-\d{2}-\d{2})\s*[—-]\s*(\d{4}-\d{2}-\d{2})',docs[target])
        if not m:return ('DEVIATION','Поле периода не найдено.')
        sub=man.get('submission_date','')
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',sub):return ('INSUFFICIENT_DATA','Дата подачи не задана однозначно.')
        return ('COMPLIANT',f'{m.group(2)} <= {sub}') if m.group(2)<=sub else ('DEVIATION',f'{m.group(2)} > {sub}')
    if t=='ambiguous_external_data':
        if man.get('contains_external_data','').lower()!='yes':return ('NOT_APPLICABLE','Внешние данные не используются.')
        return ('INSUFFICIENT_DATA','Не задан измеримый критерий «достаточной актуальности».')
    return ('INSUFFICIENT_DATA','Неизвестный тип проверки.')
def check(regulation,manifest,folder):
    rules=read_csv(regulation); man=read_manifest(manifest); docs=load_docs(folder)
    return [(r['rule_id'],)+check_rule(r,man,docs) for r in rules]
