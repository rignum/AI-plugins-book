Этот раздел не нужен для основного упражнения.

checker.py — эталонная Python-реализация тех же формальных правил, что и локальный браузерный инструмент.
tests/test_checker.py — автоматические тесты основных и пограничных сценариев.
plugin_packaging_requirements_checker/ — пример постоянной Skill-инструкции и контракта будущего инструмента.

Для запуска тестов из папки TECHNICAL_OPTIONAL:
python -m unittest discover -s tests -v
