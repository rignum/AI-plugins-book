import unittest,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'TECHNICAL_OPTIONAL'))
from checker import check
REG=ROOT/'INPUT/REGULATION/regulation_v1_0.csv'
class TestChecker(unittest.TestCase):
    def runset(self,name):
        folder=ROOT/name
        return {rid:st for rid,st,_ in check(REG,folder/'package_manifest.csv',folder)}
    def test_main(self):
        s=self.runset('INPUT/MAIN'); self.assertEqual(s['R-01'],'COMPLIANT'); self.assertEqual(s['R-06'],'NOT_APPLICABLE')
    def test_missing_approval(self):
        self.assertEqual(self.runset('INPUT/TESTS/VIOLATIONS')['R-03'],'DEVIATION')
    def test_missing_heading(self):
        self.assertEqual(self.runset('INPUT/TESTS/VIOLATIONS')['R-04'],'DEVIATION')
    def test_period_after_submission(self):
        self.assertEqual(self.runset('INPUT/TESTS/VIOLATIONS')['R-05'],'DEVIATION')
    def test_ambiguous_external(self):
        self.assertEqual(self.runset('INPUT/TESTS/VIOLATIONS')['R-06'],'INSUFFICIENT_DATA')
    def test_draft_rule_not_applicable(self):
        self.assertEqual(self.runset('INPUT/TESTS/DRAFT')['R-03'],'NOT_APPLICABLE')
    def test_ambiguous_only(self):
        s=self.runset('INPUT/TESTS/AMBIGUOUS'); self.assertEqual(s['R-01'],'COMPLIANT'); self.assertEqual(s['R-06'],'INSUFFICIENT_DATA')
    def test_main_has_six_rules(self):
        self.assertEqual(len(self.runset('INPUT/MAIN')),6)
if __name__=='__main__':unittest.main()
