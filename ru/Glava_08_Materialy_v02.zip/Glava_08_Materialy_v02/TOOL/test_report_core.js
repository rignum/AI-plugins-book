(function(root,factory){
 const api=factory(); if(typeof module==='object'&&module.exports) module.exports=api; root.TestReportTool=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
 function pick(text,re,group=1){const m=text.match(re);return m?m[group]:null}
 function analyze(text,name='report.txt'){
   const r={filename:name,command:null,declaredStatus:null,exitCode:null,ran:null,tests:[],failures:0,errors:0,overall:'UNKNOWN',evidence:[],warnings:[]};
   if(typeof text!=='string'||!text.trim()){r.overall='INVALID';r.warnings.push('отчёт пуст');return r;}
   r.command=pick(text,/^Command:\s*(.+)$/mi);
   r.declaredStatus=pick(text,/^Status:\s*(\S+)/mi);
   const ex=pick(text,/^Exit code:\s*(-?\d+)/mi); r.exitCode=ex===null?null:Number(ex);
   const rn=pick(text,/Ran\s+(\d+)\s+tests?/i); r.ran=rn===null?null:Number(rn);
   const lines=text.split(/\r?\n/);
   for(const line of lines){
     const m=line.match(/^(test_[^(\s]+).*\.\.\.\s+(ok|FAIL|ERROR|skipped.*)$/i);
     if(m) r.tests.push({name:m[1],status:m[2]});
   }
   r.failures=r.tests.filter(t=>/^FAIL$/i.test(t.status)).length;
   r.errors=r.tests.filter(t=>/^ERROR$/i.test(t.status)).length;
   if(r.declaredStatus==='NOT_RUN'){r.overall='NOT_RUN';r.warnings.push('команда не была выполнена в этой среде');}
   else if(r.ran===0){r.overall='NO_TESTS';r.warnings.push('найдено 0 тестов: код 0 и строка OK не подтверждают содержательную проверку');}
   else if(r.errors>0||/FAILED\s*\(errors=/i.test(text)){r.overall='ERROR';}
   else if(r.failures>0||/FAILED\s*\(failures=/i.test(text)){r.overall='FAIL';}
   else if((r.ran??0)>0&&/\nOK\s*$/mi.test(text)&&r.exitCode===0){r.overall='PASS';}
   else if(r.declaredStatus==='PASS'&&(r.ran??0)>0){r.overall='PASS_WITH_LIMITED_EVIDENCE';r.warnings.push('статус PASS есть, но стандартные признаки отчёта неполны');}
   if(r.command) r.evidence.push(`Команда: ${r.command}`); else r.warnings.push('строка Command не найдена');
   if(r.ran!==null) r.evidence.push(`Запущено тестов: ${r.ran}`); else if(r.overall!=='NOT_RUN') r.warnings.push('строка Ran ... tests не найдена');
   if(r.exitCode!==null) r.evidence.push(`Код завершения: ${r.exitCode}`);
   if(r.tests.length) r.evidence.push(`Распознано строк тестов: ${r.tests.length}`);
   if(r.overall==='PASS') r.evidence.push('Все распознанные тесты завершились успешно в этом отчёте');
   if(r.overall==='FAIL') r.evidence.push('Есть провал проверки: ожидаемое значение не совпало с фактическим');
   if(r.overall==='ERROR') r.evidence.push('Есть ERROR: тест не дошёл до обычного сравнения результата');
   return r;
 }
 function summary(r){
   const L=[`Файл: ${r.filename}`,`Итог интерпретации: ${r.overall}`,`Заявленный статус: ${r.declaredStatus||'не указан'}`,`Запущено тестов: ${r.ran===null?'не установлено':r.ran}`,`Код завершения: ${r.exitCode===null?'не указан':r.exitCode}`,''];
   L.push('Тесты:'); (r.tests.length?r.tests:[{name:'нет распознанных строк',status:'—'}]).forEach(t=>L.push(`- ${t.name}: ${t.status}`));
   L.push('');L.push('Доказательства:');(r.evidence.length?r.evidence:['нет']).forEach(x=>L.push('- '+x));
   if(r.warnings.length){L.push('');L.push('Предупреждения:');r.warnings.forEach(x=>L.push('- '+x));}
   return L.join('\n');
 }
 return {analyze,summary};
});