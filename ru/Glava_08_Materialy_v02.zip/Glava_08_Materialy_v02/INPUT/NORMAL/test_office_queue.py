"""Checks for the small office request counter."""

import sys
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from office_queue import count_requests  # noqa: E402


class CountRequestsTests(unittest.TestCase):
    def test_counts_open_and_closed_requests(self):
        rows = [
            {"status": "open"},
            {"status": "closed"},
            {"status": "open"},
        ]
        self.assertEqual({"open": 2, "closed": 1}, count_requests(rows))

    def test_ignores_letter_case_and_outer_spaces(self):
        rows = [{"status": " OPEN "}, {"status": "open "}]
        self.assertEqual({"open": 2, "closed": 0}, count_requests(rows))

    def test_empty_list_returns_zero_counts(self):
        self.assertEqual({"open": 0, "closed": 0}, count_requests([]))


if __name__ == "__main__":
    unittest.main()
