"""Corrected answer-key version of the office request counter."""


def count_requests(rows):
    """Return counts for the supported request statuses."""
    counts = {"open": 0, "closed": 0}

    for row in rows:
        status = row["status"].strip().lower()
        if status == "open":
            counts["open"] += 1
        elif status == "closed":
            counts["closed"] += 1

    return counts
