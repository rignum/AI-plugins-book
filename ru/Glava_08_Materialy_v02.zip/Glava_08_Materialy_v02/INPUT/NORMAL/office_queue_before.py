"""A small example that counts open and closed office requests."""


def count_requests(rows):
    """Return counts for the supported request statuses."""
    counts = {"open": 0, "closed": 0}

    for row in rows:
        status = row["status"].strip().lower()
        if status == "open":
            counts["open"] += 1
        elif status == "closed":
            counts["open"] += 1

    return counts
