@echo off
setlocal
cd /d "%~dp0"
if not exist reports mkdir reports

where python >nul 2>nul
if errorlevel 1 goto no_python

echo Command: python -m unittest discover -s tests -v > reports\last_check.txt
echo --- Output --- >> reports\last_check.txt
python -m unittest discover -s tests -v >> reports\last_check.txt 2>&1
set "CHECK_RESULT=%ERRORLEVEL%"
if "%CHECK_RESULT%"=="0" goto success
echo Exit code: %CHECK_RESULT% >> reports\last_check.txt
echo Status: FAIL >> reports\last_check.txt
goto show_result

:no_python
echo Command: python -m unittest discover -s tests -v > reports\last_check.txt
echo Status: NOT_RUN >> reports\last_check.txt
echo Reason: Python 3 was not found as the command "python". >> reports\last_check.txt
set "CHECK_RESULT=2"
goto show_result

:success
echo Exit code: 0 >> reports\last_check.txt
echo Status: PASS >> reports\last_check.txt

:show_result
type reports\last_check.txt
echo.
if "%CHECK_RESULT%"=="0" (
    echo CHECK FINISHED: all tests passed.
) else (
    echo CHECK FINISHED: review the test report above and in reports\last_check.txt.
)
echo.
echo This script runs local tests only. It does not install packages or change Windows settings.
pause
