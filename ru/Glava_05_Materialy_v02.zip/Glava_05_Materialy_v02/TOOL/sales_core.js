(function(root, factory){
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SalesTool = factory();
})(typeof self !== 'undefined' ? self : this, function(){
  'use strict';

  const schemas = [
    {
      id:'A', delimiter:';', dateFormat:'DMY', decimalMark:',',
      headers:['Код продажи','Дата','Код товара','Товар','Количество','Ед.','Цена EUR','Сумма EUR'],
      fields:['sale_id','sale_date','item_code','item_name','quantity','unit','unit_price','line_total']
    },
    {
      id:'B', delimiter:',', dateFormat:'YMD', decimalMark:'.',
      headers:['Sale ID','Date','Product Code','Description','Quantity','Unit','Unit Price EUR','Line Total EUR'],
      fields:['sale_id','sale_date','item_code','item_name','quantity','unit','unit_price','line_total']
    },
    {
      id:'C', delimiter:'|', dateFormat:'DMY', decimalMark:'.',
      headers:['InvoiceNo','DateSold','SKU','Item','Qty','Measure','UnitEUR','TotalEUR'],
      fields:['sale_id','sale_date','item_code','item_name','quantity','unit','unit_price','line_total']
    }
  ];
  const unitMap = {'шт':'шт','уп.':'уп','уп':'уп','pcs':'шт','pack':'уп'};

  function parseDelimited(text, delimiter){
    text = text.replace(/^\uFEFF/, '');
    const rows=[]; let row=[], field='', quoted=false;
    for(let i=0;i<text.length;i++){
      const ch=text[i];
      if(quoted){
        if(ch==='"'){
          if(text[i+1]==='"'){ field+='"'; i++; }
          else quoted=false;
        } else field+=ch;
      } else {
        if(ch==='"') quoted=true;
        else if(ch===delimiter){ row.push(field); field=''; }
        else if(ch==='\n'){ row.push(field.replace(/\r$/,'')); rows.push(row); row=[]; field=''; }
        else field+=ch;
      }
    }
    if(field.length || row.length){ row.push(field.replace(/\r$/,'')); rows.push(row); }
    return rows.filter(r => r.some(v => String(v).trim() !== ''));
  }

  function detectSchema(text){
    for(const s of schemas){
      const rows=parseDelimited(text,s.delimiter);
      if(!rows.length) continue;
      const h=rows[0].map(x=>x.trim());
      if(h.length===s.headers.length && h.every((v,i)=>v===s.headers[i])) return {schema:s, rows};
    }
    return null;
  }

  function parseDate(raw, fmt){
    const s=String(raw).trim();
    let y,m,d;
    let mt;
    if(fmt==='DMY'){
      mt=/^(\d{2})\.(\d{2})\.(\d{4})$/.exec(s); if(!mt) return null;
      d=+mt[1];m=+mt[2];y=+mt[3];
    } else {
      mt=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s); if(!mt) return null;
      y=+mt[1];m=+mt[2];d=+mt[3];
    }
    const dt=new Date(Date.UTC(y,m-1,d));
    if(dt.getUTCFullYear()!==y || dt.getUTCMonth()!==m-1 || dt.getUTCDate()!==d) return null;
    return {iso:`${String(y).padStart(4,'0')}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`, y,m,d};
  }
  function dateDisplay(d){ return `${String(d.d).padStart(2,'0')}.${String(d.m).padStart(2,'0')}.${d.y}`; }
  function excelSerial(d){ return Math.floor((Date.UTC(d.y,d.m-1,d.d)-Date.UTC(1899,11,30))/86400000); }

  function parseMoney(raw, decimalMark){
    let s=String(raw).trim().replace(/\s/g,'');
    if(decimalMark===',') s=s.replace(',','.');
    if(!/^[-+]?\d+(?:\.\d{1,2})?$/.test(s)) return null;
    const n=Number(s); if(!Number.isFinite(n)) return null;
    return Math.round(n*100);
  }

  function rowSignature(r){ return [r.sale_date.iso,r.item_code,r.quantity,r.unit,r.unit_price_cents,r.line_total_cents,'EUR'].join('|'); }
  function money(cents){ return (cents/100).toFixed(2); }

  function processFiles(files){
    // files: [{name,text}]
    const detected=[];
    const problems=[];
    for(const f of files){
      const d=detectSchema(f.text);
      if(!d){ problems.push(`Файл ${f.name}: заголовки или разделитель не соответствуют ни одному из трёх утверждённых форматов.`); continue; }
      detected.push({name:f.name, schema:d.schema, rows:d.rows});
    }
    if(problems.length) return {ok:false, problems};
    const ids=detected.map(x=>x.schema.id);
    for(const id of ['A','B','C']){
      const count=ids.filter(x=>x===id).length;
      if(count!==1) problems.push(`Нужен ровно один файл формата ${id}; найдено: ${count}.`);
    }
    if(problems.length) return {ok:false, problems};
    detected.sort((a,b)=>['A','B','C'].indexOf(a.schema.id)-['A','B','C'].indexOf(b.schema.id));

    const all=[];
    const sources=[];
    let originalTotalCents=0;
    for(const src of detected){
      const s=src.schema;
      sources.push({file:src.name, schema:s.id, rows:src.rows.length-1, delimiter:s.delimiter, date_format:s.dateFormat==='DMY'?'дд.мм.гггг':'гггг-мм-дд', decimal_mark:s.decimalMark});
      for(let i=1;i<src.rows.length;i++){
        const vals=src.rows[i];
        const raw={}; s.fields.forEach((k,j)=>raw[k]=(vals[j]??''));
        const record={source_file:src.name, source_row:i+1, schema:s.id, raw, errors:[]};
        record.sale_id=String(raw.sale_id).trim().toUpperCase();
        if(!record.sale_id) record.errors.push('пустой sale_id');
        record.sale_date=parseDate(raw.sale_date,s.dateFormat);
        if(!record.sale_date) record.errors.push('недопустимая дата');
        record.item_code=String(raw.item_code).trim();
        if(!record.item_code) record.errors.push('пустой код товара');
        record.item_name=String(raw.item_name).trim();
        if(!record.item_name) record.errors.push('пустое название товара');
        const qstr=String(raw.quantity).trim();
        record.quantity=/^\d+$/.test(qstr)?Number(qstr):NaN;
        if(!Number.isInteger(record.quantity) || record.quantity<=0) record.errors.push('количество должно быть положительным целым числом');
        const uraw=String(raw.unit).trim();
        record.unit=unitMap[uraw]||null;
        if(!record.unit) record.errors.push('неизвестная единица измерения');
        record.unit_price_cents=parseMoney(raw.unit_price,s.decimalMark);
        if(record.unit_price_cents===null || record.unit_price_cents<=0) record.errors.push('недопустимая цена');
        record.line_total_cents=parseMoney(raw.line_total,s.decimalMark);
        if(record.line_total_cents===null) record.errors.push('сумма строки не читается');
        else originalTotalCents += record.line_total_cents;
        if(Number.isInteger(record.quantity) && record.quantity>0 && record.unit_price_cents!==null && record.line_total_cents!==null){
          const expected=record.quantity*record.unit_price_cents;
          if(expected!==record.line_total_cents) record.errors.push(`арифметика строки: ожидается ${money(expected)} EUR, записано ${money(record.line_total_cents)} EUR`);
        }
        all.push(record);
      }
    }

    const valid=all.filter(r=>r.errors.length===0);
    const byKey=new Map();
    valid.forEach(r=>{ if(!byKey.has(r.sale_id)) byKey.set(r.sale_id,[]); byKey.get(r.sale_id).push(r); });
    const conflictKeys=new Set();
    const duplicateRows=new Set();
    for(const [key,rows] of byKey){
      if(rows.length<=1) continue;
      const sigs=new Set(rows.map(rowSignature));
      if(sigs.size===1){ for(let i=1;i<rows.length;i++) duplicateRows.add(rows[i]); }
      else conflictKeys.add(key);
    }

    const accepted=[], review=[];
    for(const r of all){
      if(r.errors.length){ review.push({...r,status:'Ошибка строки',reason:r.errors.join('; ')}); continue; }
      if(conflictKeys.has(r.sale_id)){ review.push({...r,status:'Конфликт ключа',reason:`для ${r.sale_id} существуют различающиеся строки`}); continue; }
      if(duplicateRows.has(r)){ review.push({...r,status:'Точный повтор',reason:`повтор ${r.sale_id}; в итог оставлена первая строка по порядку источников`}); continue; }
      accepted.push({...r,status:'Принято'});
    }

    const acceptedTotal=accepted.reduce((s,r)=>s+r.line_total_cents,0);
    const duplicateTotal=review.filter(r=>r.status==='Точный повтор').reduce((s,r)=>s+r.line_total_cents,0);
    const conflictTotal=review.filter(r=>r.status==='Конфликт ключа').reduce((s,r)=>s+r.line_total_cents,0);
    const errorTotal=review.filter(r=>r.status==='Ошибка строки').reduce((s,r)=>s+(r.line_total_cents||0),0);
    const checkDiff=originalTotalCents-(acceptedTotal+duplicateTotal+conflictTotal+errorTotal);
    const byDate={};
    accepted.forEach(r=>{ const k=r.sale_date.iso; byDate[k]=(byDate[k]||0)+r.line_total_cents; });

    return {ok:true, all, accepted, review, sources,
      metrics:{input_rows:all.length,accepted_rows:accepted.length,duplicate_rows:review.filter(r=>r.status==='Точный повтор').length,conflict_rows:review.filter(r=>r.status==='Конфликт ключа').length,error_rows:review.filter(r=>r.status==='Ошибка строки').length,original_total_cents:originalTotalCents,accepted_total_cents:acceptedTotal,duplicate_total_cents:duplicateTotal,conflict_total_cents:conflictTotal,error_total_cents:errorTotal,check_diff_cents:checkDiff},
      byDate
    };
  }

  function xmlEscape(v){ return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;'); }
  function colLetter(n){ let s=''; while(n){ n--; s=String.fromCharCode(65+n%26)+s; n=Math.floor(n/26); } return s; }
  function cellXml(row,col,value,type,style){
    const ref=colLetter(col)+row; const st=style?` s="${style}"`:'';
    if(value===null || value===undefined) return `<c r="${ref}"${st}/>`;
    if(type==='n') return `<c r="${ref}"${st}><v>${value}</v></c>`;
    return `<c r="${ref}" t="inlineStr"${st}><is><t>${xmlEscape(value)}</t></is></c>`;
  }
  function sheetXml(rows, widths){
    const maxCols=Math.max(...rows.map(r=>r.length),1), maxRows=rows.length;
    let cols='';
    if(widths && widths.length){ cols='<cols>'+widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join('')+'</cols>'; }
    let body='';
    rows.forEach((r,ri)=>{
      let cells=''; r.forEach((c,ci)=>{ const obj=(c&&typeof c==='object'&&('v' in c))?c:{v:c,t:'s'}; cells+=cellXml(ri+1,ci+1,obj.v,obj.t||'s',obj.s||0); });
      body+=`<row r="${ri+1}">${cells}</row>`;
    });
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:${colLetter(maxCols)}${maxRows}"/>${cols}<sheetData>${body}</sheetData></worksheet>`;
  }

  function crc32(bytes){
    let table=crc32.table;
    if(!table){ table=crc32.table=new Uint32Array(256); for(let n=0;n<256;n++){ let c=n; for(let k=0;k<8;k++) c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1); table[n]=c>>>0; } }
    let c=0xFFFFFFFF; for(const b of bytes) c=table[(c^b)&0xFF]^(c>>>8); return (c^0xFFFFFFFF)>>>0;
  }
  function u16(n){ return [n&255,(n>>>8)&255]; }
  function u32(n){ return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]; }
  function makeZip(entries){
    const enc=new TextEncoder(); const chunks=[]; const central=[]; let offset=0;
    for(const e of entries){
      const name=enc.encode(e.name); const data=typeof e.data==='string'?enc.encode(e.data):e.data; const crc=crc32(data); const flags=0x0800;
      const local=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(flags),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(data.length),...u32(data.length),...u16(name.length),...u16(0),...name]);
      chunks.push(local,data);
      const cen=new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(flags),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(data.length),...u32(data.length),...u16(name.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset),...name]);
      central.push(cen); offset+=local.length+data.length;
    }
    const centralOffset=offset; const centralSize=central.reduce((s,x)=>s+x.length,0);
    const end=new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(entries.length),...u16(entries.length),...u32(centralSize),...u32(centralOffset),...u16(0)]);
    const total=chunks.reduce((s,x)=>s+x.length,0)+centralSize+end.length; const out=new Uint8Array(total); let p=0;
    [...chunks,...central,end].forEach(x=>{out.set(x,p);p+=x.length;}); return out;
  }

  function buildXlsx(result){
    if(!result || !result.ok) throw new Error('Нет успешного результата для экспорта.');
    const m=result.metrics;
    const summary=[
      ['Сводка учебной обработки','Значение'],
      ['Исходных строк',{v:m.input_rows,t:'n'}],['Принятых строк',{v:m.accepted_rows,t:'n'}],['Точный повтор',{v:m.duplicate_rows,t:'n'}],['Конфликтующие строки',{v:m.conflict_rows,t:'n'}],['Ошибочные строки',{v:m.error_rows,t:'n'}],
      ['Сумма всех исходных строк, EUR',{v:m.original_total_cents/100,t:'n',s:2}],['Сумма принятых продаж, EUR',{v:m.accepted_total_cents/100,t:'n',s:2}],['Сумма точных повторов, EUR',{v:m.duplicate_total_cents/100,t:'n',s:2}],['Сумма конфликтов, EUR',{v:m.conflict_total_cents/100,t:'n',s:2}],['Сумма ошибочных строк, EUR',{v:m.error_total_cents/100,t:'n',s:2}],['Контрольная разница, EUR',{v:m.check_diff_cents/100,t:'n',s:2}],[],['Продажи по датам среди принятых строк','EUR']
    ];
    Object.keys(result.byDate).sort().forEach(iso=>{ const [y,mo,d]=iso.split('-').map(Number); summary.push([{v:excelSerial({y,m:mo,d}),t:'n',s:1},{v:result.byDate[iso]/100,t:'n',s:2}]); });
    const headers=['sale_id','sale_date','item_code','item_name','quantity','unit','unit_price EUR','line_total EUR','source_file','source_row','status'];
    const accepted=[headers]; result.accepted.forEach(r=>accepted.push([r.sale_id,{v:excelSerial(r.sale_date),t:'n',s:1},r.item_code,r.item_name,{v:r.quantity,t:'n'},r.unit,{v:r.unit_price_cents/100,t:'n',s:2},{v:r.line_total_cents/100,t:'n',s:2},r.source_file,{v:r.source_row,t:'n'},r.status]));
    const reviewHeaders=[...headers,'reason'];
    const review=[reviewHeaders]; result.review.forEach(r=>review.push([r.sale_id,r.sale_date?{v:excelSerial(r.sale_date),t:'n',s:1}:String(r.raw.sale_date),r.item_code,r.item_name,Number.isFinite(r.quantity)?{v:r.quantity,t:'n'}:String(r.raw.quantity),r.unit||String(r.raw.unit),r.unit_price_cents!==null?{v:r.unit_price_cents/100,t:'n',s:2}:String(r.raw.unit_price),r.line_total_cents!==null?{v:r.line_total_cents/100,t:'n',s:2}:String(r.raw.line_total),r.source_file,{v:r.source_row,t:'n'},r.status,r.reason]));
    const sources=[['Файл','Формат','Строк','Разделитель','Формат даты','Десятичный знак']]; result.sources.forEach(s=>sources.push([s.file,s.schema,{v:s.rows,t:'n'},s.delimiter,s.date_format,s.decimal_mark]));

    const sheetNames=['Сводка','Принятые','Проверка','Источники'];
    const sheetData=[sheetXml(summary,[34,18]),sheetXml(accepted,[16,14,14,24,12,10,16,16,20,12,16]),sheetXml(review,[16,14,14,24,12,10,16,16,20,12,18,45]),sheetXml(sources,[24,10,10,14,16,16])];
    const contentTypes=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheetNames.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`;
    const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
    const workbook=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheetNames.map((n,i)=>`<sheet name="${xmlEscape(n)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets></workbook>`;
    const wbRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheetNames.map((_,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}<Relationship Id="rId${sheetNames.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
    const styles=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="2"><numFmt numFmtId="164" formatCode="dd.mm.yyyy"/><numFmt numFmtId="165" formatCode="0.00"/></numFmts><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    const entries=[{name:'[Content_Types].xml',data:contentTypes},{name:'_rels/.rels',data:rootRels},{name:'xl/workbook.xml',data:workbook},{name:'xl/_rels/workbook.xml.rels',data:wbRels},{name:'xl/styles.xml',data:styles}];
    sheetData.forEach((data,i)=>entries.push({name:`xl/worksheets/sheet${i+1}.xml`,data}));
    return makeZip(entries);
  }

  return {schemas, processFiles, buildXlsx, money, dateDisplay};
});
