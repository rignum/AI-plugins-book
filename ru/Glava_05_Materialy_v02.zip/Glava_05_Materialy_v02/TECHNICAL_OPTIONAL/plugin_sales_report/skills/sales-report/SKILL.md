---
name: sales-report-merge
description: Use this workflow to inspect, validate, and combine recurring sales CSV reports when the user has approved the field mapping, source formats, and duplicate key. Ask for clarification when the key, date format, or column meaning is uncertain.
---

# Sales report merge

Use this workflow only for a sales-report task with an approved field specification. Read the user's current files and the referenced specification. The included example specification describes fictional data; it is not a universal accounting policy.

## Before processing

1. Confirm the reporting period, all source files, currency, and whether the same sale identifier is unique across every source.
2. Compare exact headers and column order with the approved mapping. If they differ, stop and ask for an updated mapping. Do not infer fields from similar names.
3. Use the delimiter, encoding, date format, decimal mark, and unit map specified separately for each source. Never guess an ambiguous date.
4. Preserve identifiers and product codes as text, including leading zeroes. Keep source file and source row for traceability.

## Duplicate handling

- Normalize only the approved key by trimming surrounding spaces and applying the approved case rule.
- Group records by the approved key. Do not call visually similar records duplicates when their keys differ.
- If the key and every approved comparison field match, keep the first record in the stated source order and report the rest as exact repeats.
- If a key repeats but any comparison field differs, send every record with that key to review. Do not choose the newest, largest, or most plausible record.

## Validation and output

- Validate required fields, date parsing, allowed units, positive integer quantity, decimal values, and line_total = quantity × unit_price at the specified currency precision.
- Keep invalid rows in a review output with source, row number, status, and reason. Do not silently repair values.
- Reconcile row counts and source amounts across accepted rows, exact repeats, conflicts, and invalid rows. If an input amount cannot be read, mark reconciliation incomplete; never report a passing zero difference.
- Build a workbook with a summary, accepted rows, review rows, and a source list with file checksums. Label charts as accepted-only when review rows are excluded.
- Do not claim the script ran unless a permitted execution tool actually ran it. The presence of scripts/merge_sales.py in this Skill does not by itself provide local file access or code execution.
- Do not connect to external services, upload customer data, overwrite inputs, or change a production database without an approved integration and explicit authorization.

## Supporting files

- Read assets/field_spec.json for the machine-readable mapping.
- Run scripts/merge_sales.py only in an environment that can access the approved files and execute Python. Require the user or system owner to review the workbook and run record before operational use.
